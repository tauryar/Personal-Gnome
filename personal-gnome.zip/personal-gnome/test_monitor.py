"""İzleyici durum makinesi: toplantı, boşta kalma, başka uygulamaya geçme, dönüş."""
import tempfile

import pytest

import app
import core


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def run(monkeypatch, steps, other_limit=15 * 60, idle_limit=300):
    """steps: (saniye, toplantı_nedeni, boşta_sn, exe, başlık)"""
    it = iter(steps)
    cur = {}

    def tick():
        cur["v"] = next(it)
        return cur["v"][0]

    monkeypatch.setattr(core, "detect_meeting", lambda: cur["v"][1])
    monkeypatch.setattr(core, "idle_seconds", lambda: cur["v"][2])
    monkeypatch.setattr(core, "foreground_app", lambda: (cur["v"][3], cur["v"][4]))

    class Stop:
        n = len(steps)

        def wait(self, t):
            self.n -= 1
            return self.n < 0

    while not app.events.empty():
        app.events.get()
    app.monitor(Stop(), True, idle_limit, other_limit, clock=tick)
    out = []
    while not app.events.empty():
        out.append(app.events.get())
    return out


VS = ("code.exe", "auth.py - oyun - Visual Studio Code")
WA = ("whatsapp.exe", "WhatsApp")


def test_unknown_exe_keeps_idle_behaviour(monkeypatch):
    ev = run(monkeypatch, [(0, None, 0, "", ""), (10, None, 400, "", ""), (20, None, 500, "", ""),
                           (30, None, 2, "", "")])
    assert ev == [("silent", "mola", ""), ("card", "geri döndün")]


def test_long_switch_to_other_app(monkeypatch):
    ev = run(monkeypatch, [(0, None, 0, *VS), (60, None, 0, *WA), (600, None, 0, *WA),
                           (1020, None, 0, *WA), (1100, None, 1, *WA), (1200, None, 1, *VS)])
    assert ev == [("silent", "başka uygulama", VS[1]), ("card", "geri döndün")]
    assert app.STATE["last_work_title"] == VS[1]


def test_short_switch_is_ignored(monkeypatch):
    assert run(monkeypatch, [(0, None, 0, *VS), (60, None, 0, *WA), (180, None, 0, *WA),
                             (200, None, 0, *VS)]) == []


def test_card_waits_until_back_in_work_app(monkeypatch):
    ev = run(monkeypatch, [(0, None, 0, *VS), (400, None, 350, *VS), (500, None, 1, *WA),
                           (520, None, 1, *WA), (540, None, 1, *VS)])
    assert ev == [("silent", "mola", VS[1]), ("card", "geri döndün")]


def test_meeting_only_park_and_card(monkeypatch):
    ev = run(monkeypatch, [(0, None, 0, *VS), (10, "mikrofon: Zoom.exe", 0, "zoom.exe", "Zoom"),
                           (2000, "mikrofon: Zoom.exe", 900, "zoom.exe", "Zoom"), (2010, None, 1, *VS)])
    assert ev == [("park", "toplantı", True, "mikrofon: Zoom.exe"), ("card", "toplantı bitti")]


def test_own_panel_window_is_neutral(monkeypatch):
    assert run(monkeypatch, [(0, None, 0, *VS), (60, None, 0, "personalgnome.exe", "Personal Gnome"),
                             (1200, None, 0, "personalgnome.exe", "Personal Gnome"),
                             (1210, None, 0, *VS)]) == []


def test_monitor_survives_errors(monkeypatch):
    calls = {"n": 0}

    def flaky():
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("geçici")
        return None

    monkeypatch.setattr(core, "detect_meeting", flaky)
    monkeypatch.setattr(core, "idle_seconds", lambda: 0)
    monkeypatch.setattr(core, "foreground_app", lambda: ("", ""))

    class Stop:
        n = 3

        def wait(self, t):
            self.n -= 1
            return self.n < 0

    app.monitor(Stop(), True, 300)
    assert calls["n"] == 3


def test_activity_counts_only_active_work_time(monkeypatch):
    import icgoru
    added = []
    monkeypatch.setattr(icgoru.ACTIVITY, "add", lambda s, now: added.append(s))
    monkeypatch.setattr(core, "foreground_hwnd", lambda: 777)
    run(monkeypatch, [(0, None, 0, *VS), (3, None, 1, *VS), (6, None, 1, *WA),      # WhatsApp sayılmaz
                      (9, None, 120, *VS),                                          # boşta: sayılmaz
                      (500, None, 1, *VS)])                                         # uyku sonrası sıçrama: en fazla 10 sn
    assert added == [0.0, 3.0, 10.0]
    assert app.STATE["last_work_hwnd"] == 777


def test_meeting_time_not_counted_as_work(monkeypatch):
    import icgoru
    added = []
    monkeypatch.setattr(icgoru.ACTIVITY, "add", lambda s, now: added.append(s))
    run(monkeypatch, [(0, "mikrofon: Zoom.exe", 0, *VS), (3, "mikrofon: Zoom.exe", 0, *VS)])
    assert added == []
