"""Sesli not: mikrofon kaydı + yerel Whisper (faster-whisper) ile Türkçe yazıya çevirme.

İsteğe bağlı modül. Kurulu değilse uygulama yazılı notla çalışmaya devam eder.
Kurulum: pip install -r requirements-voice.txt
"""
from __future__ import annotations

import importlib.util
import os
import threading

SAMPLE_RATE = 16000
MODEL_SIZE = os.environ.get("KALDIGIM_YER_MODEL", "small")  # yavaşsa "base" dene

try:
    import numpy as np
    import sounddevice as sd
    # Üç paket de yoksa mikrofon düğmesi hiç gösterilmez.
    AVAILABLE = importlib.util.find_spec("faster_whisper") is not None
except (ImportError, OSError):  # paket yok veya PortAudio kütüphanesi yüklenemedi
    AVAILABLE = False

_model = None
_model_lock = threading.Lock()


def _get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel
            _model = WhisperModel(MODEL_SIZE, device="cpu", compute_type="int8")
    return _model


def preload() -> None:
    """Modeli arka planda önceden yükle (ilk notta bekleme olmasın).
    İlk çalıştırmada model internetten indirilir; hata olursa sessizce geçer,
    sesli not denendiğinde yazılı nota düşülür."""
    def _safe():
        try:
            _get_model()
        except Exception as exc:
            print(f"[sesli not] model yüklenemedi: {exc}")
    if AVAILABLE:
        threading.Thread(target=_safe, daemon=True).start()


class Recorder:
    def __init__(self, max_seconds: int = 30):
        self.max_frames = max_seconds * SAMPLE_RATE
        self.chunks: list = []
        self.stream = None

    def start(self) -> None:
        self.chunks = []

        def cb(indata, frames, t, status):
            if sum(len(c) for c in self.chunks) < self.max_frames:
                self.chunks.append(indata[:, 0].copy())

        self.stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1,
                                     dtype="float32", callback=cb)
        self.stream.start()

    def stop(self):
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        return np.concatenate(self.chunks) if self.chunks else np.zeros(0, dtype="float32")


def transcribe(audio) -> str:
    if len(audio) < SAMPLE_RATE // 2:  # yarım saniyeden kısa
        return ""
    segments, _ = _get_model().transcribe(audio, language="tr", vad_filter=True)
    return " ".join(s.text.strip() for s in segments).strip()


def self_check() -> str:
    """Paketlenmiş uygulamada ses bileşenlerinin yüklendiğini doğrula (model indirmeden)."""
    if not AVAILABLE:
        return "Sesli not: paketler yok (sadece yazılı not)."
    from pathlib import Path

    import ctranslate2
    import faster_whisper
    import onnxruntime

    vad = sorted((Path(faster_whisper.__file__).parent / "assets").glob("*.onnx"))
    if not vad:
        return "Sesli not: HATA - ses etkinliği modeli (assets/*.onnx) pakette yok."
    onnxruntime.InferenceSession(str(vad[0]), providers=["CPUExecutionProvider"])
    return (f"Sesli not: hazır (faster-whisper {faster_whisper.__version__}, "
            f"ctranslate2 {ctranslate2.__version__}, VAD {vad[0].name}). "
            f"Konuşma modeli ({MODEL_SIZE}) ilk kullanımda indirilir.")
