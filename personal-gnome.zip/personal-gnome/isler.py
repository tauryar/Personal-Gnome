"""Personal Gnome - işler: sıradaki adımlar, iş zinciri, standup özeti.

Adımlar isler.json dosyasında tutulur:
  {"id", "metin", "is_adi", "repo", "zaman", "bitti", "bitti_zaman"}
Adımlar nottaki 'sıradaki: ...' işaretlerinden kendiliğinden ya da elle eklenir.
"""
from __future__ import annotations

import time
import uuid

import core

DOSYA = "isler.json"


# ---------------------------------------------------------------- adımlar
def load_items() -> list[dict]:
    items = core.load_json(DOSYA, [])
    out = []
    for it in items:
        if isinstance(it, dict) and str(it.get("metin", "")).strip():
            out.append({
                "id": str(it.get("id") or uuid.uuid4().hex),
                "metin": str(it["metin"]).strip(),
                "is_adi": str(it.get("is_adi", "")),
                "repo": str(it.get("repo", "")),
                "zaman": float(it.get("zaman", 0) or 0),
                "bitti": bool(it.get("bitti", False)),
                "bitti_zaman": float(it.get("bitti_zaman", 0) or 0),
            })
    return out


def save_items(items: list[dict]) -> None:
    # Biten adımlar sonsuza kadar birikmesin: en yeni 300 biten tutulur, açıkların hepsi kalır.
    acik = [i for i in items if not i["bitti"]]
    biten = sorted((i for i in items if i["bitti"]), key=lambda i: i["bitti_zaman"])[-300:]
    core.save_json(DOSYA, acik + biten)


def add_items(texts: list[str], is_adi: str = "", repo: str = "",
              now: float | None = None) -> list[dict]:
    """Yeni adımları ekle; aynı işte aynı metinli açık adım varsa tekrar eklenmez."""
    now = time.time() if now is None else now
    items = load_items()
    acik = {(core.tr_lower(i["metin"]), i["is_adi"]) for i in items if not i["bitti"]}
    added = []
    for t in texts:
        t = t.strip()
        if not t or (core.tr_lower(t), is_adi) in acik:
            continue
        it = {"id": uuid.uuid4().hex, "metin": t, "is_adi": is_adi, "repo": repo,
              "zaman": now, "bitti": False, "bitti_zaman": 0.0}
        items.append(it)
        acik.add((core.tr_lower(t), is_adi))
        added.append(it)
    if added:
        save_items(items)
    return added


def set_done(item_id: str, done: bool = True, now: float | None = None) -> bool:
    items = load_items()
    for it in items:
        if it["id"] == item_id:
            it["bitti"] = done
            it["bitti_zaman"] = (time.time() if now is None else now) if done else 0.0
            save_items(items)
            return True
    return False


def delete_item(item_id: str) -> bool:
    items = load_items()
    kalan = [i for i in items if i["id"] != item_id]
    if len(kalan) == len(items):
        return False
    save_items(kalan)
    return True


def open_items(is_adi: str | None = None) -> list[dict]:
    """Açık adımlar (eskiden yeniye). is_adi verilirse sadece o işin adımları."""
    return [i for i in load_items() if not i["bitti"] and (is_adi is None or i["is_adi"] == is_adi)]


# ---------------------------------------------------------------- iş zinciri
def job_names() -> list[str]:
    """Bilinen iş adları, en son kullanılan önce."""
    son: dict[str, float] = {}
    for r in core.load_records():
        if r.is_adi:
            son[r.is_adi] = max(son.get(r.is_adi, 0), r.zaman)
    for i in load_items():
        if i["is_adi"]:
            son[i["is_adi"]] = max(son.get(i["is_adi"], 0), i["zaman"])
    return [n for n, _ in sorted(son.items(), key=lambda x: -x[1])]


def job_chain(k: core.Kayit, limit: int = 3) -> list[core.Kayit]:
    """k ile aynı işteki, k'den önceki notlu kayıtlar (yeniden eskiye)."""
    if not k.is_adi:
        return []
    out = [r for r in reversed(core.load_records())
           if r.is_adi == k.is_adi and r.not_metni and r.zaman < k.zaman]
    return out[:limit]


def rename_job(old: str, new: str) -> int:
    """İş adını kayıtlarda ve adımlarda değiştir; değişen kayıt + adım sayısını döndürür."""
    old, new = old.strip(), new.strip()
    if not old or not new or old == new:
        return 0
    records = core.load_records()
    n = 0
    for r in records:
        if r.is_adi == old:
            r.is_adi = new
            n += 1
    if n:
        core.save_records(records)
    items = load_items()
    m = 0
    for i in items:
        if i["is_adi"] == old:
            i["is_adi"] = new
            m += 1
    if m:
        save_items(items)
    return n + m


def job_urls(k: core.Kayit, limit: int = 5) -> list[str]:
    """Kaydın ve (iş adı varsa) aynı işteki notlarda geçen bağlantılar, en yeni önce."""
    kayitlar = [k] + (job_chain(k, limit=50) if k.is_adi else [])
    out: list[str] = []
    for r in kayitlar:
        for u in core.find_urls(r.not_metni):
            if u not in out:
                out.append(u)
    for i in open_items(k.is_adi) if k.is_adi else []:
        for u in core.find_urls(i["metin"]):
            if u not in out:
                out.append(u)
    return out[:limit]


# ---------------------------------------------------------------- standup
def _gun(t: float) -> str:
    return time.strftime("%Y-%m-%d", time.localtime(t))


def standup(now: float | None = None) -> str:
    """Dün / Bugün / Engeller metni. 'Dün' = bugünden önceki son kayıtlı gün
    (hafta sonu arasında Cuma olur). Engeller notlardaki 'engel: ...' işaretinden gelir."""
    now = time.time() if now is None else now
    bugun = _gun(now)
    records = core.load_records()
    onceki_gunler = sorted({_gun(r.zaman) for r in records if _gun(r.zaman) < bugun})
    gun = onceki_gunler[-1] if onceki_gunler else bugun
    gun_kayitlari = [r for r in records if _gun(r.zaman) == gun]
    t_dun = time.mktime(time.strptime(gun, "%Y-%m-%d"))
    dun_mu = _gun(now - 86400) == gun
    baslik = ("Dün" if dun_mu else ("Bugün (şu ana kadar)" if gun == bugun else "Son çalışma günü")) \
        + f" ({time.strftime('%d.%m', time.localtime(t_dun))}):"

    dun: list[str] = []
    for r in gun_kayitlari:
        n = r.not_metni.strip()
        if n and n not in dun:
            dun.append(n)
    biten = [i["metin"] for i in load_items() if i["bitti"] and _gun(i["bitti_zaman"]) == gun]

    acik = [i["metin"] for i in open_items()]
    engeller: list[str] = []
    for r in records:
        if _gun(r.zaman) in (gun, bugun):
            for e in core.parse_markers(r.not_metni)[1]:
                if e not in engeller:
                    engeller.append(e)

    out = [baslik]
    out += [f"- {n}" for n in dun[-8:]] or ["- (not yok)"]
    out += [f"- Tamamlandı: {b}" for b in biten[-5:]]
    if gun != bugun:
        out += ["", "Bugün:"]
        if acik:
            out += [f"- {a}" for a in acik[:6]]
        elif records and records[-1].not_metni:
            out.append(f"- {records[-1].not_metni}")
        else:
            out.append("- (plan yok)")
    out += ["", "Engeller:"] + ([f"- {e}" for e in engeller] or ["- Yok"])
    return "\n".join(out)
