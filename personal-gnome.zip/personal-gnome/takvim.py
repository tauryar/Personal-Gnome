"""Takvimden toplantı öncesi hatırlatma (.ics bağlantısı).

Takvim her 10 dakikada bir indirilir, yaklaşan toplantılar her 30 saniyede kontrol edilir.
Toplantıdan N dakika önce (varsayılan 2) panelde not alanı açılır.
Tekrarlayan toplantılar recurring-ical-events ile hesaplanır (RRULE, EXDATE, RECURRENCE-ID).
Tüm gün süren ve iptal edilmiş etkinlikler atlanır. Bağlantı gizli bir adres olduğu için
günlüğe yazılmaz.
"""
from __future__ import annotations

import datetime as dt
import threading
import time
import urllib.parse
import urllib.request

import core

YENILEME_SN = 600
KONTROL_SN = 30
DK_MIN, DK_MAX, DK_VARSAYILAN = 1, 15, 2
MAX_BOYUT = 5_000_000


def settings(s: dict | None = None) -> tuple[str, int]:
    s = core.load_settings() if s is None else s
    url = str(s.get("takvim_url", "") or "").strip()
    try:
        dk = int(s.get("takvim_dk", DK_VARSAYILAN))
    except (TypeError, ValueError):
        dk = DK_VARSAYILAN
    return url, max(DK_MIN, min(DK_MAX, dk))


def normalize_url(url: str) -> str:
    url = url.strip()
    if url.lower().startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    return url


def mask(url: str) -> str:
    """Günlükte gösterilecek güvenli hâl: sadece alan adı."""
    try:
        host = urllib.parse.urlsplit(normalize_url(url)).hostname or "?"
    except ValueError:
        host = "?"
    return f"{host}/…"


def fetch(url: str, timeout: float = 15) -> bytes:
    url = normalize_url(url)
    if not url.lower().startswith(("https://", "http://")):
        raise ValueError("Bağlantı https:// (veya webcal://) ile başlamalı")
    req = urllib.request.Request(url, headers={"User-Agent": "PersonalGnome/2"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read(MAX_BOYUT + 1)
    if len(data) > MAX_BOYUT:
        raise ValueError("Takvim dosyası çok büyük")
    return data


def _epoch(value) -> float | None:
    """Etkinlik başlangıcını Unix zamanına çevir. Tüm gün (tarih) etkinliklerde None.
    Saat dilimi olmayan ('floating') zaman yerel saat kabul edilir."""
    if isinstance(value, dt.datetime):
        return value.timestamp()   # naive -> yerel saat; aware -> kendi dilimi
    return None


def upcoming(data: bytes, now: float, horizon_h: float = 24) -> list[tuple[float, str]]:
    """Şimdiden itibaren horizon_h saat içindeki toplantılar: [(başlangıç, başlık)], sıralı."""
    import icalendar
    import recurring_ical_events
    cal = icalendar.Calendar.from_ical(data)
    start = dt.datetime.fromtimestamp(now - 3600, tz=dt.timezone.utc)
    end = dt.datetime.fromtimestamp(now + horizon_h * 3600, tz=dt.timezone.utc)
    out = []
    for ev in recurring_ical_events.of(cal).between(start, end):
        if str(ev.get("STATUS", "")).upper() == "CANCELLED":
            continue
        dtstart = ev.get("DTSTART")
        t = _epoch(dtstart.dt) if dtstart is not None else None
        if t is None:
            continue
        title = str(ev.get("SUMMARY", "") or "").strip() or "(başlıksız toplantı)"
        out.append((t, title))
    out.sort()
    return out


def describe(items: list[tuple[float, str]], now: float) -> str:
    gelecek = [(t, s) for t, s in items if t >= now]
    if not gelecek:
        return f"{len(items)} etkinlik okundu, önümüzdeki 24 saatte toplantı yok."
    t, s = gelecek[0]
    return (f"{len(gelecek)} yaklaşan toplantı. Sıradaki: {s} "
            f"({time.strftime('%d.%m %H:%M', time.localtime(t))})")


class Watcher:
    """Arka plan iş parçacığı. Hatırlatma anında kuyruğa ("park", ...) olayı koyar."""

    def __init__(self, events, clock=time.time, fetcher=fetch, settings_provider=settings):
        self.events = events
        self.clock = clock
        self.fetcher = fetcher
        self.settings_provider = settings_provider
        self.items: list[tuple[float, str]] = []
        self.url = ""
        self.last_fetch = 0.0
        self.reminded: set[tuple[float, str]] = set()
        self.status = ""
        self._force = threading.Event()

    def refresh_now(self) -> None:
        """Ayar değişince bir sonraki turda hemen indir."""
        self._force.set()

    def _status(self, text: str) -> None:
        if text != self.status:
            self.status = text
            self.events.put(("cal_status", text))

    def tick(self) -> None:
        now = self.clock()
        url, dk = self.settings_provider()
        if not url:
            self.items, self.url = [], ""
            self._status("")
            return
        if url != self.url or now - self.last_fetch >= YENILEME_SN or self._force.is_set():
            self._force.clear()
            self.url, self.last_fetch = url, now
            try:
                self.items = upcoming(self.fetcher(url), now)
                self._status(f"Takvim {time.strftime('%H:%M', time.localtime(now))} güncellendi. "
                             + describe(self.items, now))
            except Exception as exc:  # ağ yok, bağlantı yanlış, dosya bozuk: uygulama etkilenmez
                msg = str(exc).replace(url, mask(url)).replace(normalize_url(url), mask(url))
                print(f"[takvim] {mask(url)} okunamadı: {msg[:120]}")
                self._status(f"Takvim okunamadı: {msg[:80]}")
        for t, title in self.items:
            kalan = t - now
            if 0 <= kalan <= dk * 60 and (t, title) not in self.reminded:
                self.reminded.add((t, title))
                saat = time.strftime("%H:%M", time.localtime(t))
                self.events.put(("park", "toplantı", True, f"takvim: {title} {saat}"))
        self.reminded = {(t, s) for t, s in self.reminded if t > now - 3600}

    def run(self, stop: threading.Event) -> None:
        while True:
            try:
                self.tick()
            except Exception as exc:
                print(f"[takvim] hata, devam ediliyor: {exc}")
            # ayar değişince hızlı tepki: 30 sn beklerken zorla yenileme gelirse erken uyan
            for _ in range(KONTROL_SN):
                if stop.wait(1):
                    return
                if self._force.is_set():
                    break


def test_url(url: str, now: float | None = None) -> str:
    """Ayarlar'daki 'Test et' düğmesi: indir, çözümle, özetle."""
    now = time.time() if now is None else now
    if not url.strip():
        return "Önce takvim bağlantısını yaz."
    try:
        return describe(upcoming(fetch(url), now), now)
    except Exception as exc:
        msg = str(exc).replace(url, mask(url))
        return f"Takvim okunamadı: {msg[:100]}"
