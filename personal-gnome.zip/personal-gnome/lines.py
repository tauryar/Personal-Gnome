"""Personal Gnome - kaldığın satırı bulma.

Öncelik sırası (kartta kaynağı yazar):
  1. vscode : VS Code eklentisinin yazdığı imleç konumu (kaydedilmemiş değişiklikte bile doğru)
  2. kopya  : dosyanın bellekteki kopyasıyla karşılaştırma -> son kaydedilen değişikliğin satırı
  3. git    : git'teki ilk değişiklik bloğu (yaklaşık)
Hiçbiri yoksa satır gösterilmez.

Proje dosyalarına yalnızca OKUMA yapılır.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

import core

IMLEC_DOSYASI = "vscode_imlec.json"
MAX_DOSYA = 30            # bellekte kopyası tutulan en fazla dosya
MAX_BOYUT = 1_000_000     # bundan büyük dosyaların kopyası tutulmaz (bayt)
IMLEC_ESKI_PAY = 120      # imleçten bu kadar sn sonra başka yerde değişiklik varsa imleç eski sayılır


# ---------------------------------------------------------------- 1. VS Code imleci
def read_cursor() -> dict | None:
    """Eklentinin yazdığı {"dosya", "satir" (1'den başlar), "zaman" (ms)} verisi."""
    try:
        data = json.loads((core._data_dir() / IMLEC_DOSYASI).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    dosya, satir, zaman = data.get("dosya"), data.get("satir"), data.get("zaman")
    if not isinstance(dosya, str) or not isinstance(satir, int) or isinstance(satir, bool) \
            or satir < 1 or not isinstance(zaman, (int, float)):
        return None
    return {"dosya": dosya, "satir": satir, "zaman": float(zaman) / 1000.0,
            "kaydedilmemis": bool(data.get("kaydedilmemis", False))}


def _relative_in(repo: str, path: str, pm=os.path) -> str | None:
    """path, repo klasörünün içindeyse göreli yolu (orijinal harf büyüklüğüyle, / ile), değilse None.
    Windows'ta 'c:\\' ile 'C:\\' aynı sayılır (normcase). pm: yol modülü (testte ntpath)."""
    try:
        r = pm.abspath(repo)
        p = pm.abspath(path)
        if pm.commonpath([pm.normcase(r), pm.normcase(p)]) != pm.normcase(r):
            return None
        rel = pm.relpath(p, r)
    except ValueError:  # farklı sürücüler
        return None
    if rel == "." or rel.startswith(".."):
        return None
    return rel.replace("\\", "/") if pm.sep == "\\" else Path(rel).as_posix()


def cursor_in_repo(repo: str, newest_change: float = 0.0) -> tuple[str, int] | None:
    """İmleç bu projedeki bir dosyadaysa (göreli yol, satır).
    newest_change: projedeki en son dosya değişikliğinin zamanı; imleç verisinden belirgin
    biçimde yeniyse başka bir editörde çalışılmış demektir, imleç kullanılmaz."""
    c = read_cursor()
    if not c or not repo or not Path(c["dosya"]).is_file():
        return None
    rel = _relative_in(repo, c["dosya"])
    if rel is None:
        return None
    if newest_change > c["zaman"] + IMLEC_ESKI_PAY:
        return None
    return rel, c["satir"]


# ---------------------------------------------------------------- 2. bellekteki kopyalar
def changed_line(old: list[bytes], new: list[bytes]) -> int:
    """İki sürüm arasındaki değişikliğin, yeni sürümdeki son satırı (1'den başlar).
    Ortak baş ve son kısım atılır; kalan blok değişen yerdir. Silmede, silinen yerin
    hemen sonrasındaki satır. Değişiklik yoksa 0."""
    if old == new:
        return 0
    n = min(len(old), len(new))
    p = 0
    while p < n and old[p] == new[p]:
        p += 1
    s = 0
    while s < n - p and old[-1 - s] == new[-1 - s]:
        s += 1
    son = len(new) - s          # değişen bloğun yeni sürümdeki bitişi (dahil, 1 tabanlı)
    if son > p:
        return son
    return max(1, min(p + 1, len(new)))  # saf silme


def _read_lines(path: Path) -> list[bytes] | None:
    """Metin dosyasının satırları (\\n, \\r\\n, \\r ile ayrılır - editörlerle aynı). İkili veya
    çok büyük dosyada None."""
    try:
        if path.stat().st_size > MAX_BOYUT:
            return None
        data = path.read_bytes()
    except OSError:
        return None
    if b"\0" in data[:8192]:
        return None
    return data.splitlines()  # bytes.splitlines yalnızca \n, \r, \r\n'de böler


class ShadowTracker:
    """Son değişen dosyaların kopyasını bellekte tutar; değiştiklerinde farkı bulur."""

    def __init__(self, max_files: int = MAX_DOSYA):
        self.max_files = max_files
        self._lock = threading.Lock()
        self._files: dict[str, dict] = {}

    def observe(self, path: Path) -> None:
        try:
            st = path.stat()
        except OSError:
            with self._lock:
                self._files.pop(str(path), None)
            return
        key = str(path)
        with self._lock:
            entry = self._files.get(key)
        if entry and entry["mtime"] == st.st_mtime_ns and entry["size"] == st.st_size:
            entry["seen"] = time.monotonic()
            return
        lines = _read_lines(path)
        if lines is None:
            with self._lock:
                self._files.pop(key, None)
            return
        change = entry.get("change") if entry else None
        if entry is not None:
            ln = changed_line(entry["lines"], lines)
            if ln:
                change = (st.st_mtime, ln)
        with self._lock:
            self._files[key] = {"mtime": st.st_mtime_ns, "size": st.st_size, "lines": lines,
                                "change": change, "seen": time.monotonic()}
            if len(self._files) > self.max_files:
                for k, _ in sorted(self._files.items(), key=lambda kv: kv[1]["seen"])[
                        :len(self._files) - self.max_files]:
                    del self._files[k]

    def sample(self, repo: str) -> None:
        """Projede en son değişen dosyaların kopyasını al / güncelle."""
        if not repo or not Path(repo).is_dir():
            return
        for _, rel in core._changed_files(repo)[:self.max_files]:
            self.observe(Path(repo) / rel)

    def line_for(self, path: Path) -> int:
        """Dosyada son kaydedilen değişikliğin satırı (bilinmiyorsa 0)."""
        self.observe(path)  # son örneklemeden beri kaydedildiyse şimdi yakala
        with self._lock:
            entry = self._files.get(str(path))
            return entry["change"][1] if entry and entry["change"] else 0

    def tracked(self) -> int:
        with self._lock:
            return len(self._files)


TRACKER = ShadowTracker()


# ---------------------------------------------------------------- birleştirme
def refine(repo: str, snap: dict, tracker: ShadowTracker | None = TRACKER) -> dict:
    """git_snapshot sonucuna en güvenilir satır bilgisini ekle."""
    snap = dict(snap)
    files = list(snap.get("dosyalar", []))
    newest = 0.0
    for f in files:
        try:
            newest = max(newest, (Path(repo) / f).stat().st_mtime)
        except OSError:
            pass
    cur = cursor_in_repo(repo, newest)
    if cur:
        rel, line = cur
        snap["dosyalar"] = ([rel] + [f for f in files if f != rel])[:max(5, len(files))]
        snap["satir"], snap["satir_kaynak"] = line, "vscode"
        return snap
    if files and tracker is not None:
        ln = tracker.line_for(Path(repo) / files[0])
        if ln:
            snap["satir"], snap["satir_kaynak"] = ln, "kopya"
            return snap
    if snap.get("git_deposu") and snap.get("satir"):
        snap["satir_kaynak"] = "git"
    else:
        snap["satir"], snap["satir_kaynak"] = 0, ""
    return snap


def snapshot(repo: str, tracker: ShadowTracker | None = TRACKER) -> dict:
    return refine(repo, core.git_snapshot(repo), tracker)


def sampler(stop: threading.Event, repos_provider, interval: float = 10.0,
            tracker: ShadowTracker = TRACKER) -> None:
    """Arka planda her interval saniyede projelerdeki son değişen dosyaları örnekle."""
    while True:
        try:
            for repo in list(repos_provider()):
                tracker.sample(repo)
        except Exception as exc:  # tek bir hata örneklemeyi durdurmasın
            print(f"[satır] hata, devam ediliyor: {exc}")
        if stop.wait(interval):
            return
