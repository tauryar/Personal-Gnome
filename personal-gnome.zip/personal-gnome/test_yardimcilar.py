"""Takvim, tepsi, tema, başlangıç kaydı, ekran görüntüsü, içgörü."""
import datetime as dt
import os
import sys
import tempfile
import time
import types

import pytest

import core


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


class Q:
    def __init__(self):
        self.items = []

    def put(self, x):
        self.items.append(x)


# ================================================================ takvim
import takvim  # noqa: E402

NOW = dt.datetime(2026, 11, 27, 9, 0, tzinfo=dt.timezone.utc).timestamp()   # 12:00 İstanbul


def ics(*events: str) -> bytes:
    body = "\r\n".join(events)
    return ("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//t//t//EN\r\n" + body + "\r\nEND:VCALENDAR\r\n").encode()


def ev(uid, summary, start, extra=""):
    return (f"BEGIN:VEVENT\r\nUID:{uid}\r\nSUMMARY:{summary}\r\nDTSTART:{start}\r\n"
            f"DTEND:{start}\r\n{extra}END:VEVENT")


DATA = ics(
    ev("1", "Daily", "20261120T091000Z", "RRULE:FREQ=DAILY\r\nEXDATE:20261128T091000Z\r\n"),
    ev("2", "Tatil", "20261127", "").replace("DTSTART:20261127", "DTSTART;VALUE=DATE:20261127")
                                    .replace("DTEND:20261127", "DTEND;VALUE=DATE:20261128"),
    ev("3", "İptal edilen", "20261127T100000Z", "STATUS:CANCELLED\r\n"),
    ev("4", "Sprint planlama", "20261127T110000Z", ""),
)


def test_upcoming_handles_recurrence_allday_cancelled():
    items = takvim.upcoming(DATA, NOW)
    titles = [(time.strftime("%d %H:%M", time.gmtime(t)), s) for t, s in items]
    assert ("27 09:10", "Daily") in titles and ("27 11:00", "Sprint planlama") in titles
    assert all(s not in ("Tatil", "İptal edilen") for _, s in titles)      # tüm gün + iptal atlandı
    assert ("28 09:10", "Daily") not in titles                               # EXDATE
    assert takvim.describe(items, NOW).startswith("2 yaklaşan toplantı. Sıradaki: Daily")


def test_floating_time_is_local():
    data = ics(ev("f", "Yerel", "20261127T150000", ""))
    (t, s), = takvim.upcoming(data, time.mktime((2026, 11, 27, 12, 0, 0, 0, 0, -1)))
    assert time.localtime(t)[3:5] == (15, 0)


def test_settings_clamp_and_url_helpers():
    assert takvim.settings({}) == ("", 2)
    assert takvim.settings({"takvim_url": " x ", "takvim_dk": 99}) == ("x", 15)
    assert takvim.settings({"takvim_dk": "abc"})[1] == 2
    assert takvim.normalize_url("webcal://p.com/a.ics") == "https://p.com/a.ics"
    assert takvim.mask("https://calendar.google.com/private-gizli/basic.ics") == "calendar.google.com/…"
    with pytest.raises(ValueError):
        takvim.fetch("file:///etc/passwd")


def test_watcher_reminds_once_in_window():
    q = Q()
    clock = {"t": NOW}
    w = takvim.Watcher(q, clock=lambda: clock["t"], fetcher=lambda url: DATA,
                       settings_provider=lambda: ("https://x/gizli.ics", 2))
    w.tick()                                         # 12:00, toplantı 12:10: henüz değil
    assert not [e for e in q.items if e[0] == "park"]
    assert q.items[0][0] == "cal_status" and "güncellendi" in q.items[0][1]
    clock["t"] = NOW + 8 * 60 + 30                   # 1,5 dk kala
    w.tick()
    w.tick()                                         # tekrar kontrol: ikinci hatırlatma yok
    parks = [e for e in q.items if e[0] == "park"]
    assert len(parks) == 1 and parks[0][:3] == ("park", "toplantı", True)
    assert parks[0][3].startswith("takvim: Daily ")
    clock["t"] = NOW + 11 * 60                       # başladıktan sonra: hatırlatma yok
    w.tick()
    assert len([e for e in q.items if e[0] == "park"]) == 1


def test_watcher_error_is_masked_and_isolated(capsys):
    q = Q()
    url = "https://calendar.example/private-COKGIZLI/basic.ics"

    def bad(u):
        raise OSError(f"bağlanamadı: {u}")

    w = takvim.Watcher(q, clock=lambda: NOW, fetcher=bad, settings_provider=lambda: (url, 2))
    w.tick()
    out = capsys.readouterr().out
    assert "COKGIZLI" not in out and "calendar.example/…" in out
    assert q.items[-1][0] == "cal_status" and "COKGIZLI" not in q.items[-1][1]


def test_watcher_no_url_does_nothing():
    q = Q()
    w = takvim.Watcher(q, clock=lambda: NOW, fetcher=lambda u: 1 / 0, settings_provider=lambda: ("", 2))
    w.tick()
    assert q.items == []


# ================================================================ tepsi
import tray  # noqa: E402


def test_tray_icon_images():
    img = tray.make_image("kesinti")
    assert img.size == (64, 64) and img.getpixel((32, 6))[:3] == tray.RENKLER["kesinti"]
    assert img.getpixel((0, 0))[3] == 0                     # köşe saydam


def test_tray_icon_uses_logo_inside_state_ring():
    assert tray.logo_path().is_file() and tray._logo() is not None
    for state, color in tray.RENKLER.items():
        img = tray.make_image(state)
        assert img.getpixel((32, 3))[:3] == color            # halka: durum rengi
    assert tray.make_image("normal").getpixel((32, 32))[:3] != tray.RENKLER["normal"]  # ortada logo


def test_tray_disabled_outside_windows():
    if sys.platform == "win32":
        pytest.skip("Windows")
    t = tray.Tray(Q())
    assert not t.ok and "Windows" in t.error
    t.set_state("kesinti")
    t.stop()
    t.start()                                               # hiçbiri hata vermez


def test_tray_menu_puts_events(monkeypatch):
    """Sahte pystray ile: menü öğeleri sadece kuyruğa olay koyar, varsayılan öğe Göster/Gizle."""
    created = {}

    class MenuItem:
        def __init__(self, text, action, default=False):
            self.text, self.action, self.default = text, action, default

    class Menu:
        SEPARATOR = object()

        def __init__(self, *items):
            self.items = items

    class Icon:
        def __init__(self, name, image, title, menu):
            created.update(name=name, title=title, menu=menu)
            self.icon = image
            self.stopped = False

        def run(self):
            created["ran"] = True

        def stop(self):
            self.stopped = True

    fake = types.SimpleNamespace(MenuItem=MenuItem, Menu=Menu, Icon=Icon)
    monkeypatch.setitem(sys.modules, "pystray", fake)
    monkeypatch.setattr(tray.sys, "platform", "win32")
    q = Q()
    t = tray.Tray(q)
    assert t.ok and created["title"] == "Personal Gnome"
    items = [i for i in created["menu"].items if i is not Menu.SEPARATOR]
    assert [i.text for i in items] == ["Göster / Gizle", "Bölündüm (not bırak)", "Kartı göster",
                                       "Şerit / Sabit", "Çıkış"]
    assert [i.default for i in items] == [True, False, False, False, False]
    for i in items:
        i.action(None, i)
    assert q.items == [("tray", a) for a in ("toggle", "park", "card", "strip", "quit")]
    t.set_state("donus")
    assert t.icon.icon.getpixel((32, 6))[:3] == tray.RENKLER["donus"]
    t.start()
    time.sleep(0.1)
    assert created.get("ran")
    t.stop()
    assert t.icon.stopped


# ================================================================ başlangıç kaydı
import baslangic  # noqa: E402


def test_autostart_only_for_exe():
    assert baslangic.command("C:\\Araclar\\PersonalGnome.exe") == '"C:\\Araclar\\PersonalGnome.exe"'
    if sys.platform != "win32":
        assert not baslangic.available() and baslangic.refresh() == "" and not baslangic.is_enabled()
        with pytest.raises(RuntimeError):
            baslangic.enable()
        baslangic.disable()                                  # hata vermez


def test_autostart_rejects_long_path(monkeypatch):
    monkeypatch.setattr(baslangic, "available", lambda: True)
    monkeypatch.setattr(baslangic.sys, "executable", "C:\\" + "a" * 300 + "\\PersonalGnome.exe")
    with pytest.raises(ValueError):
        baslangic.enable()


# ================================================================ ekran görüntüsü
import ekran  # noqa: E402


def test_clip_rect_excludes_panel_and_screen_edges():
    # 1920x1080, panel sağda 346 px; pencere ekrandan taşıyor ve panelin altına giriyor
    assert ekran.clip_rect((-8, -8, 1930, 1040), (1574, 0, 346, 1032), 1920, 1080) == (0, 0, 1574, 1040)
    # panel solda
    assert ekran.clip_rect((0, 0, 1000, 800), (0, 0, 288, 1080), 1920, 1080) == (288, 0, 1000, 800)
    # tamamen panelin altında kalan pencere: görüntü yok
    assert ekran.clip_rect((1600, 0, 1900, 900), (1574, 0, 346, 1080), 1920, 1080) is None


def test_capture_saves_png_and_cleanup_only_old(monkeypatch):
    from PIL import Image
    monkeypatch.setattr(ekran, "window_rect", lambda h: (100, 100, 900, 700))
    boxes = []

    def grab(bbox):
        boxes.append(bbox)
        return Image.new("RGB", (bbox[2] - bbox[0], bbox[3] - bbox[1]), "white")

    name = ekran.capture(1234, (1574, 0, 346, 1080), 1920, 1080, zaman=time.time(), grabber=grab)
    assert boxes == [(100, 100, 900, 700)] and name.endswith(".png")
    for _ in range(50):
        if ekran.path_for(name):
            break
        time.sleep(0.05)
    p = ekran.path_for(name)
    assert p and Image.open(p).size == (800, 600)
    eski = ekran.shots_dir() / "20000101-000000-000.png"
    eski.write_bytes(b"x")
    os.utime(eski, (time.time() - 8 * 86400,) * 2)
    baska = ekran.shots_dir() / "not.txt"                   # .png olmayan dosyaya dokunulmaz
    baska.write_text("x")
    os.utime(baska, (time.time() - 30 * 86400,) * 2)
    assert ekran.cleanup() == 1
    assert not eski.exists() and p.exists() and baska.exists()


def test_capture_failures_return_empty(monkeypatch):
    monkeypatch.setattr(ekran, "window_rect", lambda h: None)
    assert ekran.capture(1, None, 1920, 1080, time.time(), grabber=lambda bbox: 1 / 0) == ""
    monkeypatch.setattr(ekran, "window_rect", lambda h: (0, 0, 800, 600))

    def locked(bbox):
        raise OSError("screen grab failed")

    assert ekran.capture(1, None, 1920, 1080, time.time(), grabber=locked) == ""
    assert ekran.path_for("../x.png") is None and ekran.path_for("") is None


def test_screenshot_setting_default_off():
    assert not ekran.enabled()
    core.set_setting("ekran_goruntusu", True)
    assert ekran.enabled()


# ================================================================ içgörü
import icgoru  # noqa: E402


def at(h, m=0, d=27):
    return time.mktime((2026, 11, d, h, m, 0, 0, 0, -1))


def test_activity_buffers_and_flushes():
    a = icgoru.Activity(flush_every=60)
    a.add(3, at(9))
    assert icgoru.load() == {}                               # ilk eklemede yazılmaz
    for i in range(30):
        a.add(3, at(9, 1) + i)
    a.flush(at(9, 2))
    assert icgoru.load() == {"2026-11-27 09": 93.0}


def test_activity_prunes_after_60_days():
    core.save_json(icgoru.DOSYA, {"2026-01-01 10": 100.0, "2026-11-20 10": 50.0})
    a = icgoru.Activity()
    a.add(10, at(10))
    a.flush(at(10))
    assert set(icgoru.load()) == {"2026-11-20 10", "2026-11-27 10"}


def test_insight_report():
    core.save_json(icgoru.DOSYA, {"2026-11-27 09": 3600.0, "2026-11-27 10": 3600.0,
                                  "2026-11-27 14": 1800.0})
    recs = [core.Kayit(zaman=at(10, 5), not_metni="", tur="mesaj", repo=""),
            core.Kayit(zaman=at(10, 30), not_metni="", tur="mesaj", repo=""),
            core.Kayit(zaman=at(14, 10), not_metni="", tur="toplantı", repo="", donus=at(14, 40))]
    core.save_records(recs)
    r = icgoru.report(7, now=at(18))
    assert "Ölçülen çalışma: 2 sa 30 dk" in r
    assert "09:00   1 sa 0 dk" in r and "10:00   1 sa 0 dk" in r
    assert "En az bölündüğün saatler: 09:00" in r
    assert "En çok bölündüğün saat: 14:00" in r                 # 1 kesinti / 0,5 saat = 2
    assert "Toplantı yükü: 1 toplantı, süresi ölçülen toplam 30 dk (çalışma süresinin %20'i kadar)" in r


def test_insight_without_data():
    assert "Çalışma süresi verisi henüz yok" in icgoru.report(7)
