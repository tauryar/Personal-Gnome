"""Windows açılışında başlatma (kullanıcının kendi Run kaydı; yönetici izni gerekmez).

HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run altına "PersonalGnome" değeri yazılır.
Microsoft'a göre bu kayıttaki komut satırı en fazla 260 karakter olabilir.
Yalnızca .exe olarak çalışırken kullanılabilir (kaynaktan çalıştırırken kapalı).
"""
from __future__ import annotations

import sys

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
NAME = "PersonalGnome"
MAX_KOMUT = 260


def available() -> bool:
    return sys.platform == "win32" and bool(getattr(sys, "frozen", False))


def command(exe: str | None = None) -> str:
    return f'"{exe or sys.executable}"'


def current_value() -> str | None:
    if sys.platform != "win32":
        return None
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            value, _ = winreg.QueryValueEx(k, NAME)
            return str(value)
    except OSError:
        return None


def is_enabled() -> bool:
    return current_value() is not None


def enable() -> None:
    if not available():
        raise RuntimeError("Sadece .exe olarak çalışırken kullanılabilir")
    cmd = command()
    if len(cmd) > MAX_KOMUT:
        raise ValueError(f"Uygulama yolu çok uzun ({len(cmd)} > {MAX_KOMUT} karakter); "
                         "exe'yi daha kısa bir klasöre taşı")
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, NAME, 0, winreg.REG_SZ, cmd)


def disable() -> None:
    if sys.platform != "win32":
        return
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, NAME)
    except FileNotFoundError:
        pass


def refresh() -> str:
    """Açılışta çağrılır: kayıt açıksa ve exe taşındıysa yolu güncelle."""
    if not available():
        return ""
    val = current_value()
    if val is not None and val != command():
        try:
            enable()
            return "başlangıç kaydı yeni konuma güncellendi"
        except (OSError, ValueError, RuntimeError) as exc:
            return f"başlangıç kaydı güncellenemedi: {exc}"
    return ""
