"""İşler, iş zinciri, notlardan adım çıkarma, standup, Markdown, eski kayıt uyumu."""
import json
import tempfile
import time

import pytest

import core
import isler


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def rec(zaman, not_metni="", is_adi="", tur="diğer", repo="/p/oyun", **kw):
    return core.Kayit(zaman=zaman, not_metni=not_metni, tur=tur, repo=repo, is_adi=is_adi,
                      git_deposu=False, **kw)


# ---------------------------------------------------------------- Türkçe küçük harf + işaretler
def test_tr_lower_keeps_length_and_turkish_i():
    s = "SIRADAKİ: İstanbul IĞDIR"
    low = core.tr_lower(s)
    assert low == "sıradaki: istanbul ığdır" and len(low) == len(s)
    assert "İ".lower() != "i"                     # Python'un kendi lower'ı yanlış (kanıt)


@pytest.mark.parametrize("text,adim,engel", [
    ("sıradaki: token testini yaz", ["token testini yaz"], []),
    ("SIRADAKİ: büyük harfle", ["büyük harfle"], []),
    ("Sıradaki adım: login ekranı", ["login ekranı"], []),
    ("siradaki: ascii klavye", ["ascii klavye"], []),
    ("TODO: a; b ;c", ["a", "b", "c"], []),
    ("yapılacak: x\nengel: API anahtarı bekleniyor", ["x"], ["API anahtarı bekleniyor"]),
    ("sırada: bir sıradaki: iki", ["bir", "iki"], []),
    ("sıradaki adım ne bilmiyorum", [], []),       # iki nokta yoksa adım değil
    ("engelli: değil", [], []),                    # 'engel' kelimenin parçası
    ("Notta sadece düşünce var", [], []),
])
def test_parse_markers(text, adim, engel):
    assert core.parse_markers(text) == (adim, engel)


def test_find_urls_strips_punctuation_and_dedupes():
    t = "bak https://github.com/a/b/issues/3, ve (https://x.dev/y). tekrar https://github.com/a/b/issues/3"
    assert core.find_urls(t) == ["https://github.com/a/b/issues/3", "https://x.dev/y"]


def test_default_job_from_branch():
    assert core.default_job("login-fix") == "login-fix"
    assert core.default_job("main") == "" and core.default_job("master") == "" and core.default_job("") == ""


# ---------------------------------------------------------------- eski kayıt uyumu
def test_old_records_without_new_fields_load():
    eski = [{"zaman": 1.0, "not_metni": "m1", "tur": "mola", "repo": "/r", "dal": "main",
             "diff_ozet": "", "dosyalar": ["a.py"], "satir": 3, "pencere": "", "otomatik": False}]
    core.data_file().write_text(json.dumps(eski), encoding="utf-8")
    k = core.load_records()[0]
    assert (k.satir_kaynak, k.is_adi, k.ekran, k.kaynak) == ("", "", "", "")
    card = core.format_card(k, now=100)
    assert "a.py  (satır 3)" in card                # eski kayıtta kaynak etiketi yok


def test_one_broken_record_does_not_drop_others():
    core.data_file().write_text(json.dumps([{"bozuk": 1}, {"zaman": 2.0, "not_metni": "ok",
                                                          "tur": "mola", "repo": ""}]), encoding="utf-8")
    assert [r.not_metni for r in core.load_records()] == ["ok"]


# ---------------------------------------------------------------- adımlar
def test_add_items_dedupes_and_done_delete():
    a = isler.add_items(["test yaz", "TEST YAZ", "doc"], is_adi="login", repo="/r", now=10)
    assert [i["metin"] for i in a] == ["test yaz", "doc"]
    assert isler.add_items(["test yaz"], is_adi="login") == []        # açık olan tekrar eklenmez
    assert len(isler.add_items(["test yaz"], is_adi="başka iş")) == 1  # farklı işte eklenir
    iid = a[0]["id"]
    assert isler.set_done(iid, True, now=20)
    assert [i["metin"] for i in isler.open_items("login")] == ["doc"]
    assert isler.set_done(iid, False)
    assert len(isler.open_items("login")) == 2
    assert isler.delete_item(iid) and not isler.delete_item(iid)


def test_job_chain_names_and_rename():
    core.save_records([rec(1, "ilk", "login"), rec(2, "", "login"), rec(3, "ikinci", "login"),
                       rec(4, "başka", "rapor"), rec(5, "üçüncü", "login")])
    k = core.load_records()[-1]
    assert [r.not_metni for r in isler.job_chain(k)] == ["ikinci", "ilk"]
    assert isler.job_names() == ["login", "rapor"]
    isler.add_items(["adım"], is_adi="login")
    assert isler.rename_job("login", "giriş") == 5        # 4 kayıt + 1 adım
    assert {r.is_adi for r in core.load_records()} == {"giriş", "rapor"}
    assert isler.open_items("giriş")[0]["metin"] == "adım"


def test_job_urls_from_chain_newest_first_max_5():
    core.save_records([rec(1, "https://a.com/1 https://a.com/2", "j"),
                       rec(2, "https://a.com/3", "j"), rec(3, "https://b.com", "diğer"),
                       rec(4, "son not https://a.com/4 https://a.com/5 https://a.com/6", "j")])
    k = core.load_records()[-1]
    assert isler.job_urls(k) == ["https://a.com/4", "https://a.com/5", "https://a.com/6",
                                 "https://a.com/3", "https://a.com/1"]


def test_card_shows_job_chain_and_steps():
    core.save_records([rec(time.time() - 7200, "önceki not", "login")])
    k = rec(time.time(), "şimdiki not", "login")
    card = core.format_card(k, zincir=isler.job_chain(k), adimlar=["token testini yaz"])
    assert "İş: login" in card and "Bu işteki önceki notlar:" in card and "önceki not" in card
    assert "Sıradaki adımlar:" in card and "[ ] token testini yaz" in card


def test_markdown_card():
    k = core.Kayit(zaman=time.mktime((2026, 11, 27, 14, 5, 0, 0, 0, -1)), not_metni="y=3 neden",
                   tur="soru", repo="/p/oyun", dal="login", diff_ozet="1 file changed",
                   dosyalar=["auth.py", "b.py"], satir=42, satir_kaynak="vscode", is_adi="login")
    md = core.markdown_card(k, adimlar=["test yaz"])
    assert md.startswith("### Personal Gnome: oyun\n_27.11.2026 14:05, soru_")
    assert "**Not:** y=3 neden" in md and "- **Dal:** `login`" in md
    assert "- **Dosya:** `auth.py` (satır 42 - imleç, VS Code)" in md and "- `b.py`" in md
    assert "- [ ] test yaz" in md


# ---------------------------------------------------------------- standup
def at(y, m, d, h=10):
    return time.mktime((y, m, d, h, 0, 0, 0, 0, -1))


def test_standup_uses_previous_work_day_and_blockers():
    core.save_records([rec(at(2026, 11, 20), "eski gün"),
                       rec(at(2026, 11, 24), "login formu bitti"),
                       rec(at(2026, 11, 24, 15), "engel: API anahtarı bekleniyor"),
                       rec(at(2026, 11, 27, 9), "bugünkü not")])
    isler.add_items(["token testi"], is_adi="login", now=at(2026, 11, 24))
    done = isler.add_items(["form doğrulama"], now=at(2026, 11, 24))
    isler.set_done(done[0]["id"], True, now=at(2026, 11, 24, 16))
    s = isler.standup(now=at(2026, 11, 27, 11))
    assert s.startswith("Son çalışma günü (24.11):")    # 25-26 boş: Pazartesi gibi
    assert "- login formu bitti" in s and "eski gün" not in s
    assert "- Tamamlandı: form doğrulama" in s
    assert "Bugün:\n- token testi" in s
    assert "Engeller:\n- API anahtarı bekleniyor" in s


def test_standup_yesterday_label_and_empty():
    assert "Engeller:\n- Yok" in isler.standup(now=at(2026, 11, 27))
    core.save_records([rec(at(2026, 11, 26), "dünkü not")])
    s = isler.standup(now=at(2026, 11, 27))
    assert s.startswith("Dün (26.11):") and "Bugün:\n- dünkü not" in s
