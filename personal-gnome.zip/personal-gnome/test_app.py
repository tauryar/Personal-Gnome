"""app.py yardımcıları."""
import sys
import tempfile

import pytest

import app


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def test_dpi_awareness_is_noop_outside_windows():
    if sys.platform != "win32":
        assert app.enable_dpi_awareness() == "Windows değil"


def test_dpi_called_before_tk_window_in_main():
    import inspect
    src = inspect.getsource(app.main)
    assert src.index("enable_dpi_awareness()") < src.index("tk.Tk()")


def test_package_check_reports_all_components():
    out = app.package_check()
    for part in ("Sesli not", "Takvim: tamam", "Tepsi: tamam", "VS Code eklentisi: tamam",
                 "Ekran görüntüsü: tamam"):
        assert part in out, out
    assert out.startswith("Paket testi: tamam")


def test_ui_event_runs_callable():
    ran = []

    class P:
        pass

    app.handle_event(P(), ("ui", lambda: ran.append(1)))
    assert ran == [1]


def test_cli_paket_testi(capsys):
    import core
    app.main(["--paket-testi"])
    assert "Paket testi:" in capsys.readouterr().out
    assert (core._data_dir() / "paket_testi.txt").read_text(encoding="utf-8").startswith("Paket testi: tamam")


def test_cli_rapor_still_works(capsys):
    app.main(["--rapor", "7"])
    assert "Son 7 günde kayıt yok." in capsys.readouterr().out
