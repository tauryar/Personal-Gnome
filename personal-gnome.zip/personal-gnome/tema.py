"""Açık / Koyu / Windows'a uy tema.

Açık tema bugünkü görünümün aynısıdır (sistemin ttk teması, Tk varsayılan renkleri).
Koyu temada 'clam' ttk teması kullanılır: Windows'un yerleşik 'vista' teması renk
ayarlarının çoğunu yok sayar. Windows ayarı kayıt defterinden okunur:
HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize\\AppsUseLightTheme
(0 = koyu, 1 = açık).
"""
from __future__ import annotations

import sys
import tkinter as tk
from tkinter import ttk

SECENEKLER = {"Açık": "acik", "Koyu": "koyu", "Windows'a uy": "sistem"}
KOYU = {"bg": "#202124", "fg": "#e8eaed", "alan": "#2d2e31", "secim": "#3c5a87", "soluk": "#9aa0a6",
        "kenar": "#45474a", "dugme": "#35363a", "aktif": "#4a4c50"}
# Tk widget'larında temaya göre değiştirilen seçenekler
_SECENEKLER = ("background", "foreground", "insertbackground", "selectbackground",
               "selectforeground", "highlightbackground", "highlightcolor", "disabledforeground",
               "activebackground", "activeforeground")


def system_prefers_dark() -> bool | None:
    if sys.platform != "win32":
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as k:
            value, _ = winreg.QueryValueEx(k, "AppsUseLightTheme")
        return int(value) == 0
    except (OSError, ValueError):
        return None


def resolve(mode: str) -> str:
    """'acik' | 'koyu' | 'sistem' -> uygulanacak 'acik' veya 'koyu'."""
    if mode == "koyu":
        return "koyu"
    if mode == "sistem":
        return "koyu" if system_prefers_dark() else "acik"
    return "acik"


class ThemeManager:
    def __init__(self, root: tk.Misc):
        self.root = root
        self.style = ttk.Style(root)
        self.light_theme = self.style.theme_use()
        self.current = "acik"
        self._defaults: dict[str, dict[str, str]] = {}
        probe = tk.Listbox(root)  # açılır listenin varsayılan renkleri (açık temaya dönüş için)
        self._list_colors = (probe.cget("background"), probe.cget("foreground"))
        probe.destroy()

    # Tk (ttk olmayan) widget'ları gez
    def _walk(self, w):
        yield w
        for c in w.winfo_children():
            yield from self._walk(c)

    def _remember_defaults(self) -> None:
        for w in self._walk(self.root):
            if isinstance(w, ttk.Widget) or str(w) in self._defaults:
                continue
            d = {}
            for opt in _SECENEKLER:
                try:
                    d[opt] = w.cget(opt)
                except tk.TclError:
                    pass
            self._defaults[str(w)] = d

    def colors(self) -> dict:
        """Panelin dinamik renklendirmesi için (durum satırı vb.)."""
        if self.current == "koyu":
            return {"bg": KOYU["bg"], "fg": KOYU["fg"], "soluk": KOYU["soluk"]}
        return {}

    def apply(self, name: str) -> None:
        self._remember_defaults()
        if name == "koyu":
            self._apply_dark()
        else:
            self._apply_light()
        self.current = name

    def _apply_light(self) -> None:
        self.style.theme_use(self.light_theme)
        self.root.option_add("*TCombobox*Listbox.background", self._list_colors[0])
        self.root.option_add("*TCombobox*Listbox.foreground", self._list_colors[1])
        for w in self._walk(self.root):
            d = self._defaults.get(str(w))
            if d:
                for opt, val in d.items():
                    try:
                        w.configure(**{opt: val})
                    except tk.TclError:
                        pass

    def _apply_dark(self) -> None:
        c = KOYU
        s = self.style
        s.theme_use("clam")
        s.configure(".", background=c["bg"], foreground=c["fg"], fieldbackground=c["alan"],
                    bordercolor=c["kenar"], lightcolor=c["bg"], darkcolor=c["bg"],
                    troughcolor=c["alan"], selectbackground=c["secim"], selectforeground=c["fg"],
                    insertcolor=c["fg"], arrowcolor=c["fg"])
        s.configure("TButton", background=c["dugme"])
        s.map("TButton", background=[("active", c["aktif"]), ("disabled", c["bg"])],
              foreground=[("disabled", c["soluk"])])
        s.configure("TNotebook", background=c["bg"])
        s.configure("TNotebook.Tab", background=c["dugme"], foreground=c["fg"])
        s.map("TNotebook.Tab", background=[("selected", c["bg"])])
        s.map("TCombobox", fieldbackground=[("readonly", c["alan"])],
              foreground=[("readonly", c["fg"])], selectbackground=[("readonly", c["alan"])])
        s.configure("TCheckbutton", background=c["bg"], foreground=c["fg"])
        s.map("TCheckbutton", background=[("active", c["bg"])])
        s.configure("TLabelframe", background=c["bg"])
        s.configure("TLabelframe.Label", background=c["bg"], foreground=c["fg"])
        s.configure("TSpinbox", fieldbackground=c["alan"], foreground=c["fg"])
        self.root.option_add("*TCombobox*Listbox.background", c["alan"])
        self.root.option_add("*TCombobox*Listbox.foreground", c["fg"])
        renk = {"background": c["bg"], "foreground": c["fg"], "insertbackground": c["fg"],
                "selectbackground": c["secim"], "selectforeground": c["fg"],
                "highlightbackground": c["bg"], "highlightcolor": c["kenar"],
                "disabledforeground": c["soluk"], "activebackground": c["aktif"],
                "activeforeground": c["fg"]}
        for w in self._walk(self.root):
            if isinstance(w, ttk.Widget):
                continue
            opts = dict(renk)
            if isinstance(w, (tk.Text, tk.Listbox, tk.Entry)):
                opts["background"] = c["alan"]
            for opt, val in opts.items():
                try:
                    w.configure(**{opt: val})
                except tk.TclError:
                    pass
