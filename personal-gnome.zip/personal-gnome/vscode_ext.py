"""VS Code eklentisinin kurulumu ve durumu.

Kurulum, VS Code'un resmi komut satırı seçeneğiyle yapılır:
  code --install-extension personal-gnome-vscode.vsix --force
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import time
from pathlib import Path

import core
import lines

VSIX = "personal-gnome-vscode.vsix"
CMD_OZEL = '&|<>^%"'  # code bir .cmd dosyası: cmd'nin özel karakterlerini içeren yolu verme


def bundled_vsix() -> Path | None:
    """.exe içinde (PyInstaller geçici klasörü) ya da kaynak klasöründe gelen eklenti dosyası."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    p = base / VSIX
    return p if p.is_file() else None


def install(timeout: float = 120) -> tuple[bool, str]:
    code = shutil.which("code")
    if not code:
        return False, "code komutu bulunamadı (VS Code kurulu mu, PATH'e eklendi mi?)"
    src = bundled_vsix()
    if src is None:
        return False, "Eklenti dosyası pakette yok."
    dst = core._data_dir() / VSIX  # .exe kapanınca silinen geçici klasör yerine kalıcı kopya
    shutil.copyfile(src, dst)
    if any(ch in str(dst) for ch in CMD_OZEL):
        return False, f"Klasör yolunda özel karakter var, elle kur: {dst}"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
    try:
        out = subprocess.run([code, "--install-extension", str(dst), "--force"],
                             capture_output=True, text=True, encoding="utf-8", errors="replace",
                             timeout=timeout, creationflags=flags)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Kurulum çalıştırılamadı: {exc}"
    msg = (out.stdout or out.stderr or "").strip().splitlines()
    son = msg[-1] if msg else ""
    if out.returncode == 0:
        return True, "Kuruldu. VS Code'u yeniden başlat (veya pencereyi yenile). " + son
    return False, f"Kurulum başarısız ({out.returncode}): {son}"


def status(now: float | None = None) -> str:
    now = time.time() if now is None else now
    c = lines.read_cursor()
    if not c:
        return "Eklenti verisi yok (kurulu değil ya da VS Code henüz açılmadı)."
    return (f"Bağlı. Son imleç {core.sure_metni(max(0, now - c['zaman']))} önce: "
            f"{Path(c['dosya']).name}, satır {c['satir']}")
