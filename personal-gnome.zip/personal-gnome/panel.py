"""Personal Gnome - ekranın kenarındaki panel (Tkinter).

Sekmeler:
  Şimdi   : Bölündüm düğmesi, not alanı, "kaldığın yer" kartı ve düğmeleri
  İşler   : notlardaki 'sıradaki: ...' adımları, elle adım, iş adı değiştirme
  Geçmiş  : son kayıtlar (işe göre süzülebilir), seçilenin kartı
  Rapor   : kesinti raporu + saatlik içgörü, standup özeti kopyalama
  Ayarlar : projeler, yok sayılanlar, görünüm, başlangıç, ekran görüntüsü, takvim, VS Code
Üst çubuk: şerit (Ş), taraf (<>), daralt/genişlet (- +), tam ekran ([ ]), kapat/gizle (X).
Düğmelerde emoji kullanılmaz: Tk 8.6 bazı simgeleri doğru çizemiyor.
"""
from __future__ import annotations

import shutil
import subprocess
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
import webbrowser
from pathlib import Path
from tkinter import filedialog, simpledialog, ttk

import baslangic
import core
import dock
import ekran
import icgoru
import isler
import lines
import takvim
import tema
import voice
import vscode_ext

RENK_KESINTI = "#ffd27f"
RENK_DONUS = "#bde5b8"
RENK_SERIT = "#7f8fa6"
VARSAYILAN_SORU = "Ne düşünüyordun, sıradaki adım ne? (ör. sıradaki: test yaz)"
DONEMLER = {"Son 1 gün": 1, "Son 7 gün": 7, "Son 30 gün": 30}
SERIT_PX = 12               # şerit modunda ekranda ayrılan genişlik
KAPANMA_SN = 2.0            # şerit: fare ayrıldıktan bu kadar sonra daralır
KART_ACIK_SN = 20.0         # şerit: kart kendiliğinden açılınca en az bu kadar açık kalır
TAKVIM_SUSTURMA_SN = 15 * 60  # takvim hatırlatmasından sonra mikrofon algısı yeni not açmaz
SEKMELER = [("Şimdi", "Şimdi"), ("İşler", "İş"), ("Geçmiş", "Geç."), ("Rapor", "Rap."), ("Ayarlar", "Ayar")]
TUM_ISLER = "(tüm işler)"
ISSIZ = "(iş adı yok)"


def pretty_key(spec: str) -> str:
    """'<ctrl>+<shift>+<f9>' -> 'Ctrl+Shift+F9'"""
    return "+".join(p.strip("<>").capitalize() if len(p.strip("<>")) > 1 else p.strip("<>").upper()
                    for p in spec.split("+")) if spec else ""


def open_in_editor(path: Path, line: int = 0) -> bool:
    """VS Code'da dosyayı aç; satır biliniyorsa o satırda: code -g dosya:satır."""
    code = shutil.which("code")
    target = f"{path}:{line}" if line else str(path)
    # Windows'ta code bir .cmd dosyası; cmd'nin özel karakterlerini içeren yolları açma.
    if not code or any(ch in target for ch in '&|<>^%"'):
        return False
    try:
        subprocess.Popen([code, "-g", target] if line else [code, target])
        return True
    except OSError:
        return False


class Panel:
    def __init__(self, root: tk.Misc, repos: list[str], events, park_key: str = "",
                 card_key: str = "", cli_repos: bool = False, title_provider=None,
                 hwnd_provider=None, tracker: lines.ShadowTracker | None = lines.TRACKER):
        self.root, self.events = root, events
        self.repos = list(repos)
        self.cli_repos = cli_repos          # komut satırından geldiyse ayarlara yazılmaz
        self.title_provider = title_provider or core.active_window_title
        self.hwnd_provider = hwnd_provider or (lambda: 0)  # son iş penceresi (ekran görüntüsü)
        self.tracker = tracker
        self.tray = None                    # app.py bağlar; varsa X tepsiye gizler
        self.calendar_watcher = None        # app.py bağlar
        self.pending: dict | None = None    # kesinti anının bekleyen anlık görüntüsü
        self.recorder = None
        self.fullscreen = False
        self.hidden = False
        self._closed = False
        self._modal = False                 # klasör seçme vb. açıkken
        self._fs_app = False                # öndeki uygulama tam ekran mı
        self._topmost = None
        self._ignore_app = ""
        self._last_calendar = 0.0
        self._job_auto = True               # iş alanı kullanıcı tarafından değiştirilmedi
        self._status_color: str | None = None
        self._short_tabs = False
        self._ticks = 0
        self._redocks: list[float] = []
        self._redock_pause = 0.0
        self._geo_fixes: list[float] = []
        self._geo_fix_pause = 0.0
        self._after: dict[str, str] = {}
        self._card_record: core.Kayit | None = None
        self._urls: list[str] = []
        self._goto_target: tuple[Path, int] | None = None
        self.strip_mode = core.get_setting("serit") is True
        self.expanded = not self.strip_mode
        self._last_inside = 0.0
        self._hold_until = 0.0
        self.taraf, self.pct = core.panel_settings()
        self.dock = dock.Dock(root)

        root.title("Personal Gnome")
        try:  # pencere simgesi: klasör seçme gibi diyaloglarda da logo görünsün
            import tray
            if tray.logo_path().is_file():
                self._icon = tk.PhotoImage(file=str(tray.logo_path()))
                root.iconphoto(True, self._icon)
        except Exception as exc:
            print(f"[panel] simge yüklenemedi: {exc}")
        root.overrideredirect(True)          # çerçevesiz: başlık çubuğu yerine kendi düğmelerimiz
        self._build(park_key, card_key)
        self.theme = tema.ThemeManager(root)
        mode = core.get_setting("tema", "acik")
        self.theme_mode = mode if mode in tema.SECENEKLER.values() else "acik"
        self._apply_theme()
        root.bind("<Configure>", self._on_configure)
        root.bind("<Map>", lambda e: e.widget is self.root and self._update_topmost())
        root.bind("<Escape>", lambda e: self.escape())  # not alanı dışındayken de çalışsın
        root.update_idletasks()
        self.place()
        self.refresh_all()
        self._loop("serit", 300, self._strip_tick)
        self._loop("yavas", 2000, self._slow_tick)
        self._cleanup_shots()

    # ============================================================== zamanlayıcılar
    def _loop(self, name: str, ms: int, fn) -> None:
        def run():
            if self._closed:
                return
            try:
                fn()
            except Exception as exc:  # tek bir hata döngüyü durdurmasın
                print(f"[panel {name}] hata, devam ediliyor: {exc}")
            if not self._closed:
                try:
                    self._after[name] = self.root.after(ms, run)
                except tk.TclError:
                    pass
        self._after[name] = self.root.after(ms, run)

    # ============================================================== arayüz
    def _build(self, park_key: str, card_key: str) -> None:
        r = self.root
        top = tk.Frame(r)
        top.pack(fill="x")
        # Düğmeler önce yerleşir: panel daralınca başlık kırpılır, düğmeler değil.
        for text, cmd in (("X", self.on_x), ("[ ]", self.toggle_fullscreen),
                          ("+", lambda: self.resize(+1)), ("-", lambda: self.resize(-1)),
                          ("<>", self.toggle_side), ("Ş", self.toggle_strip)):
            ttk.Button(top, text=text, width=len(text) if len(text) > 1 else 2,
                       command=cmd).pack(side="right", padx=1)
        self.title_lbl = tk.Label(top, text="Personal Gnome", font=("Segoe UI", 11, "bold"))
        self.title_lbl.pack(side="left", padx=6, pady=4)

        self.status = tk.Label(r, text="Hazır", anchor="w", justify="left", padx=6)
        self.status.pack(fill="x")
        self._light_bg, self._light_fg = self.status.cget("bg"), self.status.cget("fg")
        self._normal_bg, self._normal_fg = self._light_bg, self._light_fg

        self.footer = tk.Label(r, text=f"Not bırak: {pretty_key(park_key)}\nKart: {pretty_key(card_key)}",
                               anchor="w", justify="left", fg="gray", padx=6)
        self.footer.pack(fill="x", side="bottom")

        self.nb = ttk.Notebook(r)
        self.nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.tab_now, self.tab_jobs, self.tab_hist, self.tab_rep, self.tab_set = \
            (ttk.Frame(self.nb) for _ in range(5))
        self.tabs = (self.tab_now, self.tab_jobs, self.tab_hist, self.tab_rep, self.tab_set)
        for tab, (name, _) in zip(self.tabs, SEKMELER):
            self.nb.add(tab, text=name)
        self._build_now()
        self._build_jobs()
        self._build_history()
        self._build_report()
        self._build_settings()

        # Şerit modunda daraltılmış hâlde her şeyin üstünü örten ince renkli şerit.
        self.strip = tk.Frame(r, bg=RENK_SERIT, cursor="hand2")
        self.strip.bind("<Button-1>", lambda e: self.expand(hold=10))

    def _build_now(self) -> None:
        f = self.tab_now
        park = ttk.LabelFrame(f, text="Not bırak")
        park.pack(fill="x", padx=4, pady=4)
        self.bolundum_btn = ttk.Button(park, text="Bölündüm", command=self.bolundum)
        self.bolundum_btn.pack(fill="x", padx=4, pady=(4, 2))
        self.park_info = ttk.Label(park, text=VARSAYILAN_SORU, justify="left")
        self.park_info.pack(fill="x", padx=4, pady=2)
        self.entry = tk.Text(park, height=4, wrap="word")
        self.entry.pack(fill="x", padx=4)
        self.entry.bind("<Return>", self._on_enter)
        self.entry.bind("<Escape>", lambda e: self.escape())
        jrow = ttk.Frame(park)
        jrow.pack(fill="x", padx=4, pady=(4, 0))
        ttk.Label(jrow, text="İş:").pack(side="left")
        self.job = ttk.Combobox(jrow, values=[])
        self.job.pack(side="left", fill="x", expand=True, padx=(4, 0))
        self.job.bind("<KeyRelease>", lambda e: self._job_touched())
        self.job.bind("<<ComboboxSelected>>", lambda e: self._job_touched())
        row = ttk.Frame(park)
        row.pack(fill="x", padx=4, pady=4)
        # Kaydet önce yerleşir: panel daralınca kırpılan tür listesi olsun, Kaydet değil.
        self.save_btn = ttk.Button(row, text="Kaydet", width=7, command=self.save)
        self.save_btn.pack(side="right")
        self.mic_btn = None
        if voice.AVAILABLE:
            self.mic_btn = ttk.Button(row, text="Konuş", width=6, command=self.toggle_voice)
            self.mic_btn.pack(side="right", padx=4)
        self.tur = ttk.Combobox(row, values=core.TURLER, width=8, state="readonly")
        self.tur.set("diğer")
        self.tur.pack(side="left", fill="x", expand=True)
        self.ignore_btn = ttk.Button(park, text="", command=self._ignore_clicked)

        card = ttk.LabelFrame(f, text="Kaldığın yer")
        card.pack(fill="both", expand=True, padx=4, pady=4)
        btns = ttk.Frame(card)
        btns.pack(fill="x", side="bottom", padx=4, pady=(0, 4))
        self.goto_btn = ttk.Button(btns, text="Kaldığın satıra git", command=self._goto)
        self.devam_btn = ttk.Button(btns, text="Devam et", command=self._devam)
        self.shot_btn = ttk.Button(btns, text="Ekran görüntüsünü aç", command=self._open_shot)
        self.md_btn = ttk.Button(btns, text="Markdown kopyala", command=self._copy_md)
        box = ttk.Frame(card)
        box.pack(fill="both", expand=True, padx=4, pady=4)
        sb = ttk.Scrollbar(box, orient="vertical")
        self.card = tk.Text(box, wrap="word", height=8, relief="flat", borderwidth=0,
                            highlightthickness=0, cursor="arrow", yscrollcommand=sb.set,
                            font="TkDefaultFont", padx=4, pady=4)
        sb.config(command=self.card.yview)
        sb.pack(side="right", fill="y")
        self.card.pack(side="left", fill="both", expand=True)
        self.card.config(state="disabled")

    def _build_jobs(self) -> None:
        f = self.tab_jobs
        self.jobs_filter = ttk.Combobox(f, state="readonly", values=[TUM_ISLER])
        self.jobs_filter.set(TUM_ISLER)
        self.jobs_filter.pack(fill="x", padx=4, pady=(6, 2))
        self.jobs_filter.bind("<<ComboboxSelected>>", lambda e: self.refresh_jobs())
        self.show_done = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Bitenleri de göster", variable=self.show_done,
                        command=self.refresh_jobs).pack(anchor="w", padx=4)
        self.jobs_list = tk.Listbox(f, activestyle="none", height=10)
        self.jobs_list.pack(fill="both", expand=True, padx=4, pady=4)
        self.jobs_list.bind("<Double-Button-1>", lambda e: self._toggle_step())
        add = ttk.Frame(f)
        add.pack(fill="x", padx=4)
        self.step_entry = ttk.Entry(add)
        self.step_entry.pack(side="left", fill="x", expand=True)
        self.step_entry.bind("<Return>", lambda e: self._add_step())
        ttk.Button(add, text="Ekle", width=5, command=self._add_step).pack(side="right", padx=(4, 0))
        for text, cmd in (("Bitti / geri al", self._toggle_step), ("Sil", self._delete_step),
                          ("İşi yeniden adlandır", self._rename_job)):
            ttk.Button(f, text=text, command=cmd).pack(fill="x", padx=4, pady=1)
        self._job_items: list[dict] = []

    def _build_history(self) -> None:
        f = self.tab_hist
        self.hist_filter = ttk.Combobox(f, state="readonly", values=[TUM_ISLER])
        self.hist_filter.set(TUM_ISLER)
        self.hist_filter.pack(fill="x", padx=4, pady=(6, 2))
        self.hist_filter.bind("<<ComboboxSelected>>", lambda e: self.refresh_history())
        self.hist = tk.Listbox(f, activestyle="none", height=10)
        self.hist.pack(fill="both", expand=True, padx=4, pady=4)
        self.hist.bind("<<ListboxSelect>>", self._hist_select)
        self.hist_card = ttk.Label(f, text="", justify="left")
        self.hist_card.pack(fill="x", padx=4, pady=4)
        self._hist_records: list[core.Kayit] = []

    def _build_report(self) -> None:
        row = ttk.Frame(self.tab_rep)
        row.pack(fill="x", padx=4, pady=4)
        self.donem = ttk.Combobox(row, values=list(DONEMLER), width=11, state="readonly")
        self.donem.set("Son 7 gün")
        self.donem.pack(side="left")
        self.donem.bind("<<ComboboxSelected>>", lambda e: self.refresh_report())
        ttk.Button(row, text="Yenile", command=self.refresh_report).pack(side="right")
        ttk.Button(self.tab_rep, text="Standup özetini kopyala", command=self.copy_standup).pack(
            fill="x", padx=4)
        self.report_text = tk.Text(self.tab_rep, wrap="word", height=12, state="disabled")
        self.report_text.pack(fill="both", expand=True, padx=4, pady=4)

    def _build_settings(self) -> None:
        outer = self.tab_set
        canvas = tk.Canvas(outer, highlightthickness=0, borderwidth=0)
        sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        f = ttk.Frame(canvas)
        win = canvas.create_window((0, 0), window=f, anchor="nw")
        f.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))

        def wheel(e):
            # Sadece Ayarlar sekmesi açıkken ve fare onun içindeyken kaydır (listeler kendi kayar).
            try:
                if self._closed or self.nb.select() != str(self.tab_set):
                    return
                w = self.root.winfo_containing(e.x_root, e.y_root)
            except (tk.TclError, KeyError):
                return
            if w is None or not str(w).startswith(str(self.tab_set)) or isinstance(w, tk.Listbox):
                return
            up = getattr(e, "delta", 0) > 0 or getattr(e, "num", 0) == 4
            canvas.yview_scroll(-1 if up else 1, "units")
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            canvas.bind_all(seq, wheel, add="+")
        self._wheel = wheel
        self.set_canvas = canvas
        self._notes: list[ttk.Label] = []

        def note(parent, text):
            lbl = ttk.Label(parent, text=text, foreground="gray", justify="left")
            lbl.pack(anchor="w", padx=4, pady=(0, 4), fill="x")
            self._notes.append(lbl)
            return lbl

        def heading(parent, text, pady=(6, 2)):
            lbl = ttk.Label(parent, text=text, justify="left")
            lbl.pack(anchor="w", padx=4, pady=pady, fill="x")
            self._notes.append(lbl)  # dar panelde sarılsın
            return lbl

        heading(f, "Proje klasörleri:")
        self.repo_list = tk.Listbox(f, height=4)
        self.repo_list.pack(fill="x", padx=4)
        row = ttk.Frame(f)
        row.pack(fill="x", padx=4, pady=4)
        ttk.Button(row, text="Ekle", command=self._add_repo).pack(side="left")
        ttk.Button(row, text="Kaldır", command=self._remove_repo).pack(side="left", padx=4)
        if self.cli_repos:
            note(f, "Komut satırından verilen projeler kullanılıyor (kaydedilmez).")

        heading(f, "Toplantı sayılmayan uygulamalar:", pady=(8, 2))
        self.ign_list = tk.Listbox(f, height=3)
        self.ign_list.pack(fill="x", padx=4)
        ttk.Button(f, text="Listeden çıkar", command=self._remove_ignore).pack(anchor="w", padx=4, pady=4)

        g = ttk.LabelFrame(f, text="Görünüm")
        g.pack(fill="x", padx=4, pady=4)
        trow = ttk.Frame(g)
        trow.pack(fill="x", padx=4, pady=2)
        ttk.Label(trow, text="Tema:").pack(side="left")
        self.theme_combo = ttk.Combobox(trow, state="readonly", values=list(tema.SECENEKLER), width=13)
        self.theme_combo.pack(side="left", padx=4)
        self.theme_combo.bind("<<ComboboxSelected>>", lambda e: self._theme_selected())
        self.strip_var = tk.BooleanVar(value=self.strip_mode)
        ttk.Checkbutton(g, text="Şerit modu", variable=self.strip_var,
                        command=self._strip_checked).pack(anchor="w", padx=4)
        note(g, "Kenarda ince bir şerit kalır; fareyi kenara götürünce açılır, "
                "ayrılınca 2 sn sonra daralır.")

        b = ttk.LabelFrame(f, text="Başlangıç")
        b.pack(fill="x", padx=4, pady=4)
        self.autostart_var = tk.BooleanVar(value=baslangic.is_enabled())
        cb = ttk.Checkbutton(b, text="Windows açılınca başlat", variable=self.autostart_var,
                             command=self._autostart_checked)
        cb.pack(anchor="w", padx=4)
        if not baslangic.available():
            cb.state(["disabled"])
            note(b, "Sadece .exe olarak çalışırken kullanılabilir.")

        e = ttk.LabelFrame(f, text="Ekran görüntüsü")
        e.pack(fill="x", padx=4, pady=4)
        self.shot_var = tk.BooleanVar(value=ekran.enabled())
        ttk.Checkbutton(e, text="Kesintide çalıştığım\npencerenin görüntüsünü al",
                        variable=self.shot_var, command=self._shot_checked).pack(anchor="w", padx=4)
        note(e, "Sadece çalıştığın pencere alınır, bu bilgisayarda kalır, 7 gün sonra silinir.")

        c = ttk.LabelFrame(f, text="Takvim hatırlatması")
        c.pack(fill="x", padx=4, pady=4)
        heading(c, "Takvimin .ics bağlantısı (gizli adres):", pady=0)
        url, dk = takvim.settings()
        self.cal_url = ttk.Entry(c, show="•")
        self.cal_url.insert(0, url)
        self.cal_url.pack(fill="x", padx=4)
        self.cal_show = tk.BooleanVar(value=False)
        ttk.Checkbutton(c, text="Bağlantıyı göster", variable=self.cal_show,
                        command=lambda: self.cal_url.config(show="" if self.cal_show.get() else "•")
                        ).pack(anchor="w", padx=4)
        drow = ttk.Frame(c)
        drow.pack(fill="x", padx=4, pady=2)
        ttk.Label(drow, text="Kaç dk önce:").pack(side="left")
        self.cal_dk = ttk.Spinbox(drow, from_=takvim.DK_MIN, to=takvim.DK_MAX, width=4)
        self.cal_dk.set(str(dk))
        self.cal_dk.pack(side="left", padx=4)
        crow = ttk.Frame(c)
        crow.pack(fill="x", padx=4, pady=2)
        ttk.Button(crow, text="Kaydet", command=self._save_calendar).pack(side="left")
        ttk.Button(crow, text="Test et", command=self._test_calendar).pack(side="left", padx=4)
        self.cal_status = note(c, "Takvim bağlı değil." if not url else "")

        v = ttk.LabelFrame(f, text="VS Code eklentisi")
        v.pack(fill="x", padx=4, pady=4)
        ttk.Button(v, text="Eklentiyi kur / güncelle", command=self._install_ext).pack(anchor="w", padx=4, pady=2)
        self.ext_status = note(v, "")
        note(v, "Eklenti imlecin gerçek satırını verir (kaydedilmemiş değişiklikte bile). "
                "İnternete bağlanmaz, dosyalarını değiştirmez.")

    # ============================================================== tema
    def _apply_theme(self, only_if_changed: bool = False) -> None:
        name = tema.resolve(self.theme_mode)
        if only_if_changed and name == self.theme.current:
            return
        self.theme.apply(name)
        c = self.theme.colors()
        self._normal_bg = c.get("bg", self._light_bg)
        self._normal_fg = c.get("fg", self._light_fg)
        self.set_status(self.status.cget("text"), self._status_color)
        label = next(k for k, v in tema.SECENEKLER.items() if v == self.theme_mode)
        self.theme_combo.set(label)
        if hasattr(self, "geo"):  # temada düğme genişlikleri değişir: başlık sığıyor mu
            self.root.update_idletasks()
            self._update_title(self.geo[2])

    def _theme_selected(self) -> None:
        self.theme_mode = tema.SECENEKLER.get(self.theme_combo.get(), "acik")
        core.set_setting("tema", self.theme_mode)
        self._apply_theme()

    # ============================================================== yerleşim
    def place(self) -> None:
        reserve = SERIT_PX if (self.strip_mode and not self.fullscreen) else None
        reserved = self.dock.apply(self.taraf, self.pct, self.fullscreen, reserve)
        geo = reserved
        if reserve is not None and self.expanded:
            geo = dock.expanded_rect(self.taraf, self.dock.full_width, reserved,
                                     dock.screen_size(self.root)[0])
            self.dock.set_geometry(geo)
        self.geo = geo
        self._show_strip(reserve is not None and not self.expanded)
        self._update_wrap(geo[2])
        self._update_topmost()

    def _show_strip(self, on: bool) -> None:
        if on:
            self.strip.place(x=0, y=0, relwidth=1, relheight=1)
            self.strip.lift()
        else:
            self.strip.place_forget()

    def expand(self, hold: float = 0.0) -> None:
        """Şerit modunda paneli aç (ayrılan alan değişmez, pencereler yeniden boyutlanmaz)."""
        if hold:
            self._hold_until = max(self._hold_until, time.monotonic() + hold)
        self._last_inside = time.monotonic()
        if not self.strip_mode or self.fullscreen or self.expanded:
            return
        self.expanded = True
        self.geo = dock.expanded_rect(self.taraf, self.dock.full_width, self.dock.reserved,
                                      dock.screen_size(self.root)[0])
        self.dock.set_geometry(self.geo)
        self._show_strip(False)
        self._update_wrap(self.geo[2])
        self.root.lift()

    def collapse(self) -> None:
        if not self.strip_mode or self.fullscreen or not self.expanded:
            return
        self.expanded = False
        self.geo = self.dock.reserved
        self.dock.set_geometry(self.geo)
        self._show_strip(True)

    def _busy(self) -> bool:
        """Not yazılırken, kayıt sürerken veya bir alana yazarken şerit daralmaz."""
        if self.pending is not None or self.recorder is not None or self.note_text() or self._modal:
            return True
        try:
            fw = self.root.focus_get()
        except (KeyError, tk.TclError):  # açılır listenin iç parçası odaktaysa
            return True
        return isinstance(fw, (tk.Entry, ttk.Entry, tk.Text, tk.Spinbox)) and fw is not self.card

    def _fix_geometry(self) -> None:
        """Pencere istenen yerde değilse (pencere sistemi bir taşımayı yuttuysa) yeniden uygula.
        Bir dakikada 3'ten fazla gerekirse 10 dk vazgeç: sistemle kavga etmesin."""
        if self.hidden or self._modal or not self.root.winfo_ismapped():
            return
        now = time.monotonic()
        if now < self._geo_fix_pause:
            return
        actual = (self.root.winfo_x(), self.root.winfo_y(), self.root.winfo_width(), self.root.winfo_height())
        if all(abs(a - b) <= 1 for a, b in zip(actual, self.geo)):
            return
        self._geo_fixes = [t for t in self._geo_fixes if now - t < 60] + [now]
        if len(self._geo_fixes) > 3:
            self._geo_fix_pause = now + 600
            print(f"[panel] pencere konumu tutmuyor (istenen {self.geo}, olan {actual}); 10 dk denenmeyecek")
            return
        self.dock.set_geometry(self.geo)

    def _strip_tick(self) -> None:
        self._fix_geometry()
        if not self.strip_mode or self.fullscreen or self.hidden:
            return
        now = time.monotonic()
        px, py = self.root.winfo_pointerxy()
        x, y, w, h = self.geo
        if x <= px < x + w and y <= py < y + h:
            self._last_inside = now
            if not self.expanded:
                self.expand()
        elif (self.expanded and now - self._last_inside >= KAPANMA_SN
              and now >= self._hold_until and not self._busy()):
            self.collapse()

    def _slow_tick(self) -> None:
        """2 sn'de bir: ekran/görev çubuğu değiştiyse yeniden yerleş, tam ekran uygulamada
        en üstte durmayı bırak, 'Windows'a uy' temasını takip et."""
        self._ticks += 1
        if self.hidden:
            return
        if not self.fullscreen and time.monotonic() >= self._redock_pause and self.dock.changed():
            now = time.monotonic()
            self._redocks = [t for t in self._redocks if now - t < 60] + [now]
            if len(self._redocks) > 5:  # beklenmedik bir döngü: titremesin, 10 dk ara ver
                self._redock_pause = now + 600
                print("[panel] ekran durumu sürekli değişiyor; otomatik yerleşme 10 dk durduruldu")
            else:
                print("[panel] ekran veya görev çubuğu değişti, yeniden yerleşiliyor")
                self.place()
        own = self.dock.own_hwnd()
        self._fs_app = dock.fullscreen_app_active((own,) if own else ())
        self._update_topmost()  # değişmediyse bir şey yapmaz
        if self.theme_mode == "sistem" and self._ticks % 5 == 0:
            self._apply_theme(only_if_changed=True)
        if self._ticks % 1800 == 0:  # saatte bir
            self._cleanup_shots()

    def _update_topmost(self) -> None:
        # Microsoft: tam ekran uygulama açıkken appbar en üstte durmamalı.
        top = not (self.fullscreen or self._fs_app or self._modal)
        if top != self._topmost:
            self.root.attributes("-topmost", top)
            # Bazı sistemlerde pencere ekranda değilken ayar tutmaz: o zaman sonra tekrar dene.
            self._topmost = top if self.root.winfo_ismapped() else None

    def _on_configure(self, event) -> None:
        if event.widget is self.root:
            self._update_wrap(event.width)

    def _update_wrap(self, width: int) -> None:
        wl = max(120, width - 40)
        for lbl in (self.park_info, self.hist_card, self.footer, self.status):
            lbl.configure(wraplength=wl)
        for lbl in self._notes:  # Ayarlar: çerçeve + kaydırma çubuğu kadar daha dar
            lbl.configure(wraplength=max(100, width - 80))
        self._update_tabs(width)
        self._update_title(width)

    def _update_title(self, width: int) -> None:
        """Başlık sığmıyorsa kırpılmış görünmesin: kısalt ya da gizle."""
        if width < 100:
            return
        if not hasattr(self, "_title_font"):
            self._title_font = tkfont.Font(font=self.title_lbl.cget("font"))
        buttons = sum(w.winfo_reqwidth() + 2 for w in self.title_lbl.master.winfo_children()
                      if w is not self.title_lbl)  # her düğmenin padx=1 iki yanda
        free = width - buttons - 12                # başlığın padx=6 iki yanda
        for text in ("Personal Gnome", "PG", ""):
            if self._title_font.measure(text) <= free:
                break
        if self.title_lbl.cget("text") != text:
            self.title_lbl.config(text=text)

    def _update_tabs(self, width: int) -> None:
        if width < 100:  # daraltılmış şerit
            return
        font = tkfont.nametofont("TkDefaultFont")
        need = sum(font.measure(full) + 22 for full, _ in SEKMELER)
        short = need > width - 12
        if short != self._short_tabs:
            self._short_tabs = short
            for tab, (full, kisa) in zip(self.tabs, SEKMELER):
                self.nb.tab(tab, text=kisa if short else full)

    def toggle_side(self) -> None:
        self.taraf = "sol" if self.taraf == "sag" else "sag"
        core.save_panel_settings(self.taraf, self.pct)
        self.place()

    def resize(self, delta: int) -> None:
        new = max(core.PANEL_MIN, min(core.PANEL_MAX, self.pct + delta))
        if new != self.pct:
            self.pct = new
            core.save_panel_settings(self.taraf, self.pct)
            self.place()
        self.set_status(f"Genişlik: ekranın %{self.pct}'i")

    def toggle_fullscreen(self) -> None:
        self.fullscreen = not self.fullscreen
        self.place()

    def toggle_strip(self) -> None:
        self.strip_mode = not self.strip_mode
        core.set_setting("serit", self.strip_mode)
        self.strip_var.set(self.strip_mode)
        self.expanded = not self.strip_mode   # şerit açılınca önce daralmış başlar
        self.place()
        self.set_status("Şerit modu: fareyi kenara götürünce açılır." if self.strip_mode
                        else "Sabit mod.")

    def _strip_checked(self) -> None:
        if self.strip_var.get() != self.strip_mode:
            self.toggle_strip()

    # ============================================================== gizle / göster (tepsi)
    def on_x(self) -> None:
        if self.tray is not None and getattr(self.tray, "ok", False):
            self.hide()
        else:
            self.close()

    def hide(self) -> None:
        if self.hidden:
            return
        self.hidden = True
        self.root.withdraw()
        self._topmost = None  # tekrar gösterilince yeniden uygulansın
        self.dock.remove()  # gizliyken ekranda yer tutma

    def show(self) -> None:
        if self.hidden:
            self.hidden = False
            self.root.deiconify()
            self.place()
        self.root.lift()

    def toggle_visible(self) -> None:
        if self.hidden:
            self.show()
        else:
            self.hide()

    def set_status(self, text: str, color: str | None = None) -> None:
        self._status_color = color
        if color:
            self.status.config(text=text, bg=color, fg="#000000")
        else:
            self.status.config(text=text, bg=self._normal_bg, fg=self._normal_fg)
        self.strip.config(bg=color or RENK_SERIT)
        if self.tray is not None:
            self.tray.set_state({RENK_KESINTI: "kesinti", RENK_DONUS: "donus"}.get(color, "normal"))

    def _show_now(self) -> None:
        self.nb.select(self.tab_now)
        self.root.lift()

    # ============================================================== not bırakma
    def note_text(self) -> str:
        return self.entry.get("1.0", "end").strip()

    def _on_enter(self, event):
        if event.state & 0x0001:  # Shift+Enter: yeni satır
            return None
        self.save()
        return "break"

    def _job_touched(self) -> None:
        self._job_auto = False

    def bolundum(self) -> None:
        """Panelde 'Bölündüm' düğmesi = not bırakma kısayolu: durum o an dondurulur."""
        self.start_park("diğer", False, "")

    def _capture(self, zaman: float) -> str:
        if not ekran.enabled():
            return ""
        try:
            sw, sh = dock.screen_size(self.root)
            return ekran.capture(self.hwnd_provider(), self.geo, sw, sh, zaman)
        except Exception as exc:
            print(f"[ekran] hata: {exc}")
            return ""

    def start_park(self, tur: str, otomatik: bool, reason: str = "") -> None:
        """Kesinti başladı: o anın durumunu al, not alanını öne çıkar."""
        if (reason.startswith("mikrofon: ") and self.pending is None
                and time.time() - self._last_calendar < TAKVIM_SUSTURMA_SN):
            # Takvim hatırlatmasında zaten not alındı: aynı toplantı için ikinci pencere açma.
            self.set_status("Toplantı başladı (takvim hatırlatmasında not alınmıştı).")
            return
        if self.hidden:
            self.show()
        self.expand()
        self._show_now()
        if self.pending is not None:  # zaten bekleyen bir not var
            self.entry.focus_force()
            return
        kaynak = "takvim" if reason.startswith("takvim: ") else ("toplanti" if otomatik else "kisayol")
        if kaynak == "takvim":
            self._last_calendar = time.time()
        title = self.title_provider()
        repo = core.choose_repo(self.repos, title)
        zaman = time.time()
        snap = lines.snapshot(repo, self.tracker)
        self.pending = {"repo": repo, "snap": snap, "pencere": title, "zaman": zaman,
                        "otomatik": otomatik, "kaynak": kaynak, "ekran": self._capture(zaman)}
        self.job.config(values=isler.job_names())
        onerilen = core.default_job(snap.get("dal", ""))
        if self._job_auto and onerilen:
            self.job.set(onerilen)
        self.tur.set(tur)
        if kaynak == "takvim":
            info = f"Toplantı yaklaşıyor ({reason[len('takvim: '):]}). "
        else:
            info = f"Kesinti algılandı ({reason}). " if reason else ""
        self.park_info.config(text=info + VARSAYILAN_SORU)
        if reason.startswith("mikrofon: "):
            self._ignore_app = reason.split(": ", 1)[1]
            self.ignore_btn.config(text=f"Toplantı değil, {self._ignore_app} yok say")
            self.ignore_btn.pack(fill="x", padx=4, pady=(0, 4))
        esc = "notsuz kaydet" if otomatik else "iptal"
        self.set_status(f"Not bırak: Enter kaydet, Esc {esc}", RENK_KESINTI)
        self.entry.focus_force()

    def save(self, not_metni: str | None = None) -> bool:
        text = self.note_text() if not_metni is None else not_metni
        is_adi = self.job.get().strip()
        p = self.pending
        if p is not None:
            k = core.make_record(p["repo"], text, self.tur.get(), otomatik=p["otomatik"],
                                 snap=p["snap"], pencere=p["pencere"], zaman=p["zaman"],
                                 kaynak=p["kaynak"])
            k.ekran = p["ekran"]
        else:
            if not text:
                self.set_status("Önce bir not yaz.")
                return False
            title = self.title_provider()
            repo = core.choose_repo(self.repos, title)
            snap = lines.snapshot(repo, self.tracker)
            k = core.make_record(repo, text, self.tur.get(), snap=snap, pencere=title, kaynak="kisayol")
            is_adi = is_adi or core.default_job(snap.get("dal", ""))
        k.is_adi = is_adi
        try:
            core.save_record(k)
        except OSError as exc:  # dosya kilitli vb.: not kaybolmasın
            self.set_status(f"Kaydedilemedi, tekrar dene: {str(exc)[:50]}", RENK_KESINTI)
            return False
        adimlar, _ = core.parse_markers(text)
        eklenen = []
        if adimlar:
            try:
                eklenen = isler.add_items(adimlar, is_adi, k.repo)
            except OSError as exc:
                print(f"[işler] adımlar kaydedilemedi: {exc}")
        self._clear_park()
        self._job_auto = True
        self.job.set(is_adi)
        self.set_status("Kaydedildi." + (f" {len(eklenen)} adım İşler'e eklendi." if eklenen else ""))
        self.refresh_all()
        return True

    def _clear_park(self) -> None:
        self._stop_recorder()
        self.pending = None
        self.entry.delete("1.0", "end")
        self.park_info.config(text=VARSAYILAN_SORU)
        self.ignore_btn.pack_forget()
        self.tur.set("diğer")

    def escape(self) -> str:
        p = self.pending
        if p is not None and p["otomatik"]:
            self.save(not_metni="")       # otomatik kesintide durum kaybolmasın
        elif p is not None:
            self._clear_park()
            self.set_status("İptal edildi.")
        else:
            self.entry.delete("1.0", "end")
        return "break"

    def commit_pending(self) -> None:
        """Bekleyen not varsa, yazılmış ne varsa onunla kaydet."""
        if self.pending is not None:
            self.save()

    def _ignore_clicked(self) -> None:
        core.add_ignore(self._ignore_app)
        self._clear_park()
        self.set_status(f"{self._ignore_app} artık toplantı sayılmayacak.")
        self.refresh_settings()

    # ============================================================== sesli not
    def toggle_voice(self) -> None:
        if self.recorder is None:
            rec = voice.Recorder()
            try:
                rec.start()
            except Exception as exc:  # mikrofon yok / izin yok
                self.set_status(f"Mikrofon açılamadı, yazarak devam et. {str(exc)[:50]}")
                return
            self.recorder = rec
            self.mic_btn.config(text="Bitir")
            self.set_status("Dinliyorum... bitince 'Bitir'e bas.", RENK_KESINTI)
            return
        audio = self.recorder.stop()
        self.recorder = None
        self.mic_btn.config(text="Konuş", state="disabled")
        self.set_status("Yazıya çevriliyor... (ilk seferde model yüklenir, biraz sürebilir)")

        def work():
            try:
                text, err = voice.transcribe(audio), ""
            except Exception as exc:  # model/indirme hatası: yazılı nota düş
                text, err = "", str(exc)
            self.events.put(("voice_done", text, err))  # Tkinter'a ana döngüden dokun

        threading.Thread(target=work, daemon=True).start()

    def _voice_done(self, text: str, err: str) -> None:
        if self.mic_btn is not None:
            self.mic_btn.config(state="normal", text="Konuş")
        if text:
            self.entry.delete("1.0", "end")
            self.entry.insert("1.0", text)
            self.set_status("Kontrol et, Enter ile kaydet.", RENK_KESINTI)
        else:
            self.set_status(f"Ses çevrilemedi, yazarak devam et. {err[:50]}")

    def _stop_recorder(self) -> None:
        if self.recorder is not None:
            self.recorder.stop()
            self.recorder = None
            if self.mic_btn is not None:
                self.mic_btn.config(text="Konuş", state="normal")

    # ============================================================== olaylar
    def on_silent(self, tur: str, pencere: str) -> None:
        """Kısayola basılmadan uzaklaşıldı: notsuz kayıt (bekleyen not varsa o kaydedilir)."""
        if self.pending is not None:
            self.commit_pending()
            return
        repo = core.choose_repo(self.repos, pencere)
        zaman = time.time()
        snap = lines.snapshot(repo, self.tracker)
        k = core.make_record(repo, "", tur, otomatik=True, snap=snap, pencere=pencere or None,
                             kaynak="sessiz", zaman=zaman)
        k.is_adi = self.job.get().strip() or core.default_job(snap.get("dal", ""))
        k.ekran = self._capture(zaman)
        core.save_record(k)
        self.refresh_all()

    def show_card(self, reason: str = "") -> None:
        """İşe dönüldü / toplantı bitti / kısayol: kartı göster."""
        if self.hidden:
            self.show()
        self.commit_pending()
        core.mark_return()
        self.refresh_card()
        self._show_now()
        self.expand(hold=KART_ACIK_SN)
        if reason:
            self.set_status(f"{reason[0].upper()}{reason[1:]}: kaldığın yer aşağıda.", RENK_DONUS)

    # ============================================================== yenileme
    def refresh_all(self) -> None:
        for fn in (self.refresh_card, self.refresh_jobs, self.refresh_history,
                   self.refresh_report, self.refresh_settings):
            try:
                fn()
            except Exception as exc:  # bir sekmedeki hata diğerlerini durdurmasın
                print(f"[panel] {fn.__name__} hata: {exc}")

    def card_text(self) -> str:
        return self.card.get("1.0", "end-1c")

    def _set_card(self, text: str) -> None:
        self.card.config(state="normal")
        self.card.delete("1.0", "end")
        self.card.insert("1.0", text)
        self.card.config(state="disabled")

    def _steps_for(self, k: core.Kayit | None) -> list[str]:
        return [i["metin"] for i in isler.open_items(k.is_adi)] if k and k.is_adi else []

    def refresh_card(self) -> None:
        k = core.last_record()
        if k is None:
            text = "Henüz kayıt yok. Not bırakmak için yaz ve Enter'a bas (ya da Bölündüm)."
        else:
            text = core.format_card(k, onceki=core.recent_note(k), zincir=isler.job_chain(k),
                                    adimlar=self._steps_for(k))
        if not self.repos:
            text = "Önce Ayarlar sekmesinden proje klasörü ekle.\n\n" + text
        self._set_card(text)
        self._card_record = k
        self._goto_target = None
        if k and k.dosyalar and k.repo and shutil.which("code"):
            path = Path(k.repo) / k.dosyalar[0]
            if path.is_file():  # olmayan dosyayı code -g yeni dosya olarak açar
                self._goto_target = (path, k.satir)
        self._urls = isler.job_urls(k) if k else []
        for b in (self.goto_btn, self.devam_btn, self.shot_btn, self.md_btn):
            b.pack_forget()
        if self._goto_target:
            self.goto_btn.config(text="Kaldığın satıra git" if self._goto_target[1] else "Dosyayı aç")
            self.goto_btn.pack(fill="x", pady=1)
        if self._urls:
            ek = " + dosya" if self._goto_target else ""
            self.devam_btn.config(text=f"Devam et ({len(self._urls)} bağlantı{ek})")
            self.devam_btn.pack(fill="x", pady=1)
        if k and k.ekran and (ekran.path_for(k.ekran) or time.time() - k.zaman < 120):
            self.shot_btn.pack(fill="x", pady=1)
        if k:
            self.md_btn.pack(fill="x", pady=1)

    def _goto(self) -> None:
        if self._goto_target and not open_in_editor(*self._goto_target):
            self.set_status("VS Code açılamadı (code komutu bulunamadı).")

    def _devam(self) -> None:
        if self._goto_target:
            self._goto()
        for u in self._urls:
            webbrowser.open(u, new=2)
        self.set_status(f"Devam: {len(self._urls)} bağlantı açıldı.")

    def _open_shot(self) -> None:
        k = self._card_record
        p = ekran.path_for(k.ekran) if k and k.ekran else None
        if p is None:
            self.set_status("Ekran görüntüsü bulunamadı (silinmiş olabilir).")
        elif not ekran.open_file(p):
            self.set_status(f"Görüntü: {p}")

    def _copy(self, text: str) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(text)

    def _copy_md(self) -> None:
        k = self._card_record
        if k:
            self._copy(core.markdown_card(k, self._steps_for(k)))
            self.set_status("Kart Markdown olarak kopyalandı.")

    def copy_standup(self) -> None:
        self._copy(isler.standup())
        self.set_status("Standup özeti kopyalandı (Dün / Bugün / Engeller).")

    # --- işler sekmesi
    def _job_filter_value(self, combo: ttk.Combobox) -> str | None:
        """None = tüm işler, '' = iş adı olmayanlar, aksi hâlde iş adı."""
        v = combo.get()
        return None if v in ("", TUM_ISLER) else ("" if v == ISSIZ else v)

    def _set_job_filters(self) -> None:
        names = isler.job_names()
        values = [TUM_ISLER] + names + [ISSIZ]
        for combo in (self.jobs_filter, self.hist_filter):
            combo.config(values=values)
            if combo.get() not in values:
                combo.set(TUM_ISLER)
        self.job.config(values=names)

    def refresh_jobs(self) -> None:
        self._set_job_filters()
        sec = self._job_filter_value(self.jobs_filter)
        items = [i for i in isler.load_items() if sec is None or i["is_adi"] == sec]
        if not self.show_done.get():
            items = [i for i in items if not i["bitti"]]
        items.sort(key=lambda i: (i["bitti"], i["zaman"]))
        self._job_items = items
        self.jobs_list.delete(0, "end")
        for i in items:
            ek = f"  ({i['is_adi']})" if sec is None and i["is_adi"] else ""
            self.jobs_list.insert("end", f"{'[x]' if i['bitti'] else '[ ]'} {i['metin']}{ek}")

    def _selected_step(self) -> dict | None:
        sel = self.jobs_list.curselection()
        return self._job_items[sel[0]] if sel and sel[0] < len(self._job_items) else None

    def _add_step(self) -> None:
        text = self.step_entry.get().strip()
        if not text:
            return
        sec = self._job_filter_value(self.jobs_filter)
        is_adi = sec if sec is not None else self.job.get().strip()
        isler.add_items([text], is_adi)
        self.step_entry.delete(0, "end")
        self.refresh_jobs()
        self.refresh_card()

    def _toggle_step(self) -> None:
        it = self._selected_step()
        if it:
            isler.set_done(it["id"], not it["bitti"])
            self.refresh_jobs()
            self.refresh_card()

    def _delete_step(self) -> None:
        it = self._selected_step()
        if it:
            isler.delete_item(it["id"])
            self.refresh_jobs()
            self.refresh_card()

    def _rename_job(self, new_name: str | None = None) -> None:
        old = self._job_filter_value(self.jobs_filter)
        if not old:
            self.set_status("Önce yukarıdaki listeden bir iş seç.")
            return
        if new_name is None:
            self._modal = True
            self._update_topmost()
            try:
                new_name = simpledialog.askstring("İşi yeniden adlandır", f"'{old}' için yeni ad:",
                                                  initialvalue=old, parent=self.root)
            finally:
                self._modal = False
                self._update_topmost()
        if not new_name or not new_name.strip():
            return
        n = isler.rename_job(old, new_name)
        if self.job.get().strip() == old:
            self.job.set(new_name.strip())
        self.refresh_all()
        self.jobs_filter.set(new_name.strip())
        self.refresh_jobs()
        self.set_status(f"İş adı değişti: {old} -> {new_name.strip()} ({n} kayıt/adım)")

    # --- geçmiş, rapor, ayarlar
    def refresh_history(self) -> None:
        self._set_job_filters()
        sec = self._job_filter_value(self.hist_filter)
        recs = [r for r in reversed(core.load_records()) if sec is None or r.is_adi == sec]
        self._hist_records = recs[:100]
        self.hist.delete(0, "end")
        for r in self._hist_records:
            when = time.strftime("%d.%m %H:%M", time.localtime(r.zaman))
            is_ = f"[{r.is_adi}] " if r.is_adi and sec is None else ""
            self.hist.insert("end", f"{when}  {r.tur}  {is_}{r.not_metni[:40] or '(notsuz)'}")
        self.hist_card.config(text="")

    def _hist_select(self, _event=None) -> None:
        sel = self.hist.curselection()
        if sel:
            r = self._hist_records[sel[0]]
            self.hist_card.config(text=core.format_card(r, zincir=isler.job_chain(r)))

    def refresh_report(self) -> None:
        days = DONEMLER.get(self.donem.get(), 7)
        text = core.report(days) + "\n\n" + icgoru.report(days)
        self.report_text.config(state="normal")
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", text)
        self.report_text.config(state="disabled")

    def refresh_settings(self) -> None:
        self.repo_list.delete(0, "end")
        for r in self.repos:
            self.repo_list.insert("end", r)
        self.ign_list.delete(0, "end")
        for n in core.load_ignore():
            self.ign_list.insert("end", n)
        self.ext_status.config(text=vscode_ext.status())

    def set_calendar_status(self, text: str) -> None:
        self.cal_status.config(text=text or "Takvim bağlı değil.")

    def _add_repo(self, path: str | None = None) -> None:
        if path is None:
            self._modal = True  # klasör seçme penceresi panelin altında kalmasın
            self._update_topmost()
            try:
                path = filedialog.askdirectory(parent=self.root, title="Proje klasörü seç")
            finally:
                self._modal = False
                self._update_topmost()
        if not path:
            return
        if not Path(path).is_dir():
            self.set_status("Klasör bulunamadı.", RENK_KESINTI)
            return
        if path not in self.repos:
            self.repos.append(path)
            if not self.cli_repos:
                core.save_repos(self.repos)
        if core.is_git_repo(path):
            self.set_status(f"Eklendi: {Path(path).name} (git: dosya + satır)")
        else:
            self.set_status(f"Eklendi: {Path(path).name} (git yok: son değişen dosyalar; satır, "
                            "kaydettiğin değişiklikten ya da VS Code eklentisinden)")
        self.refresh_all()

    def _remove_repo(self) -> None:
        sel = self.repo_list.curselection()
        if sel:
            del self.repos[sel[0]]
            if not self.cli_repos:
                core.save_repos(self.repos)
            self.refresh_all()

    def _remove_ignore(self) -> None:
        sel = self.ign_list.curselection()
        if sel:
            core.remove_ignore(self.ign_list.get(sel[0]))
            self.refresh_settings()

    def _autostart_checked(self) -> None:
        want = self.autostart_var.get()
        try:
            baslangic.enable() if want else baslangic.disable()
            self.set_status("Windows açılınca başlayacak." if want else "Otomatik başlatma kapatıldı.")
        except (OSError, ValueError, RuntimeError) as exc:
            self.autostart_var.set(not want)
            self.set_status(f"Ayarlanamadı: {str(exc)[:80]}")

    def _shot_checked(self) -> None:
        core.set_setting("ekran_goruntusu", bool(self.shot_var.get()))
        self.set_status("Ekran görüntüsü " + ("açık." if self.shot_var.get() else "kapalı."))

    def _save_calendar(self) -> None:
        url = self.cal_url.get().strip()
        try:
            dk = max(takvim.DK_MIN, min(takvim.DK_MAX, int(self.cal_dk.get())))
        except ValueError:
            dk = takvim.DK_VARSAYILAN
        self.cal_dk.set(str(dk))
        s = core.load_settings()
        s["takvim_url"], s["takvim_dk"] = url, dk
        core.save_settings(s)
        if self.calendar_watcher is not None:
            self.calendar_watcher.refresh_now()
        self.set_calendar_status("Kaydedildi, takvim okunuyor..." if url else "")
        self.set_status("Takvim ayarı kaydedildi." if url else "Takvim hatırlatması kapatıldı.")

    def _in_background(self, work, done) -> None:
        """work() arka planda çalışır, sonucu done(sonuç) ile arayüz iş parçacığında işlenir."""
        def run():
            try:
                res = work()
            except Exception as exc:
                res = exc
            self.events.put(("ui", lambda: done(res)))
        threading.Thread(target=run, daemon=True).start()

    def _test_calendar(self) -> None:
        url = self.cal_url.get().strip()
        self.set_calendar_status("Test ediliyor...")
        self._in_background(lambda: takvim.test_url(url),
                            lambda res: self.set_calendar_status(str(res)))

    def _install_ext(self) -> None:
        self.ext_status.config(text="Kuruluyor...")

        def done(res):
            ok, msg = res if isinstance(res, tuple) else (False, str(res))
            self.ext_status.config(text=msg)
            self.set_status("VS Code eklentisi kuruldu." if ok else "Eklenti kurulamadı.")
        self._in_background(vscode_ext.install, done)

    def _cleanup_shots(self) -> None:
        try:
            ekran.cleanup()
        except Exception as exc:
            print(f"[ekran] temizlik hatası: {exc}")

    # ============================================================== kapanış
    def close(self) -> None:
        self._closed = True
        for aid in self._after.values():
            try:
                self.root.after_cancel(aid)
            except tk.TclError:
                pass
        self._stop_recorder()
        if self.tray is not None:
            self.tray.stop()
        self.dock.remove()  # ayrılan ekran alanını geri ver
        self.root.destroy()
