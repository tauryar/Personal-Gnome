"""Personal Gnome - giriş noktası (Windows hedefli; .exe olarak paketlenir).

Ekranın kenarında (varsayılan sağ, genişliğin %18'i) yer ayıran bir panel açar.
Kesintiyi dört yoldan yakalar ve panelde not alanını / "kaldığın yer" kartını gösterir:
  1. Toplantı      : bir uygulama mikrofonu kullanmaya başlayınca not alanı öne çıkar
  2. Takvim        : (açıksa) takvimdeki toplantıdan N dk önce
  3. Elle          : Ctrl+Shift+F9, paneldeki "Bölündüm" düğmesi, tepsi menüsü
  4. Unutulursa    : 5 dk boşta kalma veya 15 dk iş uygulaması dışında kalma -> notsuz kayıt
İş uygulamasına dönünce / toplantı bitince kart öne çıkar. Ctrl+Shift+F10 kartı gösterir.
Arka plan iş parçacıkları (izleyici, satır örnekleyici, takvim, tepsi) arayüze doğrudan
dokunmaz; yalnızca olay kuyruğuna yazar (Tkinter iş parçacığı güvenli değildir).

Kaynaktan çalıştırma:  python app.py [--repo C:\\yol\\proje ...]
Sadece komut satırı:   python app.py --rapor | --tani | --paket-testi
"""
from __future__ import annotations

import argparse
import atexit
import queue
import sys
import threading
import time
from pathlib import Path

import core
import icgoru

events: "queue.Queue[tuple]" = queue.Queue()
# izleyicinin gördüğü son iş penceresi (başlık + tanıtıcı; tanıtıcı ekran görüntüsü için)
STATE = {"last_work_title": "", "last_work_hwnd": 0}


# ---------------------------------------------------------------- arka plan izleyici
def monitor(stop: threading.Event, use_meeting: bool, idle_limit: float,
            other_limit: float = 15 * 60, clock=time.time) -> None:
    """Durumlar: çalışıyor / uzakta. Uzaklaşma üç yoldan başlar: toplantı (mikrofon),
    boşta kalma (bilgisayardan kalktın), başka uygulamada uzun süre (başka işe geçtin).
    Uzaklık, iş uygulamasına dönünce biter -> kart."""
    in_meeting = False
    away = False
    last_work: float | None = None
    last_work_title = ""
    prev: float | None = None
    while not stop.wait(3):
        try:
            now = clock()
            # İçgörü için: iki tur arası geçen süre (uyku/askı sonrası sıçramalar sayılmaz)
            gecen = 0.0 if prev is None else max(0.0, min(now - prev, 10.0))
            prev = now
            reason = core.detect_meeting() if use_meeting else None
            if reason and not in_meeting:
                events.put(("park", "toplantı", True, reason))
            elif not reason and in_meeting:
                away = False
                events.put(("card", "toplantı bitti"))
            in_meeting = bool(reason)
            if in_meeting:
                # Toplantıda dinlerken boşta kalmak ayrı kesinti sayılmaz.
                away = False
                continue

            idle = core.idle_seconds()
            exe, title = core.foreground_app()
            kind = core.app_kind(exe)
            if kind == "work":
                last_work, last_work_title = now, title
                STATE["last_work_title"] = title
                STATE["last_work_hwnd"] = core.foreground_hwnd()
                if idle < 60:  # iş uygulaması önde ve kullanılıyor: çalışma süresi
                    icgoru.ACTIVITY.add(gecen, now)

            if not away:
                if idle > idle_limit:
                    away = True  # kısayola basmayı unutup kalktın: notsuz kayıt
                    events.put(("silent", "mola", title if kind == "work" else last_work_title))
                elif kind == "other" and last_work is not None and now - last_work > other_limit:
                    away = True  # bilgisayarda başka işe geçtin (mesajlaşma, tarayıcı...)
                    events.put(("silent", "başka uygulama", last_work_title))
            elif idle < 5 and kind in ("work", "unknown"):
                away = False  # iş uygulamasına döndün (exe bilinmiyorsa ilk harekette)
                events.put(("card", "geri döndün"))
        except Exception as exc:  # tek bir hata izleyiciyi kalıcı olarak durdurmasın
            print(f"[izleyici] hata, devam ediliyor: {exc}")


def context_title() -> str:
    """Kaydın 'aktif pencere'si: son iş penceresi (panelin kendisi değil)."""
    return STATE["last_work_title"] or core.active_window_title()


# ---------------------------------------------------------------- olaylar -> panel
def handle_event(panel, ev: tuple) -> None:
    kind = ev[0]
    if kind == "park":
        panel.start_park(ev[1], ev[2], ev[3])
    elif kind == "silent":
        panel.on_silent(ev[1], ev[2])
    elif kind == "card":
        panel.show_card(ev[1])
    elif kind == "voice_done":
        panel._voice_done(ev[1], ev[2])
    elif kind == "ui":            # arka plan işinin sonucu: arayüz iş parçacığında çalıştır
        ev[1]()
    elif kind == "cal_status":
        panel.set_calendar_status(ev[1])
    elif kind == "tray":
        action = ev[1]
        if action == "toggle":
            panel.toggle_visible()
        elif action == "park":
            panel.bolundum()
        elif action == "card":
            panel.show_card("")
        elif action == "strip":
            panel.show()
            panel.toggle_strip()
        elif action == "quit":
            panel.close()


def process_events(panel) -> None:
    """Kuyruktaki olayları işle; biri hata verirse diğerleri yine işlenir."""
    while not events.empty():
        ev = events.get()
        try:
            handle_event(panel, ev)
        except Exception as exc:
            print(f"[olay {ev[0]}] hata, devam ediliyor: {exc}")


# ---------------------------------------------------------------- yardımcılar
def diagnose() -> None:
    """Windows'ta algılamanın gerçekten çalışıp çalışmadığını görmek için."""
    print("Tanı modu (Ctrl+C ile çık). Bir toplantıya/aramaya gir ve çıktıyı izle.")
    try:
        while True:
            exe, _ = core.foreground_app()
            print(time.strftime("%H:%M:%S"),
                  "| mikrofon:", core.mic_in_use_apps() or "-",
                  "| boşta sn:", round(core.idle_seconds()),
                  "| ön plan:", exe or "?", f"({core.app_kind(exe)})",
                  "| karar:", core.detect_meeting() or "toplantı yok")
            titles = [t for t in core.window_titles() if t.strip()]
            print("   pencereler:", titles[:8])
            time.sleep(3)
    except KeyboardInterrupt:
        pass


def enable_dpi_awareness() -> str:
    """Ekran ölçeklendirmesi (ör. %125) açıkken koordinatlar tutarlı olsun.

    Varsayılan "DPI'dan habersiz" süreçte Tk pencere ölçüleri ölçeklenmiş birimlerle
    çalışırken, ekranda ayrılacak alan Windows'a bu birimlerle bildirilir ve gerçek piksel
    olarak yorumlanabilir: ayrılan alan panelden geniş olur, arada boşluk kalır.
    Sistem DPI farkındalığı ile her şey gerçek pikselle çalışır. Herhangi bir pencere
    veya ekran ölçüsü okunmadan ÖNCE çağrılmalı."""
    if sys.platform != "win32":
        return "Windows değil"
    import ctypes
    try:
        hr = ctypes.windll.shcore.SetProcessDpiAwareness(1)  # PROCESS_SYSTEM_DPI_AWARE
        return f"SetProcessDpiAwareness(1) sonucu {hr} (0 = başarılı)"
    except (AttributeError, OSError):
        try:  # Windows 8.1 öncesi
            return f"SetProcessDPIAware sonucu {ctypes.windll.user32.SetProcessDPIAware()}"
        except (AttributeError, OSError) as exc:
            return f"DPI farkındalığı ayarlanamadı: {exc}"


def package_check() -> str:
    """Paketlenmiş .exe'de bütün bileşenlerin yüklendiğini doğrula (ağ gerektirmez)."""
    satirlar = []
    hata = False

    def dene(ad, fn):
        nonlocal hata
        try:
            satirlar.append(f"  {ad}: {fn()}")
        except Exception as exc:
            hata = True
            satirlar.append(f"  {ad}: HATA - {exc}")

    def ses():
        import voice
        return voice.self_check()

    def takvim_test():
        import importlib.resources
        import zoneinfo

        import takvim
        # Windows'ta sistem saat dilimi veritabanı yok: tzdata paketi exe'nin içinde olmalı.
        if not importlib.resources.files("tzdata.zoneinfo").joinpath("Europe", "Istanbul").is_file():
            raise FileNotFoundError("tzdata saat dilimi verisi pakette yok (--collect-data tzdata)")
        zoneinfo.ZoneInfo("Europe/Istanbul")
        data = (b"BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//t//t//EN\r\nBEGIN:VEVENT\r\n"
                b"UID:1\r\nSUMMARY:t\r\nDTSTART;TZID=Europe/Istanbul:20300101T100000\r\n"
                b"RRULE:FREQ=DAILY\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")
        n = len(takvim.upcoming(data, 1893488400.0))  # 2030-01-01 10:00 +03 civarı
        return f"tamam ({n} etkinlik, saat dilimi verisi var)"

    def tepsi():
        import tray
        if tray._logo() is None:
            raise FileNotFoundError("assets/logo.png pakette yok")
        tray.make_image("kesinti")
        if sys.platform == "win32":
            import pystray
            return f"tamam (pystray {pystray.Icon.__module__})"
        return "tamam (simge çizimi; tepsi yalnızca Windows'ta)"

    def eklenti():
        import vscode_ext
        p = vscode_ext.bundled_vsix()
        if p is None:
            raise FileNotFoundError("personal-gnome-vscode.vsix pakette yok")
        return f"tamam ({p.name}, {p.stat().st_size} bayt)"

    def ekran_():
        from PIL import ImageGrab  # noqa: F401
        return "tamam (Pillow ImageGrab)"

    dene("Sesli not", ses)
    dene("Takvim", takvim_test)
    dene("Tepsi", tepsi)
    dene("VS Code eklentisi", eklenti)
    dene("Ekran görüntüsü", ekran_)
    return ("Paket testi: " + ("HATA" if hata else "tamam") + "\n" + "\n".join(satirlar))


def redirect_output_if_windowed() -> None:
    """.exe konsolsuz çalışınca çıktı ve hatalar günlük dosyasına yazılsın."""
    if sys.stdout is None or sys.stderr is None:
        log = open(core._data_dir() / "gunluk.txt", "a", encoding="utf-8", buffering=1)
        if sys.stdout is None:
            sys.stdout = log
        if sys.stderr is None:
            sys.stderr = log


# ---------------------------------------------------------------- ana döngü
def main(argv: list[str] | None = None) -> None:
    redirect_output_if_windowed()
    ap = argparse.ArgumentParser(description="Personal Gnome")
    ap.add_argument("--repo", nargs="+", default=None,
                    help="İzlenecek git depo(ları). Verilmezse panelin Ayarlar sekmesindekiler kullanılır")
    ap.add_argument("--park-key", default="<ctrl>+<shift>+<f9>")
    ap.add_argument("--card-key", default="<ctrl>+<shift>+<f10>")
    ap.add_argument("--idle-dk", type=float, default=5, help="Kaç dk boşta kalınca notsuz kayıt alınsın")
    ap.add_argument("--baska-is-dk", type=float, default=15,
                    help="İş uygulaması dışında kaç dk kalınca notsuz kayıt alınsın")
    ap.add_argument("--toplanti-yok", action="store_true", help="Toplantı algılamayı kapat")
    ap.add_argument("--rapor", type=float, nargs="?", const=7, default=None, metavar="GÜN",
                    help="Son GÜN günün kesinti raporunu yazdır ve çık (varsayılan 7)")
    ap.add_argument("--tani", action="store_true",
                    help="Tanı modu: mikrofon, ön plandaki uygulama ve pencere başlıklarını yazdır")
    ap.add_argument("--ses-testi", action="store_true",
                    help="Sesli not bileşenlerinin yüklendiğini kontrol et ve çık")
    ap.add_argument("--paket-testi", action="store_true",
                    help="Paketlenmiş bütün bileşenleri (ses, takvim, tepsi, eklenti) kontrol et ve çık")
    args = ap.parse_args(argv)

    if args.paket_testi:
        text = package_check()
        print(text)
        try:  # build.bat ve GitHub iş akışı sonucu bu dosyadan okur (üzerine yazılır)
            (core._data_dir() / "paket_testi.txt").write_text(text, encoding="utf-8")
        except OSError:
            pass
        return
    if args.ses_testi:
        import voice
        try:
            print(voice.self_check())
        except Exception as exc:
            print(f"Sesli not: HATA - {exc}")
        return
    if args.rapor is not None:
        print(core.report(args.rapor))
        return
    if args.tani:
        diagnose()
        return

    repos = args.repo if args.repo is not None else core.load_repos()
    for r in repos:
        if not Path(r).is_dir():
            print(f"UYARI: {r} klasörü bulunamadı.")
        elif not core.is_git_repo(r):
            print(f"BİLGİ: {Path(r).resolve()} git deposu değil; son değişen dosyalar gösterilecek, "
                  "satır kaydettiğin değişiklikten veya VS Code eklentisinden alınır.")

    dpi = enable_dpi_awareness()  # Tk penceresi oluşmadan önce
    import tkinter as tk
    from pynput import keyboard

    import baslangic
    import lines
    import panel as panel_mod
    import takvim
    import tray as tray_mod

    msg = baslangic.refresh()  # exe taşındıysa başlangıç kaydındaki yolu güncelle
    if msg:
        print(f"[başlangıç] {msg}")

    root = tk.Tk()
    p = panel_mod.Panel(root, repos, events, args.park_key, args.card_key,
                        cli_repos=args.repo is not None, title_provider=context_title,
                        hwnd_provider=lambda: STATE["last_work_hwnd"])
    print(f"[ekran] {dpi}; ekran {root.winfo_screenwidth()}x{root.winfo_screenheight()}; "
          f"panel (x, y, genişlik, yükseklik) = {p.geo}; yer ayırma: "
          f"{'evet' if p.dock.registered else 'hayır ' + p.dock.last_error}")
    atexit.register(p.dock.remove)  # ne olursa olsun ayrılan ekran alanı geri verilsin
    atexit.register(icgoru.ACTIVITY.flush)
    # Konuşma modeli açılışta yüklenmez: ilk "Konuş"ta yüklenir (gün boyu bellek tutmasın).

    tray = tray_mod.Tray(events)
    if tray.ok:
        p.tray = tray
        tray.start()
    else:
        print(f"[tepsi] yok: {tray.error} (X düğmesi uygulamayı kapatır)")

    hotkeys = keyboard.GlobalHotKeys({
        args.park_key: lambda: events.put(("park", "diğer", False, "")),
        args.card_key: lambda: events.put(("card", "")),
    })
    hotkeys.start()

    stop = threading.Event()
    threading.Thread(target=monitor,
                     args=(stop, not args.toplanti_yok, args.idle_dk * 60, args.baska_is_dk * 60),
                     daemon=True).start()
    # Git'siz klasörde ve git'te ikinci düzenlemeden sonra satır bilgisi için dosya kopyaları
    threading.Thread(target=lines.sampler, args=(stop, lambda: p.repos), daemon=True).start()
    watcher = takvim.Watcher(events)
    p.calendar_watcher = watcher
    threading.Thread(target=watcher.run, args=(stop,), daemon=True).start()

    def pump():
        try:
            process_events(p)
        finally:
            try:
                root.after(200, pump)  # her koşulda yeniden planla: döngü asla durmasın
            except tk.TclError:
                pass  # pencere kapandı (Çıkış)

    print("Personal Gnome çalışıyor. Depo(lar): " + (", ".join(repos) or "(Ayarlar sekmesinden ekle)"))
    root.after(200, pump)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        hotkeys.stop()
        p.dock.remove()
        tray.stop()
        icgoru.ACTIVITY.flush()


if __name__ == "__main__":
    main()
