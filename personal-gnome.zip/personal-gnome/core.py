"""Personal Gnome - çekirdek.

Anlık görüntü (git + aktif pencere), kayıt (JSON), toplantı algılama,
boşta kalma süresi ve dönüş kartı metni. Tkinter'a bağımlı değildir,
bu yüzden tek başına test edilebilir.
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

IS_WINDOWS = sys.platform == "win32"

# Pencere başlığıyla toplantı algılama için doğrulanmış bir başlık biçimi bulunamadı;
# tahmini kalıplar yanlış tetiklediği için (ör. "meet.py - VS Code") varsayılan boş.
# Windows'ta `python app.py --tani` ile gerçek başlıkları gör, gerekirse
# ayarlar.json içine "pencere_kaliplari": ["..."] olarak ekle.
MEETING_TITLE_PATTERNS: list[str] = []
# Mikrofon kullanan bu uygulamalar toplantı sayılmaz (kendi sesli notumuz vb.).
MIC_IGNORE = ("python", "kaldigim", "personalgnome")

TURLER = ["toplantı", "mesaj", "soru", "mola", "diğer"]

# Ön plandaki pencerenin uygulaması (exe adı) bunlardan biriyse "çalışıyorsun" sayılır.
# ayarlar.json -> "calisma_uygulamalari": [...] ile eklenebilir (ör. "blender.exe").
DEFAULT_WORK_APPS = [
    "code.exe", "cursor.exe", "windowsterminal.exe", "powershell.exe", "pwsh.exe",
    "cmd.exe", "conhost.exe", "godot*.exe", "idea64.exe", "pycharm64.exe",
    "rider64.exe", "webstorm64.exe", "devenv.exe", "unity.exe",
]
# Kendi pencerelerimiz: ne iş ne başka iş sayılır.
NEUTRAL_APPS = ["python*.exe", "pythonw*.exe", "kaldigim*.exe", "personalgnome*.exe"]


# ---------------------------------------------------------------- kayıt
def _data_dir() -> Path:
    base = Path(os.environ.get("KALDIGIM_YER_DIR", Path.home() / ".kaldigim_yer"))
    base.mkdir(parents=True, exist_ok=True)
    return base


def data_file() -> Path:
    return _data_dir() / "kayitlar.json"


# ---------------------------------------------------------------- yok sayma listesi
def _settings_file() -> Path:
    return _data_dir() / "ayarlar.json"


def _atomic_write(path: Path, text: str) -> None:
    """Yazarken çökme olursa dosya bozulmasın: önce geçici dosya, sonra yer değiştir."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    # Windows'ta antivirüs/eşitleme dosyayı anlık kilitleyebilir: birkaç kez dene.
    for attempt in range(5):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == 4:
                raise
            time.sleep(0.1)


def load_settings() -> dict:
    try:
        data = json.loads(_settings_file().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def save_settings(settings: dict) -> None:
    _atomic_write(_settings_file(), json.dumps(settings, ensure_ascii=False, indent=2))


def get_setting(key: str, default=None):
    return load_settings().get(key, default)


def set_setting(key: str, value) -> None:
    settings = load_settings()
    settings[key] = value
    save_settings(settings)


def load_json(name: str, default):
    """Veri klasöründeki bir JSON dosyasını oku; yoksa/bozuksa varsayılanı döndür."""
    try:
        data = json.loads((_data_dir() / name).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default
    return data if isinstance(data, type(default)) else default


def save_json(name: str, data) -> None:
    _atomic_write(_data_dir() / name, json.dumps(data, ensure_ascii=False, indent=2))


PANEL_MIN, PANEL_MAX, PANEL_DEFAULT = 15, 20, 18  # ekran genişliğinin yüzdesi


def panel_settings(settings: dict | None = None) -> tuple[str, int]:
    """(taraf, genişlik yüzdesi). Taraf 'sag'/'sol', genişlik 15-20 arasına sıkıştırılır."""
    settings = load_settings() if settings is None else settings
    p = settings.get("panel") if isinstance(settings.get("panel"), dict) else {}
    taraf = "sol" if p.get("taraf") == "sol" else "sag"
    try:
        pct = int(p.get("genislik", PANEL_DEFAULT))
    except (TypeError, ValueError):
        pct = PANEL_DEFAULT
    return taraf, max(PANEL_MIN, min(PANEL_MAX, pct))


def save_panel_settings(taraf: str, pct: int) -> None:
    settings = load_settings()
    settings["panel"] = {"taraf": taraf, "genislik": max(PANEL_MIN, min(PANEL_MAX, int(pct)))}
    save_settings(settings)


def load_repos() -> list[str]:
    return [str(r) for r in load_settings().get("depolar", []) if str(r).strip()]


def save_repos(repos: list[str]) -> None:
    settings = load_settings()
    settings["depolar"] = list(dict.fromkeys(repos))  # sırayı koru, tekrarı at
    save_settings(settings)


def load_ignore() -> list[str]:
    return [str(n).lower() for n in load_settings().get("yok_say", [])]


def add_ignore(app_name: str) -> None:
    """Toplantı sanılan uygulamayı (ör. gün boyu açık Discord) kalıcı olarak yok say."""
    settings = load_settings()
    names = load_ignore()
    if app_name.lower() not in names:
        names.append(app_name.lower())
    settings["yok_say"] = names
    save_settings(settings)


def remove_ignore(app_name: str) -> None:
    settings = load_settings()
    settings["yok_say"] = [n for n in load_ignore() if n != app_name.lower()]
    save_settings(settings)


@dataclass
class Kayit:
    zaman: float
    not_metni: str
    tur: str
    repo: str
    dal: str = ""
    diff_ozet: str = ""
    dosyalar: list[str] = field(default_factory=list)
    satir: int = 1          # ilk dosyada değişikliğin başladığı satır (0 = bilinmiyor)
    pencere: str = ""
    otomatik: bool = False
    kaynak: str = ""        # "kisayol" (elle) | "toplanti" | "takvim" | "sessiz"
    git_deposu: bool = True  # False: git'siz klasör (dosyalar değişiklik zamanından)
    donus: float = 0.0      # işe dönüş zamanı (rapor için; 0 = bilinmiyor)
    # --- 2. sürüm alanları (eski kayıtlarda yoktur, varsayılanlar kullanılır)
    satir_kaynak: str = ""  # "vscode" | "kopya" | "git" | "" (satır bilinmiyor)
    is_adi: str = ""        # iş zinciri adı
    ekran: str = ""         # ekran görüntüsü dosya adı (ekranlar/ klasöründe)


def load_records() -> list[Kayit]:
    f = data_file()
    if not f.exists():
        return []
    try:
        raw = json.loads(f.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    if not isinstance(raw, list):
        return []
    known = set(Kayit.__dataclass_fields__)
    out = []
    for r in raw:
        try:
            out.append(Kayit(**{a: v for a, v in r.items() if a in known}))
        except (TypeError, AttributeError):  # elle bozulmuş tek kayıt hepsini düşürmesin
            continue
    return out


def save_records(records: list[Kayit]) -> None:
    _atomic_write(data_file(),
                  json.dumps([asdict(r) for r in records[-200:]], ensure_ascii=False, indent=2))


def save_record(k: Kayit) -> None:
    records = load_records()
    records.append(k)
    save_records(records)


def last_record() -> Kayit | None:
    records = load_records()
    return records[-1] if records else None


def update_record(zaman: float, **fields) -> bool:
    """zaman damgasıyla bulunan kaydın alanlarını güncelle."""
    records = load_records()
    for r in reversed(records):
        if r.zaman == zaman:
            for a, v in fields.items():
                setattr(r, a, v)
            save_records(records)
            return True
    return False


def mark_return(now: float | None = None, min_gap: float = 30) -> None:
    """Son kayda işe dönüş zamanını yaz (kayıttan hemen sonra karta bakmak dönüş sayılmaz)."""
    now = time.time() if now is None else now
    k = last_record()
    if k and not k.donus and now - k.zaman >= min_gap:
        update_record(k.zaman, donus=now)


def recent_note(k: Kayit, max_age: float = 4 * 3600) -> Kayit | None:
    """k notsuzsa: aynı depodaki, max_age içindeki en son notlu kayıt."""
    if k.not_metni:
        return None
    for r in reversed(load_records()):
        if r.zaman < k.zaman - max_age:
            break
        if r.not_metni and r.repo == k.repo and r.zaman <= k.zaman:
            return r
    return None


# ---------------------------------------------------------------- git
def _git(repo: str, *args: str) -> str:
    # .exe olarak paketlenince her git çağrısında konsol penceresi yanıp sönmesin.
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if IS_WINDOWS else 0
    try:
        out = subprocess.run(
            ["git", "-C", repo, *args],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=5, creationflags=flags,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    # Sadece sağdan kırp: porcelain satırları boşlukla başlayabilir (" M dosya").
    return out.stdout.rstrip() if out.returncode == 0 else ""


def git_snapshot(repo: str, max_files: int = 5) -> dict:
    """Proje klasörünün anlık görüntüsü.
    Git deposuysa: dal, değişiklik özeti, değişmiş dosyalar ve ilk değişen satır.
    Git deposu değilse: değişiklik zamanına göre en son değiştirilen dosyalar (satır bilinmez)."""
    if not repo:  # henüz proje seçilmedi
        return {"dal": "", "diff_ozet": "", "dosyalar": [], "satir": 0, "git_deposu": False,
                "satir_kaynak": ""}
    if not is_git_repo(repo):
        paths = [p for _, p in _folder_files(repo)[:max_files]]
        return {"dal": "", "diff_ozet": "", "dosyalar": paths, "satir": 0, "git_deposu": False,
                "satir_kaynak": ""}
    dal = _git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    diff_ozet = _git(repo, "diff", "--shortstat", "HEAD").strip()
    dosyalar = _git_changed_files(repo)
    paths = [p for _, p in dosyalar[:max_files]]
    satir = first_changed_line(repo, paths[0]) if paths else 0
    return {
        "dal": dal,
        "diff_ozet": diff_ozet,
        "dosyalar": paths,
        "satir": satir,
        "git_deposu": True,
        "satir_kaynak": "git" if satir else "",
    }


# Git'siz klasör taramasında atlananlar: araçların ürettiği klasör ve dosyalar.
# Noktayla başlayan klasörler (.git, .godot, .vs, .idea, .venv ...) her zaman atlanır.
HARIC_KLASORLER = {"node_modules", "__pycache__", "venv", "env", "library", "temp", "logs",
                   "obj", "bin", "build", "dist", "out", "target"}
HARIC_UZANTILAR = {".log", ".tmp", ".pyc", ".pyo", ".import", ".uid", ".meta", ".swp"}


def _folder_files(folder: str, max_entries: int = 50_000,
                  time_limit: float = 2.0) -> list[tuple[float, str]]:
    """Git'siz klasörde dosyalar, en son değiştirilen önce: [(mtime, göreli yol)]."""
    extra = {str(d).lower() for d in load_settings().get("haric_klasorler", [])}
    haric = HARIC_KLASORLER | extra
    start, seen, out = time.monotonic(), 0, []
    for dirpath, dirnames, filenames in os.walk(folder):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d.lower() not in haric]
        for name in filenames:
            seen += 1
            if Path(name).suffix.lower() in HARIC_UZANTILAR:
                continue
            full = Path(dirpath) / name
            try:
                out.append((full.stat().st_mtime, full.relative_to(folder).as_posix()))
            except OSError:
                continue
        if seen > max_entries or time.monotonic() - start > time_limit:
            break  # çok büyük klasörde arayüzü bekletme
    out.sort(reverse=True)
    return out


def _changed_files(repo: str) -> list[tuple[float, str]]:
    """Git deposunda değişmiş dosyalar, değilse klasördeki son değiştirilenler."""
    if not repo:
        return []
    return _git_changed_files(repo) if is_git_repo(repo) else _folder_files(repo)


def _git_changed_files(repo: str) -> list[tuple[float, str]]:
    """Değişmiş ve hâlâ var olan dosyalar, en son dokunulan önce: [(mtime, yol)]."""
    # -z: yollar kaçış koduna çevrilmez (Türkçe adlar bozulmaz), NUL ile ayrılır.
    # --untracked-files=all: yeni klasördeki dosyalar tek tek listelenir.
    porcelain = _git(repo, "status", "--porcelain", "-z", "--untracked-files=all")
    tokens = porcelain.split("\0")
    dosyalar = []
    i = 0
    while i < len(tokens):
        entry = tokens[i]
        i += 1
        if len(entry) < 4:
            continue
        status, path = entry[:2], entry[3:]
        if "R" in status or "C" in status:
            i += 1  # yeniden adlandırmada sonraki parça eski ad
        full = Path(repo) / path
        if full.is_file():  # silinmiş dosyaya "satıra git" yapılmasın
            dosyalar.append((full.stat().st_mtime, path))
    dosyalar.sort(reverse=True)
    return dosyalar


def choose_repo(repos: list[str], title: str = "") -> str:
    """Birden fazla depo varsa: adı pencere başlığında geçen, yoksa en son değişiklik yapılan."""
    if not repos:
        return ""
    if len(repos) == 1:
        return repos[0]
    t = (title or "").lower()
    named = []
    for r in repos:
        name = Path(r).resolve().name.lower()
        if name and re.search(r"(?<![\w-])" + re.escape(name) + r"(?![\w-])", t):
            named.append((len(name), r))
    if named:
        return max(named)[1]  # en uzun (en belirgin) ad
    latest = [(files[0][0] if files else -1.0, i) for i, r in enumerate(repos)
              for files in [_changed_files(r)]]
    return repos[max(latest)[1]] if max(latest)[0] >= 0 else repos[0]


def first_changed_line(repo: str, path: str) -> int:
    """Dosyadaki ilk değişiklik bloğunun yeni sürümdeki satırı (izlenmeyen dosyada 1)."""
    out = _git(repo, "diff", "-U0", "HEAD", "--", path)
    m = re.search(r"^@@ -\d+(?:,\d+)? \+(\d+)", out, re.MULTILINE)
    return max(int(m.group(1)), 1) if m else 1


# ---------------------------------------------------------------- Windows sinyalleri
def active_window_title() -> str:
    if not IS_WINDOWS:
        return ""
    import ctypes
    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def foreground_hwnd() -> int:
    """Ön plandaki pencerenin tanıtıcısı (ekran görüntüsü için). Windows dışında 0."""
    if not IS_WINDOWS:
        return 0
    import ctypes
    return int(ctypes.windll.user32.GetForegroundWindow() or 0)


def foreground_app() -> tuple[str, str]:
    """Ön plandaki pencerenin (exe adı küçük harf, başlık). Windows dışında ("", "")."""
    if not IS_WINDOWS:
        return "", ""
    import ctypes
    from ctypes import wintypes
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return "", ""
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    exe = ""
    handle = kernel32.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
    if handle:
        try:
            buf = ctypes.create_unicode_buffer(1024)
            size = wintypes.DWORD(1024)
            if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                exe = Path(buf.value.replace("\\", "/")).name.lower()
        finally:
            kernel32.CloseHandle(handle)
    return exe, active_window_title()


def app_kind(exe: str, settings: dict | None = None) -> str:
    """'work' | 'neutral' | 'other' | 'unknown' (exe bilinmiyorsa)."""
    if not exe:
        return "unknown"
    settings = load_settings() if settings is None else settings
    work = DEFAULT_WORK_APPS + [str(p).lower() for p in settings.get("calisma_uygulamalari", [])]
    if any(fnmatch.fnmatch(exe, p) for p in NEUTRAL_APPS):
        return "neutral"
    if any(fnmatch.fnmatch(exe, p) for p in work):
        return "work"
    return "other"


def idle_seconds() -> float:
    """Son klavye/fare hareketinden beri geçen süre (sadece Windows)."""
    if not IS_WINDOWS:
        return 0.0
    import ctypes

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    lii = LASTINPUTINFO()
    lii.cbSize = ctypes.sizeof(lii)
    ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
    now = ctypes.windll.kernel32.GetTickCount() & 0xFFFFFFFF
    return ((now - lii.dwTime) & 0xFFFFFFFF) / 1000.0


def window_titles() -> list[str]:
    if not IS_WINDOWS:
        return []
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    titles: list[str] = []
    proc_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                titles.append(buf.value)
        return True

    user32.EnumWindows(proc_type(cb), 0)
    return titles


def mic_in_use_apps() -> list[str]:
    """Mikrofonu şu an kullanan uygulamalar.

    Windows, HKCU\\...\\ConsentStore\\microphone altında uygulama başına
    LastUsedTimeStop tutar; 0 ise uygulama mikrofonu hâlâ kullanıyordur
    (bu kural kamera anahtarı için belgelenmiş; mikrofon anahtarı aynı
    yapıda, Windows'ta ilk saatte doğrula).
    Masaüstü uygulamaları NonPackaged alt anahtarındadır, bu yüzden
    iki seviye taranır.
    """
    if not IS_WINDOWS:
        return []
    import winreg
    base = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone"
    found: list[str] = []

    def walk(path: str, depth: int) -> None:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path)
        except OSError:
            return
        with key:
            if depth > 0:
                try:
                    start, _ = winreg.QueryValueEx(key, "LastUsedTimeStart")
                    stop, _ = winreg.QueryValueEx(key, "LastUsedTimeStop")
                    if start and stop == 0:
                        found.append(path.rsplit("\\", 1)[-1].replace("#", "\\"))
                except OSError:
                    pass
            i = 0
            while depth < 2:
                try:
                    sub = winreg.EnumKey(key, i)
                except OSError:
                    break
                walk(path + "\\" + sub, depth + 1)
                i += 1

    walk(base, 0)
    return found


def is_git_repo(repo: str) -> bool:
    return _git(repo, "rev-parse", "--is-inside-work-tree") == "true"


def detect_meeting(mic_apps: list[str] | None = None,
                   titles: list[str] | None = None) -> str | None:
    """Toplantı varsa nedenini döndürür, yoksa None."""
    mic_apps = mic_in_use_apps() if mic_apps is None else mic_apps
    titles = window_titles() if titles is None else titles
    settings = load_settings()
    ignore = load_ignore()
    for app in mic_apps:
        name = Path(app.replace(chr(92), "/")).name
        if any(s in app.lower() for s in MIC_IGNORE) or name.lower() in ignore:
            continue
        return f"mikrofon: {name}"
    patterns = MEETING_TITLE_PATTERNS + [str(p) for p in settings.get("pencere_kaliplari", [])]
    for t in titles:
        for pat in patterns:
            try:
                if re.search(pat, t, re.IGNORECASE):
                    return f"pencere: {t[:60]}"
            except re.error:  # ayarlara elle yazılmış hatalı kalıp algılamayı durdurmasın
                continue
    return None


# ---------------------------------------------------------------- kayıt oluşturma + kart
def make_record(repo: str, not_metni: str, tur: str, otomatik: bool = False,
                snap: dict | None = None, pencere: str | None = None, kaynak: str = "",
                zaman: float | None = None) -> Kayit:
    snap = git_snapshot(repo) if snap is None else snap
    return Kayit(
        zaman=time.time() if zaman is None else zaman,
        not_metni=not_metni.strip(),
        tur=tur,
        repo=str(Path(repo).resolve()) if repo else "",
        pencere=active_window_title() if pencere is None else pencere,
        otomatik=otomatik,
        kaynak=kaynak,
        **snap,
    )


def sure_metni(saniye: float) -> str:
    dk = int(saniye // 60)
    if dk < 1:
        return "1 dakikadan az"
    if dk < 60:
        return f"{dk} dk"
    return f"{dk // 60} sa {dk % 60} dk"


def _ne_zaman(saniye: float) -> str:
    return "Az önce" if saniye < 60 else f"{sure_metni(saniye)} önce"


SATIR_ETIKET = {"vscode": "imleç, VS Code", "kopya": "son kaydedilen değişiklik",
                "git": "ilk değişiklik, git"}


def satir_metni(k: Kayit) -> str:
    """'  (satır 42 - imleç, VS Code)'; satır bilinmiyorsa boş."""
    if not k.satir:
        return ""
    etiket = SATIR_ETIKET.get(k.satir_kaynak)
    return f"  (satır {k.satir} - {etiket})" if etiket else f"  (satır {k.satir})"


def format_card(k: Kayit, now: float | None = None, onceki: Kayit | None = None,
                zincir: list[Kayit] | None = None, adimlar: list[str] | None = None) -> str:
    """Kaldığın yer kartı. zincir: aynı işteki önceki notlu kayıtlar (yeniden eskiye),
    adimlar: bu işin açık 'sıradaki' adımları."""
    now = time.time() if now is None else now
    if k.not_metni:
        not_satiri = f"  {k.not_metni}"
    elif onceki:
        not_satiri = f"  {onceki.not_metni}   ({_ne_zaman(now - onceki.zaman).lower()} bıraktığın not)"
    else:
        not_satiri = "  (not bırakılmadı)"
    satirlar = [
        f"{_ne_zaman(now - k.zaman)} ayrıldın ({k.tur})",
        "",
        "NE DÜŞÜNÜYORDUN:",
        not_satiri,
    ]
    if adimlar:
        satirlar.append("Sıradaki adımlar:")
        satirlar += [f"  [ ] {a}" for a in adimlar[:3]]
    satirlar.append("")
    if k.is_adi:
        satirlar.append(f"İş: {k.is_adi}")
        if zincir:
            satirlar.append("Bu işteki önceki notlar:")
            satirlar += [f"  • {_ne_zaman(now - r.zaman)}: {r.not_metni[:80]}" for r in zincir[:3]]
    satirlar.append(f"Proje: {Path(k.repo).name or k.repo or '(seçilmedi)'}")
    if k.git_deposu:
        satirlar.append(f"Dal: {k.dal or '-'}")
        satirlar.append("Değişiklik: " + (k.diff_ozet or ("yeni dosya(lar), henüz git’e eklenmedi"
                                                         if k.dosyalar else "commitlenmemiş değişiklik yok")))
    if k.dosyalar:
        satirlar.append("Son değiştirdiğin dosyalar:")
        satirlar.append(f"  • {k.dosyalar[0]}{satir_metni(k)}")
        satirlar += [f"  • {d}" for d in k.dosyalar[1:]]
    if k.pencere:
        satirlar.append(f"Aktif pencere: {k.pencere[:70]}")
    if k.ekran:
        satirlar.append("Ekran görüntüsü: var (aşağıdaki düğmeyle aç)")
    return "\n".join(satirlar)


def markdown_card(k: Kayit, adimlar: list[str] | None = None) -> str:
    """Kartın Markdown hâli (issue, PR, sohbet için panoya kopyalanır)."""
    proje = Path(k.repo).name or k.repo or "(seçilmedi)"
    out = [f"### Personal Gnome: {proje}",
           f"_{time.strftime('%d.%m.%Y %H:%M', time.localtime(k.zaman))}, {k.tur}_",
           "",
           f"**Not:** {k.not_metni or '(not bırakılmadı)'}",
           ""]
    if k.is_adi:
        out.append(f"- **İş:** {k.is_adi}")
    if k.git_deposu:
        out.append(f"- **Dal:** `{k.dal or '-'}`")
        if k.diff_ozet:
            out.append(f"- **Değişiklik:** {k.diff_ozet}")
    if k.dosyalar:
        etiket = satir_metni(k).strip().strip("()")
        out.append(f"- **Dosya:** `{k.dosyalar[0]}`" + (f" ({etiket})" if etiket else ""))
        out += [f"- `{d}`" for d in k.dosyalar[1:]]
    if adimlar:
        out += ["", "**Sıradaki adımlar:**"] + [f"- [ ] {a}" for a in adimlar]
    return "\n".join(out).rstrip() + "\n"


# ---------------------------------------------------------------- notlardan bilgi çıkarma
def tr_lower(s: str) -> str:
    """Türkçe doğru küçük harf: I -> ı, İ -> i. (str.lower() 'İ'yi iki karaktere çevirir.)
    Uzunluk korunur, bu yüzden sonuçtaki konumlar orijinal metinde de geçerlidir."""
    return s.replace("I", "ı").replace("İ", "i").lower()


ADIM_ISARETLERI = ("sıradaki", "siradaki", "sırada", "sirada", "yapılacak", "yapilacak", "todo")
ENGEL_ISARETLERI = ("engel",)
# "sıradaki: x" ve "sıradaki adım: x" ikisi de kabul edilir.
_ISARET_RE = re.compile(r"(?<!\w)(" + "|".join(ADIM_ISARETLERI + ENGEL_ISARETLERI)
                        + r")(?:\s+ad[ıi]m(?:lar)?)?\s*:")


def parse_markers(text: str) -> tuple[list[str], list[str]]:
    """Nottan 'sıradaki: ...' adımlarını ve 'engel: ...' maddelerini çıkar.
    İşaretten sonra satır sonuna (veya sonraki işarete) kadar olan kısım alınır;
    ';' ile birden fazla madde yazılabilir. Dönüş: (adımlar, engeller)."""
    low = tr_lower(text)
    matches = list(_ISARET_RE.finditer(low))
    adimlar: list[str] = []
    engeller: list[str] = []
    for i, m in enumerate(matches):
        end = len(text)
        nl = text.find("\n", m.end())
        if nl != -1:
            end = nl
        if i + 1 < len(matches):
            end = min(end, matches[i + 1].start())
        hedef = engeller if m.group(1) in ENGEL_ISARETLERI else adimlar
        for parca in text[m.end():end].split(";"):
            parca = parca.strip(" \t,.-")
            if parca and parca not in hedef:
                hedef.append(parca)
    return adimlar, engeller


_URL_RE = re.compile(r"https?://[^\s<>\"']+")


def find_urls(text: str) -> list[str]:
    out = []
    for u in _URL_RE.findall(text or ""):
        u = u.rstrip(".,;:!?)]}")
        if u not in out:
            out.append(u)
    return out


ANA_DALLAR = {"main", "master", "head", "develop", "dev", "trunk"}


def default_job(dal: str) -> str:
    """Git dalından iş adı önerisi. Ana dallar (main, master...) bir iş anlatmadığı için boş."""
    dal = (dal or "").strip()
    return "" if dal.lower() in ANA_DALLAR else dal


# ---------------------------------------------------------------- rapor
def _kaynak(r: Kayit) -> str:
    if r.kaynak:
        return r.kaynak
    return "otomatik" if r.otomatik else "kisayol"  # M1 kayıtları


def report(days: float = 7, now: float | None = None) -> str:
    """Kesinti raporu. MVP sorularını da ölçer: otomatik pencerede not bırakılıyor mu?"""
    now = time.time() if now is None else now
    recs = [r for r in load_records() if r.zaman >= now - days * 86400]
    if not recs:
        return f"Son {days:g} günde kayıt yok."
    out = [f"Son {days:g} gün: {len(recs)} kesinti kaydı"]

    kaynaklar: dict[str, int] = {}
    for r in recs:
        kaynaklar[_kaynak(r)] = kaynaklar.get(_kaynak(r), 0) + 1
    adlar = {"kisayol": "elle", "toplanti": "toplantı algılandı", "takvim": "takvim hatırlatması",
             "sessiz": "unutulmuş (notsuz otomatik)", "otomatik": "otomatik"}
    out.append("  Nasıl başladı: " + ", ".join(f"{adlar.get(k, k)} {n}" for k, n in kaynaklar.items()))

    olculen = [r for r in recs if r.donus > r.zaman]
    if olculen:
        toplam = sum(r.donus - r.zaman for r in olculen)
        out.append(f"  Süresi ölçülen {len(olculen)} kesinti: toplam {sure_metni(toplam)}, "
                   f"ortalama {sure_metni(toplam / len(olculen))} (yaklaşık: dönüş = kartın açıldığı an)")

    out.append("  Türlere göre:")
    turler: dict[str, list] = {}
    for r in recs:
        t = turler.setdefault(r.tur, [0, 0.0])
        t[0] += 1
        if r.donus > r.zaman:
            t[1] += r.donus - r.zaman
    for tur, (n, sure) in sorted(turler.items(), key=lambda x: -x[1][0]):
        out.append(f"    {tur:<16} {n:>3} kez" + (f"   {sure_metni(sure)}" if sure else ""))

    pencereli = [r for r in recs if _kaynak(r) != "sessiz"]
    if pencereli:
        notlu = sum(1 for r in pencereli if r.not_metni)
        out.append(f"  Not bırakılan pencereler: {notlu}/{len(pencereli)} (%{round(100 * notlu / len(pencereli))})")
    oto = [r for r in recs if _kaynak(r) == "toplanti"]
    if oto:
        notlu = sum(1 for r in oto if r.not_metni)
        out.append(f"  Toplantıda kendiliğinden açılan pencerede not: {notlu}/{len(oto)}")
    return "\n".join(out)
