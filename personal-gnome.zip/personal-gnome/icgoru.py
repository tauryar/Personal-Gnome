"""Haftalık içgörü: hangi saatlerde çalışıyorsun, hangi saatlerde bölünüyorsun.

İzleyici, iş uygulaması ön plandayken ve klavye/fare kullanılırken geçen süreyi saat saat
biriktirir (etkinlik.json: {"YYYY-MM-DD HH": saniye}). 60 günden eski saatler silinir.
"""
from __future__ import annotations

import threading
import time

import core

DOSYA = "etkinlik.json"
SAKLAMA_GUN = 60


def hour_key(t: float) -> str:
    return time.strftime("%Y-%m-%d %H", time.localtime(t))


class Activity:
    """İzleyici iş parçacığından çağrılır; dakikada bir dosyaya yazar."""

    def __init__(self, flush_every: float = 60):
        self.flush_every = flush_every
        self._buf: dict[str, float] = {}
        self._lock = threading.Lock()
        self._last_flush = None

    def add(self, seconds: float, now: float) -> None:
        if seconds <= 0:
            return
        with self._lock:
            k = hour_key(now)
            self._buf[k] = self._buf.get(k, 0.0) + seconds
        if self._last_flush is None:
            self._last_flush = now
        elif now - self._last_flush >= self.flush_every:
            self.flush(now)

    def flush(self, now: float | None = None) -> None:
        now = time.time() if now is None else now
        with self._lock:
            buf, self._buf = self._buf, {}
        self._last_flush = now
        if not buf:
            return
        data = load()
        for k, v in buf.items():
            data[k] = round(data.get(k, 0.0) + v, 1)
        sinir = hour_key(now - SAKLAMA_GUN * 86400)
        data = {k: v for k, v in data.items() if k >= sinir}
        try:
            core.save_json(DOSYA, data)
        except OSError as exc:  # kilitliyse bir dahaki sefere eklensin
            with self._lock:
                for k, v in buf.items():
                    self._buf[k] = self._buf.get(k, 0.0) + v
            print(f"[içgörü] yazılamadı: {exc}")


ACTIVITY = Activity()


def load() -> dict[str, float]:
    data = core.load_json(DOSYA, {})
    out = {}
    for k, v in data.items():
        try:
            out[str(k)] = float(v)
        except (TypeError, ValueError):
            continue
    return out


def report(days: float = 7, now: float | None = None) -> str:
    now = time.time() if now is None else now
    since = now - days * 86400
    sinir = hour_key(since)
    work = [0.0] * 24
    for k, v in load().items():
        if k >= sinir:
            try:
                work[int(k[-2:])] += v
            except ValueError:
                continue
    recs = [r for r in core.load_records() if r.zaman >= since]
    kesinti = [0] * 24
    for r in recs:
        kesinti[time.localtime(r.zaman).tm_hour] += 1

    out = [f"İÇGÖRÜ (son {days:g} gün)"]
    toplam = sum(work)
    if toplam < 60:
        out.append("  Çalışma süresi verisi henüz yok. (Uygulama açıkken iş uygulamasında "
                   "geçirdiğin süre ölçülür.)")
    else:
        out.append(f"  Ölçülen çalışma: {core.sure_metni(toplam)}")
        out.append("  Saat    Çalışma      Kesinti")
        for h in range(24):
            if work[h] >= 60 or kesinti[h]:
                out.append(f"  {h:02d}:00   {core.sure_metni(work[h]) if work[h] >= 60 else '-':<11}  {kesinti[h]}")
        aday = [(kesinti[h] / (work[h] / 3600), h) for h in range(24) if work[h] >= 1800]
        if len(aday) >= 2:
            aday.sort()
            out.append("  En az bölündüğün saatler: "
                       + ", ".join(f"{h:02d}:00" for _, h in aday[:3])
                       + "  (çalışma saati başına en az kesinti)")
            en_kotu = max(aday)
            if en_kotu[0] > 0:
                out.append(f"  En çok bölündüğün saat: {en_kotu[1]:02d}:00 "
                           f"(saat başına {en_kotu[0]:.1f} kesinti)")
    top = [r for r in recs if r.tur == "toplantı"]
    if top:
        olculen = [r.donus - r.zaman for r in top if r.donus > r.zaman]
        satir = f"  Toplantı yükü: {len(top)} toplantı"
        if olculen:
            satir += f", süresi ölçülen toplam {core.sure_metni(sum(olculen))}"
            if toplam >= 60:
                satir += f" (çalışma süresinin %{round(100 * sum(olculen) / toplam)}'i kadar)"
        out.append(satir)
    else:
        out.append("  Toplantı yükü: kayıtlı toplantı yok")
    return "\n".join(out)
