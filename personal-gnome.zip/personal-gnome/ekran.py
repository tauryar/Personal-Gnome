"""Kesinti anında çalıştığın pencerenin ekran görüntüsü (isteğe bağlı, varsayılan kapalı).

- Sadece son çalışılan iş penceresinin ekrandaki alanı alınır (tüm ekran değil); panelle
  çakışan kısım kırpılır.
- Görüntüler yalnızca bu bilgisayarda, veri klasöründeki ekranlar/ içinde tutulur ve
  7 gün sonra silinir.
- Pencerenin kendi içeriği değil ekrandaki görünümü yakalanır (Pillow'un pencere yakalaması
  GPU ile çizen uygulamalarda, ör. VS Code, siyah görüntü verebiliyor).
"""
from __future__ import annotations

import os
import sys
import threading
import time
from pathlib import Path

import core

KLASOR = "ekranlar"
SAKLAMA_GUN = 7
MIN_BOYUT = 80  # bundan küçük alan anlamsız


def enabled(settings: dict | None = None) -> bool:
    s = core.load_settings() if settings is None else settings
    return s.get("ekran_goruntusu") is True


def shots_dir() -> Path:
    d = core._data_dir() / KLASOR
    d.mkdir(exist_ok=True)
    return d


def path_for(name: str) -> Path | None:
    if not name or "/" in name or "\\" in name:
        return None
    p = shots_dir() / name
    return p if p.is_file() else None


def window_rect(hwnd: int) -> tuple[int, int, int, int] | None:
    """Pencerenin ekrandaki görünen dikdörtgeni (sol, üst, sağ, alt). Windows dışında None."""
    if sys.platform != "win32" or not hwnd:
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    if not user32.IsWindow(hwnd) or user32.IsIconic(hwnd) or not user32.IsWindowVisible(hwnd):
        return None
    r = wintypes.RECT()
    try:  # DWMWA_EXTENDED_FRAME_BOUNDS = 9: görünmez kenarlar hariç
        hr = ctypes.windll.dwmapi.DwmGetWindowAttribute(wintypes.HWND(hwnd), 9, ctypes.byref(r),
                                                        ctypes.sizeof(r))
        if hr != 0:
            raise OSError(hr)
    except (OSError, AttributeError):
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return None
    return r.left, r.top, r.right, r.bottom


def clip_rect(rect, panel_geo, sw: int, sh: int):
    """Ekran sınırına ve panelin dışına kırp. panel_geo = (x, y, w, h) ya da None."""
    left, top, right, bottom = rect
    left, top, right, bottom = max(0, left), max(0, top), min(sw, right), min(sh, bottom)
    if panel_geo:
        px, _, pw, _ = panel_geo
        if px > (left + right) / 2:        # panel sağda
            right = min(right, px)
        else:                               # panel solda
            left = max(left, px + pw)
    if right - left < MIN_BOYUT or bottom - top < MIN_BOYUT:
        return None
    return left, top, right, bottom


def capture(hwnd: int, panel_geo, sw: int, sh: int, zaman: float, grabber=None) -> str:
    """Görüntüyü al (hemen) ve arka planda kaydet. Dosya adını döndürür; alınamazsa ''."""
    rect = window_rect(hwnd)
    if rect is None:
        return ""
    bbox = clip_rect(rect, panel_geo, sw, sh)
    if bbox is None:
        return ""
    if grabber is None:
        from PIL import ImageGrab
        grabber = ImageGrab.grab
    try:
        img = grabber(bbox=bbox)
    except Exception as exc:  # ekran kilitli vb.
        print(f"[ekran] görüntü alınamadı: {exc}")
        return ""
    name = time.strftime("%Y%m%d-%H%M%S", time.localtime(zaman)) + f"-{int(zaman * 1000) % 1000:03d}.png"
    target = shots_dir() / name

    def save():
        tmp = target.with_suffix(".tmp")
        try:
            img.save(tmp, "PNG", optimize=True)
            os.replace(tmp, target)  # yarım yazılmış dosya açılmasın
        except Exception as exc:
            print(f"[ekran] kaydedilemedi: {exc}")

    threading.Thread(target=save, daemon=True).start()
    return name


def cleanup(days: float = SAKLAMA_GUN, now: float | None = None) -> int:
    """Süresi dolan görüntüleri sil (sadece bu uygulamanın ekranlar/ klasöründeki .png'ler)."""
    now = time.time() if now is None else now
    n = 0
    for p in list(shots_dir().glob("*.png")) + list(shots_dir().glob("*.tmp")):
        try:
            if p.is_file() and p.stat().st_mtime < now - days * 86400:
                p.unlink()
                n += 1
        except OSError:
            continue
    return n


def open_file(path: Path) -> bool:
    if sys.platform == "win32":
        try:
            os.startfile(str(path))  # varsayılan resim görüntüleyici
            return True
        except OSError:
            return False
    return False
