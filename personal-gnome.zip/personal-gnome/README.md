<img src="assets/logo.png" width="64" align="right" alt="Personal Gnome logosu">

# Personal Gnome

<img src="assets/maskot.png" width="160" alt="Personal Gnome maskotu">

Yazılımcı kesintiye uğradığında **nerede kaldığını ve ne düşündüğünü** kaydeder, dönünce gösterir.
Ekranın kenarında duran bir paneldir (Windows, tek .exe). Veriler yalnızca bilgisayarda kalır
(`%USERPROFILE%\.kaldigim_yer\`). İnternet yalnızca iki şey için kullanılır: sesli notun konuşma
modelini ilk kez indirmek ve (açtıysan) takvim bağlantını okumak.

## Proje klasörü: git'li veya git'siz

**git**, kod dosyalarındaki değişiklikleri kaydeden bir sürüm kontrol aracıdır; git ile takip edilen klasöre
"git deposu" denir. Personal Gnome her iki klasörle de çalışır.

### Kaldığın satır nasıl bulunur

Satır en güvenilir kaynaktan alınır; kartta kaynağı yazar:

| Öncelik | Kaynak | Kartta | Ne zaman doğru |
|---|---|---|---|
| 1 | VS Code eklentisi | `(satır 42 - imleç, VS Code)` | Her zaman; kaydedilmemiş değişiklikte bile |
| 2 | Dosyanın bellekteki kopyasıyla karşılaştırma | `(satır 42 - son kaydedilen değişiklik)` | Dosyayı kaydettiğinde |
| 3 | git'teki ilk değişiklik | `(satır 42 - ilk değişiklik, git)` | Yaklaşık; dosyadaki ilk düzenlemede tam yer |
| - | Hiçbiri | satır yazmaz | |

- **Git'siz klasör:** en son değişen 30 metin dosyasının kopyası bellekte tutulur, 10 sn'de bir kontrol edilir.
  Kaydettiğin değişikliğin satırı bulunur. Dosyalarına yalnızca **okuma** yapılır.
  Sınır: uzun süredir dokunulmamış bir dosyanın *ilk* kaydında satır bilinmez (karşılaştıracak eski hâl yok);
  ikinci kayıttan itibaren bilinir. VS Code eklentisiyle bu sınır yoktur.
- **Git deposu:** ilk düzenlemede git, sonrakilerde bellekteki kopya kullanılır (git hep ilk bloğu gösterirdi).
- Değişiklik birden fazla satırsa, değişen bloğun **son** satırı gösterilir (imleç genelde oradadır).

Git'siz klasörde araçların ürettiği klasör/dosyalar atlanır: noktayla başlayan klasörler (`.godot`, `.vs`, `.venv`...),
`node_modules`, `Library`, `Temp`, `build`, `dist`, `bin`, `obj` ve `*.import`, `*.uid`, `*.meta`, `*.log`.
Eklemek için `ayarlar.json`: `{ "haric_klasorler": ["Assets_cache"] }`.

### VS Code eklentisi

Ayarlar → **Eklentiyi kur / güncelle** (arkada `code --install-extension personal-gnome-vscode.vsix --force` çalışır).
Sonra VS Code'u yeniden başlat. Eklenti imleç her hareket ettiğinde dosya yolunu ve satırı
`vscode_imlec.json` dosyasına yazar. İnternete bağlanmaz, proje dosyalarını değiştirmez.
Ayarlar'da "Bağlı. Son imleç ... önce" yazıyorsa çalışıyordur.

## Panel

- Varsayılan: ekranın **sağında**, genişliğin **%18**'i, görev çubuğunun üstünde biter (saat kapanmaz).
  Windows'a "appbar" olarak kaydolur: görev çubuğu gibi yer ayırır, büyütülmüş pencereler kalan alana sığar.
- Üst çubuk: `Ş` şerit modu · `<>` taraf (sağ/sol) · `-` `+` genişlik (%15–20) · `[ ]` tam ekran · `X` tepsiye gizle.
- **Şerit modu:** kenarda yalnızca 12 piksellik ince bir şerit yer tutar. Fareyi kenara götürünce panel açılır,
  ayrılınca 2 sn sonra daralır. Not yazarken, ses kaydederken veya bir alana yazarken daralmaz.
  Kesinti olunca kendiliğinden açılır; kart açılınca en az 20 sn açık kalır. Açık panel büyütülmüş pencerenin
  kenarını geçici olarak örter (ayrılan alan bilerek değiştirilmez; değişseydi bütün pencereler titrerdi).
  Şeridin rengi durumu gösterir: sarı = not bekliyor, yeşil = kart.
- **Kendini yeniden yerleştirir:** çözünürlük, görev çubuğunun yeri veya otomatik gizlenme değişirse 2 sn içinde.
- **Tam ekran uygulama** (oyun, video, sunum) açılınca panel en üstte durmayı bırakır, kapanınca geri döner.
- **Tema:** Ayarlar → Açık / Koyu / Windows'a uy.
- **Sistem tepsisi** (saat yanındaki ikon): sol tık = göster/gizle. Sağ tık menüsü: Bölündüm, Kartı göster,
  Şerit / Sabit, **Çıkış**. `X` paneli tepsiye gizler; uygulamayı kapatmak için tepsi menüsünden Çıkış.
  Gizliyken bir kesinti olursa panel kendiliğinden görünür. İkon rengi durumu gösterir.
- Sekmeler:
  - **Şimdi:** `Bölündüm` düğmesi, not alanı (yaz veya `Konuş`), İş alanı, "Kaldığın yer" kartı ve düğmeleri:
    `Kaldığın satıra git`, `Devam et` (dosya + nottaki bağlantılar), `Ekran görüntüsünü aç`, `Markdown kopyala`
  - **İşler:** sıradaki adımlar; işe göre süz, elle ekle, bitti işaretle (çift tık), sil, işi yeniden adlandır
  - **Geçmiş:** son 100 kayıt, işe göre süzülebilir; seçilenin kartı
  - **Rapor:** kesinti raporu + saatlik içgörü; `Standup özetini kopyala`
  - **Ayarlar:** projeler, yok sayılanlar, görünüm, Windows açılınca başlat, ekran görüntüsü, takvim, VS Code
- Panel daralınca sekme adları kısalır (İş, Geç., Rap., Ayar); Ayarlar kaydırılabilir.

## Ne zaman ne olur

| Durum | Ne olur |
|---|---|
| Toplantı (bir uygulama mikrofonu kullanmaya başlar) | Not alanı sarı olur, o anın kod durumu alınır. Yaz/konuş → Enter. Esc = notsuz kaydet |
| Takvimdeki toplantıya N dk kaldı (Ayarlar → Takvim) | Not alanı "Toplantı yaklaşıyor: başlık, saat" ile açılır. Toplantı başlayıp mikrofon algılanınca ikinci pencere açılmaz |
| Elle ara: `Ctrl+Shift+F9`, panelde **Bölündüm**, tepsi menüsü | Aynı. Esc = iptal |
| Kısayola basmadan kalktın (5 dk dokunmadın) | Notsuz kayıt alınır |
| Kısayola basmadan başka işe geçtin (15 dk iş uygulaması dışında) | Notsuz kayıt alınır |
| İş uygulamasına döndün / toplantı bitti / `Ctrl+Shift+F10` | Kart yeşil olur: ne kadar uzaktaydın, notun, işin önceki notları, sıradaki adımlar, proje, dal, dosya ve satır |
| Yanlış toplantı tetiği (ör. Discord, OBS) | "Toplantı değil, X yok say". Ayarlar'dan geri alınabilir |

**Bölündüm düğmesi** kısayolun panel hâlidir: tıkladığın an kod durumu dondurulur, süre başlar, not alanı açılır.
Durum, panele göre değil son çalıştığın pencereye göre alınır.

Not alanında: Enter = kaydet, Shift+Enter = yeni satır.

### Nottaki işaretler

| Yazdığın | Ne olur |
|---|---|
| `sıradaki: test yaz` (ayrıca `sıradaki adım:`, `sırada:`, `yapılacak:`, `todo:`; büyük/küçük harf ve `siradaki` de olur) | İşler sekmesine adım olarak eklenir, kartta görünür |
| `todo: a; b; c` | Üç ayrı adım |
| `engel: API anahtarı bekleniyor` | Standup özetinde "Engeller" altına girer |
| `https://...` bağlantısı | Kartta `Devam et` ile açılır (o işin notlarındaki en fazla 5 bağlantı) |

### İş zinciri

Not formundaki **İş** alanı aynı işe ait notları bağlar. Git'te `main`/`master` dışındaki bir daldaysan dal adı
kendiliğinden yazılır; istediğin adı yazabilirsin (elle yazdığın ad ezilmez). Kart, o işin son 3 notunu ve açık
adımlarını gösterir. İşler sekmesinden iş adını değiştirebilirsin (bütün kayıtlarda değişir).

### Rapor, içgörü, standup

- **İçgörü:** uygulama açıkken iş uygulaması önde ve klavye/fare kullanılıyorsa çalışma süresi saat saat ölçülür
  (60 gün tutulur). Raporda her saat için çalışma süresi ve kesinti sayısı, en az ve en çok bölündüğün saatler,
  toplantı yükü.
- **Standup:** "Dün / Bugün / Engeller" metnini panoya kopyalar. Dün = bugünden önceki son kayıtlı gün
  (Pazartesi'ye Cuma), Bugün = açık adımlar, Engeller = `engel:` işaretleri.

### Ekran görüntüsü (varsayılan kapalı)

Açılırsa kesinti anında **yalnızca son çalıştığın pencerenin** ekrandaki görüntüsü alınır (panelle çakışan kısım
kırpılır). Görüntüler bu bilgisayarda `ekranlar\` klasöründe kalır ve 7 gün sonra silinir. Kilit ekranında alınmaz.

### Takvim hatırlatması (varsayılan kapalı)

Ayarlar → Takvim: takvimin **.ics** bağlantısını yapıştır.
Google Takvim: Ayarlar → soldan takvimin adı → Takvimi entegre et → "Secret address in iCal format" (iCal biçiminde gizli adres).
Outlook (web): Ayarlar → Takvim → Paylaşılan takvimler → Takvim yayımla → ICS bağlantısı (iş hesabında yönetici kapatmış olabilir). Kaç dk önce hatırlatılacağı 1–15 (varsayılan 2). `Test et`
sıradaki toplantıyı gösterir. Takvim 10 dk'da bir okunur; tekrarlayan, iptal edilen ve taşınan toplantılar doğru
hesaplanır, tüm gün süren etkinlikler atlanır. Bağlantı gizli bir adres olduğu için günlüğe yazılmaz.

İş uygulaması sayılanlar: VS Code, Cursor, Windows Terminal, PowerShell, cmd, Godot, JetBrains IDE'leri,
Visual Studio, Unity. Eklemek için `ayarlar.json`: `{ "calisma_uygulamalari": ["blender.exe"] }`.

## .exe üretme

PyInstaller çapraz derleme yapmaz; .exe bir Windows makinesinde üretilir. İki yol:

**A) Kendi bilgisayarında (Python gerekir):**
1. `personal-gnome.zip` dosyasına sağ tıkla → **Tümünü ayıkla**. (Zip'in içinden çalıştırılırsa betik dosyaları bulamaz.)
2. Python **3.12, 3.13 veya 3.14** gerekir (önerilen 3.13). **3.15 olmaz:** sesli not için gereken `onnxruntime`
   paketinin Python 3.15 için Windows dosyası henüz yayınlanmadı. 3.15 kuruluysa silmene gerek yok, yan yana kur:
   `cmd` aç → `py install 3.13`. Bu komut tanınmazsa python.org → Downloads → Python 3.13 indirip kur
   (ilk ekranda **Add python.exe to PATH** kutusunu işaretle). `build.bat` uygun sürümü kendisi bulur.
3. Çıkan klasördeki `build.bat` dosyasına çift tıkla. Ekranda yalnızca adımlar görünür; ayrıntılı çıktı `build_log.txt`
   dosyasına yazılır (hata olursa son 30 satırı ekrana gelir). Başta boş bellek gösterilir; 2 GB'tan azsa önce büyük
   programları kapat. Sonunda .exe'nin içindeki bileşenler kontrol edilir (`Paket testi: tamam`). Pencere açık kalır.
4. Çıktı: `dist\PersonalGnome.exe`.

**B) GitHub'ın bulut Windows makinesinde (bilgisayara Python kurmadan):**
1. Bu klasörü bir GitHub deposuna yükle (`.github/workflows/windows-exe.yml` dahil).
2. Depoda **Actions → Windows exe → Run workflow**.
3. Bitince çalışmanın sayfasında **Artifacts → PersonalGnome** indir. İş akışı önce testleri çalıştırır, sonra .exe'nin
   içinde bütün bileşenleri kontrol eder; biri eksikse .exe verilmez.

İlk açılış: `PersonalGnome.exe`'ye çift tıkla → **Ayarlar** sekmesinden proje klasörünü ekle →
istersen VS Code eklentisini kur ve "Windows açılınca başlat"ı işaretle.

Süreleri değiştirmek için kısayolun hedefine ekle: `PersonalGnome.exe --idle-dk 10 --baska-is-dk 20`.
Konsolsuz çalıştığı için çıktı ve hatalar `gunluk.txt` dosyasına yazılır.
Bileşen kontrolü: `PersonalGnome.exe --paket-testi` (sonuç `paket_testi.txt`'de).

## Kaynaktan çalıştırma ve test

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt -r requirements-voice.txt
python app.py                 :: panel
python app.py --tani          :: algılama tanısı (konsolda)
python app.py --rapor 7       :: rapor (konsolda)
pip install pytest
python -m pytest -q
```

Eklentiyi yeniden paketlemek (yalnızca `vscode-ext\extension.js` değiştirildiyse; Node.js gerekir):
`npx @vscode/vsce package --no-dependencies -o ..\personal-gnome-vscode.vsix` (`vscode-ext` klasöründe).

## Veri dosyaları (`%USERPROFILE%\.kaldigim_yer\`)

`kayitlar.json` (son 200 kesinti) · `isler.json` (adımlar) · `etkinlik.json` (saatlik çalışma süresi, 60 gün) ·
`ayarlar.json` · `vscode_imlec.json` (eklenti yazar) · `ekranlar\` (7 gün) · `gunluk.txt`.
Eski sürümün kayıtları olduğu gibi açılır.

## Bilinen sınırlar

- Yalnızca ana ekranda çalışır (çoklu monitör yok).
- Panel çerçevesizdir; görev çubuğunda düğmesi yoktur. Tepsi ikonundan erişilir.
- Masaya gelen biri veya telefonla aranmak otomatik algılanmaz: kısayol veya Bölündüm gerekir.
- Ekran görüntüsü pencerenin ekrandaki görünümüdür: o an başka bir pencere üstündeyse o da görünür
  (ör. toplantı uygulaması öne geldiyse).

## İlk açılışta Windows'ta doğrulanacaklar

Bunlar Windows'a özgüdür ve geliştirme ortamında (Linux) çalıştırılamadı:

1. `build.bat` sonunda `Paket testi: tamam` ve `Tepsi: tamam (pystray pystray._win32)` yazıyor mu.
2. Panel ekranda yer ayırıyor mu: VS Code'u büyüt, panelin altına girmemeli. `X` → panel gizlenip alan geri geliyor mu,
   tepsi ikonuna sol tık → geri geliyor mu. Tepsi → Çıkış uygulamayı kapatıyor mu.
3. **Şerit:** `Ş`'ye bas. Büyütülmüş pencere neredeyse tam genişliğe yayılmalı; fareyi sağ kenara götür → panel açılır,
   uzaklaştır → 2 sn sonra daralır.
4. **Yeniden yerleşme:** görev çubuğu ayarlarından "otomatik gizle"yi aç/kapat; panel 2 sn içinde uyum sağlamalı.
5. **Tam ekran:** YouTube'da bir videoyu tam ekran yap; panel videonun üstünde kalmamalı.
6. **Tema:** Ayarlar → Koyu; Windows'a uy seçip Windows'un renk modunu değiştir (10 sn içinde uyar).
7. **VS Code satırı:** eklentiyi kur, VS Code'u yeniden başlat, imleci 42. satıra koy, `Ctrl+Shift+F9` → kartta
   `satır 42 - imleç, VS Code`. Git'siz bir klasörde bir dosyanın 15. satırını değiştirip kaydet, 10 sn bekle,
   `Ctrl+Shift+F9` → (eklenti kapalıyken) `satır 15 - son kaydedilen değişiklik`.
8. **Ekran görüntüsü:** Ayarlar'da aç, VS Code'dayken `Ctrl+Shift+F9` → kartta "Ekran görüntüsünü aç" VS Code'u göstermeli.
9. **Takvim:** 3 dk sonrasına bir test etkinliği koy, .ics bağlantısını gir, `Test et` → etkinlik görünmeli; 2 dk kala not alanı açılmalı.
10. **Başlangıç:** "Windows açılınca başlat"ı işaretle, oturumu kapatıp aç.
11. `python app.py --tani` ile bir Meet görüşmesinde `mikrofon:` satırında tarayıcı görünüyor mu.
12. Ekran ölçeklendirmesi %125/%150 iken büyütülmüş pencere panelin kenarına kadar uzanıyor mu.
