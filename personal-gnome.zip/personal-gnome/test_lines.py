"""Satır bilgisinin doğru alındığının kanıtı: git'siz klasör, git deposu, VS Code imleci."""
import json
import os
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

import core
import lines


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def write(p: Path, text: str, bump: float = 1.0) -> None:
    """Dosyayı yaz ve değişiklik zamanını ileri al (aynı saniyede iki kayıt ayırt edilsin)."""
    old = p.stat().st_mtime if p.exists() else time.time() - 100
    p.write_bytes(text.encode("utf-8"))
    os.utime(p, (old + bump, old + bump))


def numbered(n: int) -> list[str]:
    return [f"satir {i}" for i in range(1, n + 1)]


def folder(name="duz") -> Path:
    d = Path(tempfile.mkdtemp()) / name
    d.mkdir()
    return d


# ---------------------------------------------------------------- saf fark fonksiyonu
@pytest.mark.parametrize("old,new,expected", [
    (["a", "b", "c"], ["a", "X", "c"], 2),                  # satır değişti
    (["a", "b", "c"], ["a", "b", "X", "Y", "Z", "c"], 5),   # 3 satır eklendi -> bloğun sonu
    (["a", "b", "c", "d"], ["a", "d"], 2),                  # silindi -> sonraki satır
    (["a", "b", "c"], ["a", "b"], 2),                       # sondan silindi -> son satır
    (["a", "b"], ["a", "b", "c"], 3),                       # sona eklendi
    (["a", "b"], ["X", "a", "b"], 1),                       # başa eklendi
    (["a", "b"], ["a", "b"], 0),                            # değişiklik yok
    ([], ["a"], 1),
    (["a"], [], 1),                                         # dosya boşaldı
    (["x", "x", "x"], ["x", "x", "x", "x"], 4),             # tekrarlanan satırlar
])
def test_changed_line(old, new, expected):
    enc = lambda xs: [s.encode() for s in xs]
    assert lines.changed_line(enc(old), enc(new)) == expected


# ---------------------------------------------------------------- git'siz klasör
def test_plain_folder_edit_insert_delete_and_sequence():
    d = folder()
    f = d / "oyun.gd"
    write(f, "\n".join(numbered(20)) + "\n")
    t = lines.ShadowTracker()
    t.sample(str(d))                                   # ilk kopya (değişiklik bilinmiyor)
    assert t.line_for(f) == 0

    rows = numbered(20)
    rows[4] = "satir 5 DEGISTI"                         # 5. satırı düzenle
    write(f, "\n".join(rows) + "\n")
    t.sample(str(d))
    assert t.line_for(f) == 5

    rows[9:9] = ["yeni a", "yeni b"]                    # 10. satırdan önce 2 satır ekle
    write(f, "\n".join(rows) + "\n")
    assert t.line_for(f) == 11                          # örnekleme beklenmeden de yakalanır

    del rows[14]                                        # 15. satırı sil
    write(f, "\n".join(rows) + "\n")
    assert t.line_for(f) == 15

    rows[1] = "satir 2 SON"                             # art arda ikinci düzenleme: en sonuncusu
    write(f, "\n".join(rows) + "\n")
    assert t.line_for(f) == 2


def test_crlf_and_turkish_file_name():
    d = folder("türkçe_proje")
    f = d / "çalışma_ğüş.py"
    write(f, "\r\n".join(numbered(10)) + "\r\n")
    t = lines.ShadowTracker()
    t.sample(str(d))
    rows = numbered(10)
    rows[6] = "satır 7 değişti ğüşiöç"
    write(f, "\r\n".join(rows) + "\r\n")
    assert t.line_for(f) == 7


def test_binary_and_large_files_are_skipped():
    d = folder()
    b = d / "resim.png"
    b.write_bytes(b"\x89PNG\x00\x00\x01")
    big = d / "buyuk.txt"
    big.write_bytes(b"a\n" * (lines.MAX_BOYUT // 2 + 1))
    t = lines.ShadowTracker()
    t.sample(str(d))
    assert t.line_for(b) == 0 and t.line_for(big) == 0 and t.tracked() == 0


def test_tracker_keeps_at_most_max_files():
    d = folder()
    for i in range(8):
        write(d / f"f{i}.txt", "x\n", bump=i)
    t = lines.ShadowTracker(max_files=5)
    t.sample(str(d))
    assert t.tracked() == 5


def test_project_files_are_never_written():
    d = folder()
    f = d / "a.py"
    write(f, "x\ny\n")
    before = (f.read_bytes(), f.stat().st_mtime_ns)
    t = lines.ShadowTracker()
    for _ in range(3):
        t.sample(str(d))
        t.line_for(f)
    assert (f.read_bytes(), f.stat().st_mtime_ns) == before
    assert sorted(p.name for p in d.iterdir()) == ["a.py"]


def test_snapshot_plain_folder_uses_copy_line():
    d = folder()
    f = d / "main.py"
    write(f, "\n".join(numbered(30)) + "\n")
    t = lines.ShadowTracker()
    t.sample(str(d))
    rows = numbered(30)
    rows[21] = "satir 22 yeni"
    write(f, "\n".join(rows) + "\n")
    snap = lines.snapshot(str(d), t)
    assert snap["dosyalar"][0] == "main.py" and snap["satir"] == 22 and snap["satir_kaynak"] == "kopya"
    k = core.make_record(str(d), "not", "diğer", snap=snap, pencere="")
    assert "main.py  (satır 22 - son kaydedilen değişiklik)" in core.format_card(k)


def test_snapshot_plain_folder_without_known_change_shows_no_line():
    d = folder()
    write(d / "main.py", "x\n")
    snap = lines.snapshot(str(d), lines.ShadowTracker())   # kopya yok, git yok
    assert snap["satir"] == 0 and snap["satir_kaynak"] == ""
    k = core.make_record(str(d), "not", "diğer", snap=snap, pencere="")
    assert "(satır" not in core.format_card(k)


# ---------------------------------------------------------------- git deposu
def make_repo(n=40) -> Path:
    d = Path(tempfile.mkdtemp()) / "oyun"
    d.mkdir()
    g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
    g("init", "-q", "-b", "main")
    g("config", "user.email", "t@t")
    g("config", "user.name", "t")
    write(d / "auth.py", "\n".join(numbered(n)) + "\n")
    g("add", ".")
    g("commit", "-qm", "ilk")
    return d


def test_git_first_edit_uses_git_line_then_copy_takes_over():
    d = make_repo()
    f = d / "auth.py"
    t = lines.ShadowTracker()
    t.sample(str(d))                                    # değişiklik yok: izlenecek dosya yok
    rows = numbered(40)
    rows[9] = "satir 10 degisti"
    write(f, "\n".join(rows) + "\n")
    snap = lines.snapshot(str(d), t)                    # ilk düzenleme: git bloğu = tam yer
    assert snap["satir"] == 10 and snap["satir_kaynak"] in ("git", "")
    if snap["satir_kaynak"] == "":                      # (kopya ilk görüşte fark bilmez)
        pytest.fail("ilk düzenlemede git satırı bekleniyordu")

    t.sample(str(d))
    rows[29] = "satir 30 degisti"                       # ikinci düzenleme: git hâlâ 10 der
    write(f, "\n".join(rows) + "\n")
    assert core.git_snapshot(str(d))["satir"] == 10
    snap = lines.snapshot(str(d), t)
    assert snap["satir"] == 30 and snap["satir_kaynak"] == "kopya"


# ---------------------------------------------------------------- VS Code imleci
def write_cursor(path: Path, satir: int, zaman: float | None = None, raw: dict | None = None):
    data = raw if raw is not None else {"dosya": str(path), "satir": satir, "sutun": 1,
                                        "kaydedilmemis": True,
                                        "zaman": int((time.time() if zaman is None else zaman) * 1000)}
    (core._data_dir() / lines.IMLEC_DOSYASI).write_text(json.dumps(data), encoding="utf-8")


def test_vscode_cursor_has_priority_and_card_label():
    d = make_repo()
    rows = numbered(40)
    rows[9] = "degisti"
    write(d / "auth.py", "\n".join(rows) + "\n")
    write(d / "diger.py", "\n".join(numbered(60)) + "\n")
    write_cursor(d / "diger.py", 42)                   # imleç başka (izlenmeyen) dosyada, satır 42
    snap = lines.snapshot(str(d), lines.ShadowTracker())
    assert snap["dosyalar"][0] == "diger.py" and snap["satir"] == 42 and snap["satir_kaynak"] == "vscode"
    k = core.make_record(str(d), "not", "diğer", snap=snap, pencere="")
    assert "diger.py  (satır 42 - imleç, VS Code)" in core.format_card(k)
    assert "satır 42 - imleç, VS Code" in core.markdown_card(k)


def test_vscode_cursor_outside_project_is_ignored():
    d = make_repo()
    other = folder("baska") / "x.py"
    write(other, "a\n")
    write_cursor(other, 5)
    assert lines.cursor_in_repo(str(d)) is None
    assert lines.snapshot(str(d), lines.ShadowTracker())["satir_kaynak"] != "vscode"


def test_vscode_cursor_stale_when_files_changed_later():
    d = make_repo()
    write_cursor(d / "auth.py", 7, zaman=time.time() - 3600)   # 1 saat önceki imleç
    rows = numbered(40)
    rows[2] = "simdi baska editorde degisti"
    p = d / "auth.py"
    p.write_text("\n".join(rows) + "\n")
    os.utime(p, None)                                          # şimdi değişti
    snap = lines.snapshot(str(d), lines.ShadowTracker())
    assert snap["satir_kaynak"] == "git" and snap["satir"] == 3


def test_vscode_cursor_sibling_folder_with_same_prefix_is_outside():
    base = Path(tempfile.mkdtemp())
    (base / "oyun").mkdir()
    (base / "oyun2").mkdir()
    f = base / "oyun2" / "a.py"
    f.write_text("x\n")
    write_cursor(f, 1)
    assert lines.cursor_in_repo(str(base / "oyun")) is None


@pytest.mark.parametrize("raw", [
    {"dosya": "x", "satir": 0, "zaman": 1},             # satır 0 geçersiz
    {"dosya": "x", "satir": "3", "zaman": 1},           # yazı
    {"dosya": "x", "satir": True, "zaman": 1},          # bool
    {"satir": 3, "zaman": 1},                           # dosya yok
    [1, 2, 3],
])
def test_bad_cursor_data_is_rejected(raw):
    write_cursor(Path("x"), 1, raw=raw)
    assert lines.read_cursor() is None


def test_extension_output_is_read_correctly():
    """Eklentinin gerçek çıktısı (Node ile çalıştırılır) Python'da doğru satırı verir."""
    import shutil
    node = shutil.which("node")
    if not node:
        pytest.skip("node yok")
    d = make_repo()
    js = Path(__file__).parent / "vscode-ext" / "extension.js"
    script = f"""
const Module = require('module');
const orig = Module._load;
Module._load = function (r, ...a) {{ return r === 'vscode' ? {{window: {{state: {{focused: true}}}}}} : orig.call(this, r, ...a); }};
const ext = require({json.dumps(str(js))});
ext.yaz({{document: {{uri: {{scheme: 'file', fsPath: {json.dumps(str(d / 'auth.py'))}}}, isDirty: false}},
         selection: {{active: {{line: 41, character: 0}}}}}});
"""
    env = dict(os.environ)
    subprocess.run([node, "-e", script], check=True, env=env)
    c = lines.read_cursor()
    assert c["satir"] == 42                                       # 0 tabanlı 41 -> 42
    assert lines.cursor_in_repo(str(d)) == ("auth.py", 42)


def test_extension_unit_tests_pass():
    import shutil
    node = shutil.which("node")
    if not node:
        pytest.skip("node yok")
    out = subprocess.run([node, str(Path(__file__).parent / "vscode-ext" / "test" / "test_extension.js")],
                         capture_output=True, text=True)
    assert out.returncode == 0, out.stderr
    assert "EKLENTI TESTI: TAMAM" in out.stdout


def test_vsix_is_bundled_and_contains_extension():
    import zipfile
    import vscode_ext
    p = vscode_ext.bundled_vsix()
    assert p is not None
    names = zipfile.ZipFile(p).namelist()
    assert "extension/extension.js" in names and "extension/package.json" in names
    pkg = json.loads(zipfile.ZipFile(p).read("extension/package.json"))
    assert pkg["main"] == "./extension.js" and "onStartupFinished" in pkg["activationEvents"]
    # pakettteki kod, depodaki kodla aynı olmalı (eski .vsix unutulmasın)
    src = (Path(__file__).parent / "vscode-ext" / "extension.js").read_bytes()
    assert zipfile.ZipFile(p).read("extension/extension.js").replace(b"\r\n", b"\n") == src.replace(b"\r\n", b"\n")


def test_vscode_status_texts():
    import vscode_ext
    assert "Eklenti verisi yok" in vscode_ext.status()
    d = folder()
    write(d / "a.py", "x\n")
    write_cursor(d / "a.py", 12)
    assert "Bağlı" in vscode_ext.status() and "a.py, satır 12" in vscode_ext.status()


def test_install_without_code_command(monkeypatch):
    import vscode_ext
    monkeypatch.setattr(vscode_ext.shutil, "which", lambda n: None)
    ok, msg = vscode_ext.install()
    assert not ok and "code komutu bulunamadı" in msg


def test_install_runs_official_cli(monkeypatch):
    import vscode_ext
    calls = []

    class R:
        returncode, stdout, stderr = 0, "Extension 'personal-gnome-vscode.vsix' was successfully installed.", ""

    monkeypatch.setattr(vscode_ext.shutil, "which", lambda n: "/usr/bin/code")
    monkeypatch.setattr(vscode_ext.subprocess, "run", lambda args, **kw: calls.append(args) or R())
    ok, msg = vscode_ext.install()
    assert ok and calls[0][0] == "/usr/bin/code" and calls[0][1] == "--install-extension"
    assert calls[0][2].endswith(vscode_ext.VSIX) and calls[0][3] == "--force"
    assert Path(calls[0][2]).is_file()                             # kalıcı kopya veri klasöründe


@pytest.mark.parametrize("repo,path,expected", [
    (r"C:\Users\Ege\oyun", r"c:\Users\Ege\oyun\src\Auth.py", "src/Auth.py"),   # sürücü harfi küçük
    (r"C:\Users\Ege\Oyun", r"c:\users\ege\oyun\a.py", "a.py"),                  # Windows büyük/küçük harf duyarsız
    (r"C:\Users\Ege\oyun", r"C:\Users\Ege\oyun2\a.py", None),                   # benzer adlı kardeş klasör
    (r"C:\Users\Ege\oyun", r"D:\oyun\a.py", None),                              # başka sürücü
    (r"C:\Users\Ege\oyun", r"C:\Users\Ege\oyun", None),                         # klasörün kendisi
])
def test_relative_in_windows_paths(repo, path, expected):
    import ntpath
    assert lines._relative_in(repo, path, pm=ntpath) == expected
