@echo off
setlocal
title Personal Gnome - exe derleme
cd /d "%~dp0"
set "LOG=%~dp0build_log.txt"

echo ============================================
echo  Personal Gnome - PersonalGnome.exe derleniyor
echo ============================================
echo Ayrintili cikti ekrana degil build_log.txt dosyasina yazilir.
echo.

if not exist "app.py" (
  echo HATA: app.py bu klasorde yok.
  echo Buyuk ihtimalle build.bat zip dosyasinin ICINDEN calistirildi.
  echo Cozum: personal-gnome.zip dosyasina sag tikla ^> "Tumunu ayikla" ^> cikan klasordeki build.bat dosyasina cift tikla.
  goto :son_hata
)
if not exist "assets\logo.ico" (
  echo HATA: assets klasoru eksik. Zip dosyasini eksiksiz ayikla.
  goto :son_hata
)
if not exist "personal-gnome-vscode.vsix" (
  echo HATA: personal-gnome-vscode.vsix bu klasorde yok. Zip dosyasini eksiksiz ayikla.
  goto :son_hata
)

> "%LOG%" echo Personal Gnome derleme gunlugu
>> "%LOG%" echo Baslangic: %date% %time%

rem --- Bellek durumu (bellek dolarsa Windows programlari cokertir)
powershell -NoProfile -Command "$o = Get-CimInstance Win32_OperatingSystem; $f = [math]::Round($o.FreePhysicalMemory / 1MB, 1); $t = [math]::Round($o.TotalVisibleMemorySize / 1MB, 1); Write-Output ('Bos bellek: ' + $f + ' GB / toplam ' + $t + ' GB'); if ($f -lt 2) { exit 2 }"
if "%ERRORLEVEL%"=="2" (
  echo UYARI: Bos bellek 2 GB'tan az. Once tarayici, oyun gibi buyuk programlari kapat.
  echo Devam etmek icin bir tusa bas. Vazgecmek icin bu pencereyi kapat.
  pause >nul
)

rem --- Calisan PersonalGnome.exe dist klasorundeki dosyayi kilitler
tasklist /FI "IMAGENAME eq PersonalGnome.exe" 2>nul | find /I "PersonalGnome.exe" >nul
if not errorlevel 1 (
  echo UYARI: PersonalGnome.exe su anda calisiyor. Tepsi ikonundan Cikis yap, sonra bir tusa bas.
  pause >nul
)

rem --- Desteklenen Python: 3.12 - 3.14. Sesli not icin gereken onnxruntime paketinin
rem     Python 3.15 icin Windows dosyasi henuz yok.
set "PY="
call :dene "py -3.13"
call :dene "py -3.12"
call :dene "py -3.14"
call :dene "python"
if not defined PY goto :python_yok
for /f "delims=" %%i in ('%PY% --version 2^>^&1') do echo Python bulundu: %%i
>> "%LOG%" echo Python: %PY%

rem Her Python surumu icin ayri sanal ortam: baska surumle kurulmus eski ortam karismasin.
%PY% -c "import sys; print(sys.version_info[0] * 100 + sys.version_info[1])" > ".pyver.tmp" || goto :hata
set /p PYV=<".pyver.tmp"
set "VENV=.venv-build-%PYV%"
set "VPY=%VENV%\Scripts\python.exe"
echo.

echo [1/4] Sanal ortam hazirlaniyor (%VENV%)...
>> "%LOG%" echo ===== [1/4] sanal ortam
if exist "%VPY%" goto :venv_hazir
%PY% -m venv "%VENV%" >> "%LOG%" 2>&1 || goto :hata
:venv_hazir

echo [2/4] Paketler kuruluyor. Ilk seferde birkac dakika surer ve internet gerekir...
>> "%LOG%" echo ===== [2/4] paketler
"%VPY%" -m pip install --disable-pip-version-check -r requirements.txt -r requirements-voice.txt pyinstaller >> "%LOG%" 2>&1 || goto :hata

echo [3/4] Exe derleniyor. Birkac dakika surebilir, pencere bu sirada sessiz kalir...
>> "%LOG%" echo ===== [3/4] PyInstaller
"%VPY%" -m PyInstaller --noconfirm --onefile --windowed --name PersonalGnome ^
  --hidden-import pynput.keyboard._win32 --hidden-import pynput.mouse._win32 ^
  --hidden-import pystray._win32 ^
  --collect-all faster_whisper --collect-all ctranslate2 --collect-all _sounddevice_data ^
  --collect-data tzdata ^
  --add-data "personal-gnome-vscode.vsix;." ^
  --add-data "assets\logo.png;assets" --icon "assets\logo.ico" ^
  app.py >> "%LOG%" 2>&1 || goto :hata

echo [4/4] Exe icindeki bilesenler kontrol ediliyor (en fazla 2 dk)...
>> "%LOG%" echo ===== [4/4] paket testi
set "PT=%USERPROFILE%\.kaldigim_yer\paket_testi.txt"
if not exist "%USERPROFILE%\.kaldigim_yer" mkdir "%USERPROFILE%\.kaldigim_yer"
> "%PT%" echo Paket testi: calismadi
powershell -NoProfile -Command "$p = Start-Process -FilePath 'dist\PersonalGnome.exe' -ArgumentList '--paket-testi' -PassThru; if (-not $p.WaitForExit(120000)) { taskkill /T /F /PID $p.Id | Out-Null; Write-Output 'Paket testi 2 dakikada bitmedi, durduruldu.'; exit 1 }"
chcp 65001 >nul
type "%PT%"
type "%PT%" >> "%LOG%"
findstr /c:"Paket testi: tamam" "%PT%" >nul || echo UYARI: Paket testinde hata var, yukaridaki satirlara bak.

echo.
echo BASARILI: dist\PersonalGnome.exe hazir.
>> "%LOG%" echo Bitis: %date% %time%
start "" explorer dist
goto :son

:hata
echo.
echo HATA: Derleme yukaridaki adimda durdu. build_log.txt dosyasinin son satirlari:
echo --------------------------------------------
powershell -NoProfile -Command "Get-Content -LiteralPath '%LOG%' -Tail 30"
echo --------------------------------------------
echo Bu pencerenin ekran goruntusunu veya build_log.txt dosyasini gonder.
:son_hata
echo.
pause
exit /b 1

:son
echo.
pause
exit /b 0

:python_yok
echo HATA: Uygun Python bulunamadi. Gerekli: Python 3.12, 3.13 veya 3.14.
echo Bilgisayarda bulunan:
python --version 2>nul
echo.
echo Neden: sesli not icin gereken onnxruntime paketi Python 3.15 icin henuz yayinlanmadi.
echo Cozum - mevcut Python silinmez, yan yana calisir:
echo   1. Baslat menusunde "cmd" ac ve su komutu yaz:  py install 3.13
echo   2. Bu komut taninmazsa https://www.python.org/downloads/ adresinden Python 3.13 indirip kur.
echo Sonra build.bat dosyasini tekrar calistir.
goto :son_hata

rem Verilen Python 3.12-3.14 araligindaysa PY olarak sec.
:dene
if defined PY exit /b 0
%~1 -c "import sys; sys.exit(0 if (3, 12) <= sys.version_info[:2] <= (3, 14) else 1)" >nul 2>&1 && set "PY=%~1"
exit /b 0
