"""Sistem tepsisi (saat yanındaki) ikonu. pystray ile, yalnızca Windows'ta.

Menü tıklamaları arayüze doğrudan dokunmaz; olay kuyruğuna ("tray", eylem) koyar
(Tkinter iş parçacığı güvenli değildir). Sol tık = varsayılan öğe (Göster / Gizle).
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path

RENKLER = {"normal": (90, 120, 160), "kesinti": (230, 160, 40), "donus": (80, 170, 90)}

# (menü yazısı, eylem). None = ayırıcı.
MENU = [("Göster / Gizle", "toggle"), ("Bölündüm (not bırak)", "park"), ("Kartı göster", "card"),
        ("Şerit / Sabit", "strip"), None, ("Çıkış", "quit")]


_LOGO = []  # önbellek: [Image | None]


def logo_path() -> Path:
    """Logo dosyası: .exe içinde (PyInstaller geçici klasörü) ya da kaynak klasöründe."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / "assets" / "logo.png"


def _logo():
    if not _LOGO:
        try:
            from PIL import Image
            p = logo_path()
            _LOGO.append(Image.open(p).convert("RGBA") if p.is_file() else None)
        except Exception:
            _LOGO.append(None)
    return _LOGO[0]


def make_image(state: str = "normal", size: int = 64):
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2, 2, size - 3, size - 3), fill=RENKLER.get(state, RENKLER["normal"]) + (255,))
    logo = _logo()
    if logo is not None:  # durum rengi halka olarak kalır, ortada logo
        inner = int(size * 0.78)
        mark = logo.resize((inner, inner), Image.LANCZOS)
        img.alpha_composite(mark, ((size - inner) // 2, (size - inner) // 2))
        return img
    # "K" harfi: yazı tipi gerektirmesin diye çizgilerle
    w = max(3, size // 9)
    x0, x1, y0, y1, ym = size * 0.34, size * 0.70, size * 0.24, size * 0.76, size * 0.5
    d.line((x0, y0, x0, y1), fill="white", width=w)
    d.line((x0, ym, x1, y0), fill="white", width=w)
    d.line((x0 + w * 0.3, ym - w * 0.3, x1, y1), fill="white", width=w)
    return img


class Tray:
    def __init__(self, events):
        self.events = events
        self.state = "normal"
        self.icon = None
        self.error = ""
        if sys.platform != "win32":
            self.error = "tepsi ikonu yalnızca Windows'ta"
            return
        try:
            import pystray
        except Exception as exc:  # paket yok / arka uç yüklenemedi: tepsisiz devam
            self.error = f"pystray yüklenemedi: {exc}"
            return
        items = []
        for entry in MENU:
            if entry is None:
                items.append(pystray.Menu.SEPARATOR)
                continue
            text, action = entry
            items.append(pystray.MenuItem(text, self._handler(action), default=(action == "toggle")))
        self.icon = pystray.Icon("PersonalGnome", make_image("normal"), "Personal Gnome",
                                 pystray.Menu(*items))

    def _handler(self, action: str):
        return lambda icon, item: self.events.put(("tray", action))

    @property
    def ok(self) -> bool:
        return self.icon is not None

    def start(self) -> None:
        if self.icon is not None:
            # pystray'in Windows arka ucu kendi mesaj döngüsünü bu iş parçacığında çalıştırır.
            threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        try:
            self.icon.run()
        except Exception as exc:
            print(f"[tepsi] durdu: {exc}")

    def set_state(self, state: str) -> None:
        if self.icon is None or state == self.state:
            return
        self.state = state
        try:
            self.icon.icon = make_image(state)
        except Exception as exc:
            print(f"[tepsi] ikon güncellenemedi: {exc}")

    def stop(self) -> None:
        if self.icon is not None:
            try:
                self.icon.stop()
            except Exception:
                pass
