"""Panel davranış testleri. Tkinter ve ekran gerekir (Linux'ta: xvfb-run python -m pytest)."""
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

tk = pytest.importorskip("tkinter")

import core  # noqa: E402

# Uygulama gibi tek bir Tk kökü; her test kendi panel penceresini (Toplevel) açar.
try:
    ROOT = tk.Tk()
    ROOT.withdraw()
except tk.TclError:
    pytest.skip("ekran yok", allow_module_level=True)

import panel as panel_mod  # noqa: E402


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def make_repo(name="oyun") -> str:
    d = Path(tempfile.mkdtemp()) / name
    d.mkdir()
    g = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
    g("init", "-q", "-b", "main")
    g("config", "user.email", "t@t")
    g("config", "user.name", "t")
    (d / "auth.py").write_text("x = 1\ny = 2\n")
    g("add", ".")
    g("commit", "-qm", "ilk")
    (d / "auth.py").write_text("x = 1\ny = 3\n")
    return str(d)


class Q:
    def __init__(self):
        self.items = []

    def put(self, x):
        self.items.append(x)


@pytest.fixture
def panel():
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [make_repo()], Q(), "<ctrl>+<shift>+<f9>", "<ctrl>+<shift>+<f10>",
                        title_provider=lambda: "auth.py - oyun - Visual Studio Code")
    root.update()
    yield p
    try:
        p.close()
    except tk.TclError:
        pass


def test_default_geometry_right_18_percent(panel):
    sw, sh = panel.root.winfo_screenwidth(), panel.root.winfo_screenheight()
    panel.root.update()
    assert panel.root.winfo_width() == round(sw * 0.18)
    assert panel.root.winfo_x() == sw - round(sw * 0.18)
    assert panel.root.winfo_height() == sh


def test_resize_clamped_and_side_toggle_persist(panel):
    for _ in range(5):
        panel.resize(+1)
    assert panel.pct == 20
    for _ in range(10):
        panel.resize(-1)
    assert panel.pct == 15
    panel.toggle_side()
    panel.root.update()
    assert panel.taraf == "sol" and panel.root.winfo_x() == 0
    assert core.panel_settings() == ("sol", 15)


def test_fullscreen_toggle(panel):
    sw = panel.root.winfo_screenwidth()
    panel.toggle_fullscreen()
    panel.root.update()
    assert panel.root.winfo_width() == sw and panel.root.winfo_x() == 0
    panel.toggle_fullscreen()
    panel.root.update()
    assert panel.root.winfo_width() == round(sw * 0.18)


def test_auto_park_escape_saves_without_note(panel):
    panel.start_park("toplantı", True, "mikrofon: Zoom.exe")
    assert panel.ignore_btn.winfo_manager() == "pack"          # "yok say" görünür
    panel.escape()
    k = core.last_record()
    assert k.not_metni == "" and k.kaynak == "toplanti" and k.dosyalar == ["auth.py"] and k.satir == 2
    assert panel.pending is None


def test_manual_park_snapshot_taken_at_start_then_note(panel):
    panel.start_park("soru", False, "")
    t0 = panel.pending["zaman"]
    time.sleep(0.05)
    panel.entry.insert("1.0", "y=3 neden testte patlıyor bak")
    assert panel.save()
    k = core.last_record()
    assert k.zaman == t0 and k.tur == "soru" and k.kaynak == "kisayol"
    assert k.pencere == "auth.py - oyun - Visual Studio Code"


def test_manual_escape_cancels(panel):
    panel.start_park("diğer", False, "")
    panel.escape()
    assert panel.pending is None and core.last_record() is None


def test_type_and_save_without_pending(panel):
    assert panel.save() is False                                 # boş not kaydedilmez
    panel.entry.insert("1.0", "panelden doğrudan not")
    assert panel.save()
    assert core.last_record().not_metni == "panelden doğrudan not"


def test_card_commits_pending_with_typed_text(panel):
    panel.start_park("toplantı", True, "mikrofon: Zoom.exe")
    panel.entry.insert("1.0", "yarım kalan not")
    panel.show_card("toplantı bitti")
    k = core.last_record()
    assert k.not_metni == "yarım kalan not" and panel.pending is None
    assert "yarım kalan not" in panel.card_text()
    assert panel.status.cget("text").startswith("Toplantı bitti")


def test_silent_commits_pending_instead_of_duplicate(panel):
    panel.start_park("diğer", False, "")
    panel.entry.insert("1.0", "not")
    panel.on_silent("mola", "auth.py - oyun - Visual Studio Code")
    recs = core.load_records()
    assert len(recs) == 1 and recs[0].not_metni == "not"


def test_silent_without_pending_and_card_shows_previous_note(panel):
    panel.entry.insert("1.0", "token testini yaz")
    panel.save()
    panel.on_silent("mola", "auth.py - oyun - Visual Studio Code")
    panel.show_card("geri döndün")
    text = panel.card_text()
    assert "token testini yaz" in text and "bıraktığın not" in text and "Proje: oyun" in text


def test_ignore_button_persists(panel):
    panel.start_park("toplantı", True, "mikrofon: Discord.exe")
    panel._ignore_clicked()
    assert core.load_ignore() == ["discord.exe"] and core.last_record() is None
    assert panel.ign_list.get(0) == "discord.exe"


def test_history_and_report_tabs(panel):
    for note in ("bir", "iki"):
        panel.entry.insert("1.0", note)
        panel.save()
    assert panel.hist.size() == 2 and "iki" in panel.hist.get(0)
    panel.hist.selection_set(1)
    panel._hist_select()
    assert "bir" in panel.hist_card.cget("text")
    assert "2 kesinti kaydı" in panel.report_text.get("1.0", "end")


def test_voice_result_fills_note(panel):
    panel._voice_done("sesle bırakılan not", "")
    assert panel.note_text() == "sesle bırakılan not"
    panel._voice_done("", "model yok")
    assert "Ses çevrilemedi" in panel.status.cget("text")


def test_add_and_remove_repo_persist():
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [], Q())
    root.update()
    assert "proje klasörü ekle" in p.card_text()
    p._add_repo(str(Path(tempfile.mkdtemp()) / "yok"))          # olmayan klasör
    assert p.repos == [] and "bulunamadı" in p.status.cget("text")
    duz = tempfile.mkdtemp()                                     # git'siz klasör de kabul edilir
    p._add_repo(duz)
    assert p.repos == [duz] and "git yok" in p.status.cget("text")
    repo = make_repo("site")
    p._add_repo(repo)
    assert p.repos == [duz, repo] and core.load_repos() == [duz, repo]
    assert "git: dosya + satır" in p.status.cget("text")
    p.repo_list.selection_set(0)
    p._remove_repo()
    assert p.repos == [repo] and core.load_repos() == [repo]
    p.close()


def test_cli_repos_not_saved():
    root = tk.Toplevel(ROOT)
    repo = make_repo()
    p = panel_mod.Panel(root, [repo], Q(), cli_repos=True)
    p._add_repo(make_repo("ikinci"))
    assert len(p.repos) == 2 and core.load_repos() == []
    p.close()


def test_close_destroys_window(panel):
    panel.close()
    assert not panel.root.winfo_exists()


def test_pretty_key():
    assert panel_mod.pretty_key("<ctrl>+<shift>+<f9>") == "Ctrl+Shift+F9"
    assert panel_mod.pretty_key("<ctrl>+<shift>+k") == "Ctrl+Shift+K"
    assert panel_mod.pretty_key("") == ""


def test_voice_flow_with_fake_recorder(panel, monkeypatch):
    import voice

    class FakeRec:
        def start(self):
            pass

        def stop(self):
            return b"ses"

    if panel.mic_btn is None:
        pytest.skip("ses paketleri kurulu değil")
    monkeypatch.setattr(voice, "Recorder", FakeRec)
    monkeypatch.setattr(voice, "transcribe", lambda audio: "sesle not")
    panel.toggle_voice()
    assert panel.mic_btn.cget("text") == "Bitir"
    panel.toggle_voice()                                          # durdur -> arka planda çevir
    for _ in range(50):
        if panel.events.items:
            break
        time.sleep(0.05)
    assert panel.events.items[-1] == ("voice_done", "sesle not", "")
    panel._voice_done("sesle not", "")
    assert panel.note_text() == "sesle not" and panel.mic_btn.cget("text") == "Konuş"


def test_voice_mic_unavailable_message(panel, monkeypatch):
    import voice

    class BrokenRec:
        def start(self):
            raise OSError("ses aygıtı yok")

    if panel.mic_btn is None:
        pytest.skip("ses paketleri kurulu değil")
    monkeypatch.setattr(voice, "Recorder", BrokenRec)
    panel.toggle_voice()
    assert panel.recorder is None and "Mikrofon açılamadı" in panel.status.cget("text")


def test_goto_button_text_git_vs_plain(monkeypatch):
    monkeypatch.setattr(panel_mod.shutil, "which", lambda name: "/usr/bin/code")
    # git deposu: satır biliniyor
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [make_repo()], Q())
    p.entry.insert("1.0", "not")
    p.save()
    assert p.goto_btn.winfo_manager() == "pack" and p.goto_btn.cget("text") == "Kaldığın satıra git"
    p.close()
    # git'siz klasör: satır bilinmiyor
    d = Path(tempfile.mkdtemp()) / "duz"
    d.mkdir()
    (d / "oyun.gd").write_text("x\n")
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [str(d)], Q())
    p.entry.insert("1.0", "not")
    p.save()
    assert p.goto_btn.cget("text") == "Dosyayı aç" and p._goto_target == (d / "oyun.gd", 0)
    p.close()


def test_open_in_editor_arguments(monkeypatch):
    calls = []
    monkeypatch.setattr(panel_mod.shutil, "which", lambda name: "/usr/bin/code")
    monkeypatch.setattr(panel_mod.subprocess, "Popen", lambda args: calls.append(args))
    assert panel_mod.open_in_editor(Path("/p/a.py"), 12)
    assert panel_mod.open_in_editor(Path("/p/b.gd"), 0)
    assert calls == [["/usr/bin/code", "-g", "/p/a.py:12"], ["/usr/bin/code", "/p/b.gd"]]
    assert not panel_mod.open_in_editor(Path("/p/a&b.py"), 1)   # cmd özel karakteri: açma


# ====================================================================== 2. sürüm özellikleri
import app  # noqa: E402
import dock as dock_mod  # noqa: E402
import ekran  # noqa: E402
import isler  # noqa: E402


def git(repo, *a):
    subprocess.run(["git", "-C", repo, *a], check=True, capture_output=True)


def test_bolundum_button_freezes_state_and_saves(panel):
    panel.bolundum_btn.invoke()
    assert panel.pending is not None and panel.pending["kaynak"] == "kisayol"
    assert panel.pending["pencere"] == "auth.py - oyun - Visual Studio Code"
    assert panel.status.cget("bg") == panel_mod.RENK_KESINTI
    panel.entry.insert("1.0", "sıradaki: token testini yaz")
    panel.save()
    k = core.last_record()
    assert k.kaynak == "kisayol" and k.dosyalar == ["auth.py"] and k.satir == 2
    assert k.satir_kaynak == "git"
    assert [i["metin"] for i in isler.open_items()] == ["token testini yaz"]
    assert "1 adım İşler'e eklendi" in panel.status.cget("text")


def test_job_defaults_to_branch_and_chain_on_card(panel):
    repo = panel.repos[0]
    git(repo, "checkout", "-qb", "login-fix")
    panel.start_park("diğer", False, "")
    assert panel.job.get() == "login-fix"
    panel.entry.insert("1.0", "ilk not https://github.com/x/y/issues/7 sıradaki: form doğrulama")
    panel.save()
    panel.start_park("mesaj", False, "")
    panel.entry.insert("1.0", "ikinci not")
    panel.save()
    k = core.last_record()
    assert k.is_adi == "login-fix"
    text = panel.card_text()
    assert "İş: login-fix" in text and "Bu işteki önceki notlar:" in text and "ilk not" in text
    assert "[ ] form doğrulama" in text
    assert panel.devam_btn.winfo_manager() == "pack" and "1 bağlantı" in panel.devam_btn.cget("text")


def test_manual_job_name_is_kept(panel):
    git(panel.repos[0], "checkout", "-qb", "ozellik")
    panel.job.set("benim işim")
    panel._job_touched()
    panel.start_park("diğer", False, "")
    assert panel.job.get() == "benim işim"            # elle yazılan iş adı ezilmez
    panel.save(not_metni="x")
    assert core.last_record().is_adi == "benim işim"


def test_devam_opens_file_and_links(panel, monkeypatch):
    opened, edited = [], []
    monkeypatch.setattr(panel_mod.webbrowser, "open", lambda u, new=0: opened.append(u))
    monkeypatch.setattr(panel_mod, "open_in_editor", lambda p, l=0: edited.append((p.name, l)) or True)
    monkeypatch.setattr(panel_mod.shutil, "which", lambda n: "/usr/bin/code")
    panel.entry.insert("1.0", "bak https://a.dev/1 ve https://a.dev/2.")
    panel.save()
    panel.devam_btn.invoke()
    assert opened == ["https://a.dev/1", "https://a.dev/2"] and edited == [("auth.py", 2)]


def test_markdown_and_standup_copy(panel):
    panel.entry.insert("1.0", "kart notu")
    panel.save()
    panel.md_btn.invoke()
    assert panel.root.clipboard_get().startswith("### Personal Gnome: oyun")
    panel.copy_standup()
    clip = panel.root.clipboard_get()
    assert "Engeller:" in clip and "kart notu" in clip


def test_jobs_tab_add_toggle_delete_rename(panel):
    panel.job.set("rapor")
    panel.step_entry.insert(0, "grafik ekle")
    panel._add_step()
    assert panel.jobs_list.get(0) == "[ ] grafik ekle  (rapor)"
    panel.jobs_filter.set("rapor")
    panel.refresh_jobs()
    assert panel.jobs_list.get(0) == "[ ] grafik ekle"
    panel.jobs_list.selection_set(0)
    panel._toggle_step()
    assert panel.jobs_list.size() == 0                 # biten gizli
    panel.show_done.set(True)
    panel.refresh_jobs()
    assert panel.jobs_list.get(0) == "[x] grafik ekle"
    panel._rename_job("aylık rapor")
    assert panel.jobs_filter.get() == "aylık rapor" and isler.load_items()[0]["is_adi"] == "aylık rapor"
    panel.jobs_list.selection_set(0)
    panel._delete_step()
    assert isler.load_items() == []


def test_history_filter_by_job(panel):
    for job, note in (("a", "bir"), ("b", "iki"), ("a", "üç")):
        panel.job.set(job)
        panel._job_touched()
        panel.entry.insert("1.0", note)
        panel.save()
    panel.refresh_history()
    assert panel.hist.size() == 3 and "[a] üç" in panel.hist.get(0)
    panel.hist_filter.set("a")
    panel.refresh_history()
    assert [panel.hist.get(i).split("  ")[-1] for i in range(panel.hist.size())] == ["üç", "bir"]


def test_report_includes_insight(panel):
    panel.entry.insert("1.0", "x")
    panel.save()
    text = panel.report_text.get("1.0", "end")
    assert "kesinti kaydı" in text and "İÇGÖRÜ" in text


# ---------------------------------------------------------------- şerit modu
def test_strip_mode_reserve_expand_collapse(panel, monkeypatch):
    sw, sh = panel.root.winfo_screenwidth(), panel.root.winfo_screenheight()
    full = round(sw * 0.18)
    panel.toggle_strip()
    panel.root.update()
    assert core.get_setting("serit") is True and panel.strip_var.get()
    assert panel.dock.reserved == (sw - panel_mod.SERIT_PX, 0, panel_mod.SERIT_PX, sh)
    assert panel.root.winfo_width() == panel_mod.SERIT_PX and panel.strip.winfo_manager() == "place"

    clock = {"t": 1000.0}
    monkeypatch.setattr(panel_mod.time, "monotonic", lambda: clock["t"])
    pointer = {"xy": (sw - 3, 500)}                          # fare kenarda
    monkeypatch.setattr(panel.root, "winfo_pointerxy", lambda: pointer["xy"])
    panel._strip_tick()
    panel.root.update()
    assert panel.expanded and panel.root.winfo_width() == full and panel.root.winfo_x() == sw - full
    assert panel.dock.reserved[2] == panel_mod.SERIT_PX      # ayrılan alan değişmedi

    pointer["xy"] = (100, 500)                               # fare ayrıldı
    clock["t"] += 1.0
    panel._strip_tick()
    assert panel.expanded                                    # 2 sn dolmadı
    clock["t"] += 1.5
    panel._strip_tick()
    panel.root.update()
    assert not panel.expanded and panel.root.winfo_width() == panel_mod.SERIT_PX


def test_strip_stays_open_while_note_pending_and_after_card(panel, monkeypatch):
    panel.toggle_strip()
    clock = {"t": 50.0}
    monkeypatch.setattr(panel_mod.time, "monotonic", lambda: clock["t"])
    monkeypatch.setattr(panel.root, "winfo_pointerxy", lambda: (5, 5))   # fare uzakta
    panel.start_park("diğer", False, "")                     # kesinti: açılır
    assert panel.expanded
    clock["t"] += 60
    panel._strip_tick()
    assert panel.expanded                                    # not bekliyor: daralmaz
    panel.save(not_metni="tamam")
    panel.show_card("geri döndün")                           # kart: en az 20 sn açık
    clock["t"] += 10
    panel._strip_tick()
    assert panel.expanded
    clock["t"] += 15
    panel.root.focus_set()
    monkeypatch.setattr(panel.root, "focus_get", lambda: None)
    panel._strip_tick()
    assert not panel.expanded


def test_strip_setting_persists_across_restart():
    core.set_setting("serit", True)
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [], Q())
    root.update()
    assert p.strip_mode and not p.expanded and root.winfo_width() == panel_mod.SERIT_PX
    p.toggle_strip()
    root.update()
    assert not p.strip_mode and root.winfo_width() == round(root.winfo_screenwidth() * 0.18)
    p.close()


def test_fullscreen_mode_ignores_strip(panel):
    panel.toggle_strip()
    panel.toggle_fullscreen()
    panel.root.update()
    assert panel.root.winfo_width() == panel.root.winfo_screenwidth()
    assert panel.strip.winfo_manager() == ""
    panel.toggle_fullscreen()
    panel.root.update()
    assert panel.root.winfo_width() == panel_mod.SERIT_PX


# ---------------------------------------------------------------- yeniden yerleşme + tam ekran
def test_redock_when_screen_signature_changes(panel, monkeypatch):
    calls = []
    orig = panel.place
    monkeypatch.setattr(panel, "place", lambda: calls.append(1) or orig())
    panel._slow_tick()
    assert calls == []                                       # değişiklik yok: SETPOS yok
    panel.dock._sig = ("eski",)
    panel._slow_tick()
    assert calls == [1]
    panel._slow_tick()
    assert calls == [1]                                      # bir kez


def test_topmost_dropped_for_fullscreen_app(panel, monkeypatch):
    # Xvfb'de pencere yöneticisi olmadığı için -topmost geri okunamıyor; yapılan çağrıları izle.
    calls = []
    orig = panel.root.attributes
    monkeypatch.setattr(panel.root, "attributes",
                        lambda *a: calls.append(a[1]) if a[:1] == ("-topmost",) and len(a) == 2 else orig(*a))
    panel._topmost = None
    panel._slow_tick()
    assert calls == [True]
    panel._slow_tick()
    assert calls == [True]                                   # değişmedi: tekrar çağrılmaz
    monkeypatch.setattr(dock_mod, "fullscreen_app_active", lambda own=(): True)
    panel._slow_tick()
    assert calls == [True, False]
    monkeypatch.setattr(dock_mod, "fullscreen_app_active", lambda own=(): False)
    panel._slow_tick()
    assert calls == [True, False, True]
    panel.toggle_fullscreen()                                # kendi tam ekranımız: en üstte değil
    assert calls[-1] is False
    panel.toggle_fullscreen()
    assert calls[-1] is True


# ---------------------------------------------------------------- tema
def test_dark_theme_and_back(panel):
    light_bg = panel.status.cget("bg")
    entry_bg = panel.entry.cget("bg")
    panel.theme_combo.set("Koyu")
    panel._theme_selected()
    assert core.get_setting("tema") == "koyu" and panel.theme.current == "koyu"
    assert panel.status.cget("bg") == tema_mod.KOYU["bg"] and panel.entry.cget("bg") == tema_mod.KOYU["alan"]
    panel.set_status("kesinti", panel_mod.RENK_KESINTI)
    assert panel.status.cget("bg") == panel_mod.RENK_KESINTI and panel.status.cget("fg") == "#000000"
    panel.set_status("normal")
    panel.theme_combo.set("Açık")
    panel._theme_selected()
    assert panel.status.cget("bg") == light_bg and panel.entry.cget("bg") == entry_bg
    assert panel.theme.style.theme_use() == panel.theme.light_theme


def test_system_theme_follows_registry(panel, monkeypatch):
    monkeypatch.setattr(tema_mod, "system_prefers_dark", lambda: True)
    panel.theme_combo.set("Windows'a uy")
    panel._theme_selected()
    assert panel.theme.current == "koyu"
    monkeypatch.setattr(tema_mod, "system_prefers_dark", lambda: False)
    for _ in range(5):
        panel._slow_tick()
    assert panel.theme.current == "acik"


import tema as tema_mod  # noqa: E402


# ---------------------------------------------------------------- tepsi: gizle / göster
class FakeTray:
    ok = True

    def __init__(self):
        self.states, self.stopped = [], False

    def set_state(self, s):
        self.states.append(s)

    def stop(self):
        self.stopped = True


def test_x_hides_to_tray_and_events_show_again(panel):
    panel.tray = FakeTray()
    panel.on_x()
    panel.root.update()
    assert panel.hidden and panel.root.state() == "withdrawn" and panel.root.winfo_exists()
    app.handle_event(panel, ("park", "toplantı", True, "mikrofon: Zoom.exe"))   # kesinti gelince görünür
    panel.root.update()
    assert not panel.hidden and panel.root.state() == "normal" and panel.pending is not None
    assert panel.tray.states[-1] == "kesinti"
    panel.escape()
    app.handle_event(panel, ("tray", "toggle"))
    assert panel.hidden
    app.handle_event(panel, ("tray", "card"))
    assert not panel.hidden and panel.tray.states[-1] == "normal"


def test_x_without_tray_closes(panel):
    panel.on_x()
    assert not panel.root.winfo_exists()


def test_tray_menu_events(panel):
    panel.tray = FakeTray()
    app.handle_event(panel, ("tray", "park"))
    assert panel.pending is not None and panel.pending["kaynak"] == "kisayol"
    panel.escape()
    app.handle_event(panel, ("tray", "strip"))
    assert panel.strip_mode
    tray_obj = panel.tray
    app.handle_event(panel, ("tray", "quit"))
    assert tray_obj.stopped and not panel.root.winfo_exists()


# ---------------------------------------------------------------- ekran görüntüsü
def test_screenshot_saved_with_record_when_enabled(panel, monkeypatch):
    calls = []
    monkeypatch.setattr(ekran, "capture", lambda hwnd, geo, sw, sh, zaman: calls.append(geo) or "x.png")
    panel.start_park("diğer", False, "")
    panel.save(not_metni="kapalıyken")
    assert calls == [] and core.last_record().ekran == ""     # varsayılan kapalı
    panel.shot_var.set(True)
    panel._shot_checked()
    panel.start_park("diğer", False, "")
    panel.save(not_metni="açıkken")
    assert calls == [panel.geo] and core.last_record().ekran == "x.png"
    assert "Ekran görüntüsü: var" in panel.card_text()
    assert panel.shot_btn.winfo_manager() == "pack"
    panel.on_silent("mola", "VS Code")
    assert core.last_record().ekran == "x.png" and len(calls) == 2


# ---------------------------------------------------------------- takvim
def test_calendar_reminder_then_mic_does_not_duplicate(panel):
    app.handle_event(panel, ("park", "toplantı", True, "takvim: Sprint 14:00"))
    assert panel.pending["kaynak"] == "takvim" and "Toplantı yaklaşıyor (Sprint 14:00)" in panel.park_info.cget("text")
    panel.entry.insert("1.0", "login yarım")
    panel.save()
    assert core.last_record().kaynak == "takvim"
    app.handle_event(panel, ("park", "toplantı", True, "mikrofon: Zoom.exe"))
    assert panel.pending is None and "takvim hatırlatmasında" in panel.status.cget("text")
    assert len(core.load_records()) == 1
    assert "takvim hatırlatması 1" in core.report(1)


def test_calendar_settings_save_and_status(panel):
    class W:
        n = 0

        def refresh_now(self):
            W.n += 1

    panel.calendar_watcher = W()
    panel.cal_url.insert(0, "webcal://x.com/gizli.ics")
    panel.cal_dk.set("40")
    panel._save_calendar()
    assert core.get_setting("takvim_url") == "webcal://x.com/gizli.ics" and core.get_setting("takvim_dk") == 15
    assert panel.cal_dk.get() == "15" and W.n == 1
    app.handle_event(panel, ("cal_status", "Takvim 10:00 güncellendi."))
    assert panel.cal_status.cget("text") == "Takvim 10:00 güncellendi."
    assert panel.cal_url.cget("show") == "•"


def test_calendar_test_button_runs_in_background(panel, monkeypatch):
    import takvim
    monkeypatch.setattr(takvim, "test_url", lambda url: f"tamam {url}")
    panel.cal_url.insert(0, "https://x/y.ics")
    panel._test_calendar()
    for _ in range(50):
        if panel.events.items:
            break
        time.sleep(0.02)
    kind, fn = panel.events.items[-1]
    assert kind == "ui"
    fn()
    assert panel.cal_status.cget("text") == "tamam https://x/y.ics"


# ---------------------------------------------------------------- VS Code eklentisi düğmesi
def test_vscode_install_button(panel, monkeypatch):
    import vscode_ext
    monkeypatch.setattr(vscode_ext, "install", lambda: (True, "Kuruldu."))
    panel._install_ext()
    for _ in range(50):
        if panel.events.items:
            break
        time.sleep(0.02)
    app.handle_event(panel, panel.events.items[-1])
    assert panel.ext_status.cget("text") == "Kuruldu." and "kuruldu" in panel.status.cget("text")


def test_vscode_cursor_line_shown_on_card(panel):
    import json as _json
    import lines
    repo = Path(panel.repos[0])
    (core._data_dir() / lines.IMLEC_DOSYASI).write_text(_json.dumps(
        {"dosya": str(repo / "auth.py"), "satir": 1, "zaman": int(time.time() * 1000)}))
    panel.bolundum()
    panel.save(not_metni="imleç testi")
    assert "auth.py  (satır 1 - imleç, VS Code)" in panel.card_text()


# ---------------------------------------------------------------- dar panel + ayarlar
def test_short_tab_labels_when_narrow(panel):
    panel._update_tabs(150)
    assert [panel.nb.tab(t, "text") for t in panel.tabs] == ["Şimdi", "İş", "Geç.", "Rap.", "Ayar"]
    panel._update_tabs(1000)
    assert [panel.nb.tab(t, "text") for t in panel.tabs] == ["Şimdi", "İşler", "Geçmiş", "Rapor", "Ayarlar"]


def test_settings_are_scrollable_and_autostart_disabled_outside_exe(panel):
    assert isinstance(panel.set_canvas, tk.Canvas)
    panel.root.update()
    assert panel.set_canvas.bbox("all")[3] > 0
    import baslangic
    if not baslangic.available():
        cb = [w for w in panel.tab_set.winfo_children()]  # yapı var
        assert cb


def test_old_data_file_opens_in_new_panel():
    import json as _json
    core.data_file().write_text(_json.dumps([{"zaman": time.time() - 60, "not_metni": "eski not",
                                              "tur": "mola", "repo": "", "dosyalar": [], "satir": 1}]))
    root = tk.Toplevel(ROOT)
    p = panel_mod.Panel(root, [], Q())
    assert "eski not" in p.card_text()
    p.close()


def test_redock_loop_guard(panel, monkeypatch):
    calls = []
    monkeypatch.setattr(panel, "place", lambda: calls.append(1))
    monkeypatch.setattr(panel.dock, "changed", lambda: True)         # sürekli "değişti" diyen sistem
    for _ in range(10):
        panel._slow_tick()
    assert len(calls) == 5 and panel._redock_pause > 0               # 6. seferde durdu


def test_settings_wheel_scrolls_only_in_settings_tab(panel):
    panel.nb.select(panel.tab_set)
    panel.geo = (0, 0, 320, 500)                                      # içerik sığmasın: kaydırma gereksin
    panel.root.geometry("320x500+0+0")
    panel.root.update()
    c = panel.set_canvas
    c.yview_moveto(0)
    assert c.yview()[1] < 1.0
    target = panel.theme_combo                                       # bir alt widget'ın üstünde
    ev = type("E", (), {"x_root": target.winfo_rootx() + 2, "y_root": target.winfo_rooty() + 2,
                        "delta": -120, "num": 0})()
    if panel.root.winfo_containing(ev.x_root, ev.y_root) is None:
        pytest.skip("widget görünür alanda değil")
    panel._wheel(ev)
    panel.root.update()
    assert c.yview()[0] > 0
    panel.nb.select(panel.tab_now)
    before = c.yview()[0]
    panel._wheel(ev)
    assert c.yview()[0] == before


def test_title_shortens_instead_of_clipping(panel):
    panel._update_title(1000)
    assert panel.title_lbl.cget("text") == "Personal Gnome"
    panel._update_title(240)
    assert panel.title_lbl.cget("text") in ("PG", "")
    panel._update_title(150)
    assert panel.title_lbl.cget("text") == ""


def test_geometry_watchdog_reapplies_and_gives_up(panel, monkeypatch):
    panel.root.update()
    calls = []
    orig = panel.dock.set_geometry
    monkeypatch.setattr(panel.dock, "set_geometry", lambda g: calls.append(g) or orig(g))
    panel._fix_geometry()
    assert calls == []                                               # yerinde: dokunma
    panel.root.geometry("200x200+5+5")                               # sistem pencereyi kaydırdı
    panel.root.update()
    panel._fix_geometry()
    panel.root.update()
    assert calls == [panel.geo] and panel.root.winfo_x() == panel.geo[0]
    monkeypatch.setattr(panel.root, "winfo_x", lambda: 5)            # konum hiç tutmuyor
    for _ in range(6):
        panel._fix_geometry()
    assert len(calls) == 3 and panel._geo_fix_pause > 0              # dakikada 3 deneme, sonra vazgeçti


def test_error_in_one_tab_does_not_break_others(panel, monkeypatch, capsys):
    import icgoru
    monkeypatch.setattr(icgoru, "report", lambda days: 1 / 0)       # rapor sekmesi bozuk
    panel.entry.insert("1.0", "yine de kaydedilmeli")
    assert panel.save()
    assert "yine de kaydedilmeli" in panel.card_text()               # kart güncellendi
    assert "yine de" in panel.hist.get(0)                            # geçmiş güncellendi
    assert "refresh_report hata" in capsys.readouterr().out


def test_failing_timer_callback_keeps_loop_alive(panel, capsys):
    n = {"v": 0}

    def flaky():
        n["v"] += 1
        raise RuntimeError("geçici")

    panel._loop("deneme", 10, flaky)
    end = time.time() + 0.5
    while time.time() < end and n["v"] < 3:
        panel.root.update()
        time.sleep(0.02)
    assert n["v"] >= 3 and "[panel deneme] hata" in capsys.readouterr().out
