"""Çekirdek testleri: python -m pytest -q"""
import os
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

import core


@pytest.fixture(autouse=True)
def temp_data_dir(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())


def make_repo() -> Path:
    d = Path(tempfile.mkdtemp())
    run = lambda *a: subprocess.run(["git", "-C", str(d), *a], check=True, capture_output=True)
    run("init", "-q", "-b", "main")
    run("config", "user.email", "t@t")
    run("config", "user.name", "t")
    (d / "a.py").write_text("x = 1\n")
    (d / "b.py").write_text("y = 2\n")
    run("add", ".")
    run("commit", "-qm", "ilk")
    return d


def test_git_snapshot_finds_branch_and_changes():
    repo = make_repo()
    (repo / "a.py").write_text("x = 1\nx += 1\n")
    time.sleep(0.05)
    (repo / "yeni.py").write_text("z = 3\n")
    snap = core.git_snapshot(str(repo))
    assert snap["dal"] == "main"
    assert "1 file changed" in snap["diff_ozet"]
    assert snap["dosyalar"][0] == "yeni.py"  # en son dokunulan önce
    assert "a.py" in snap["dosyalar"]


def test_git_snapshot_outside_repo_is_empty():
    snap = core.git_snapshot(tempfile.mkdtemp())   # boş, git'siz klasör
    assert snap == {"dal": "", "diff_ozet": "", "dosyalar": [], "satir": 0, "git_deposu": False,
                    "satir_kaynak": ""}


def test_save_and_load_roundtrip(monkeypatch):
    monkeypatch.setenv("KALDIGIM_YER_DIR", tempfile.mkdtemp())
    repo = make_repo()
    k = core.make_record(str(repo), "  login testindeki null hatası  ", "toplantı", pencere="VS Code")
    core.save_record(k)
    last = core.last_record()
    assert last.not_metni == "login testindeki null hatası"
    assert last.tur == "toplantı" and last.dal == "main"


def test_format_card():
    k = core.Kayit(zaman=1000, not_metni="JWT yenilemeyi dene", tur="mesaj", repo="/r",
                   dal="feat/auth", diff_ozet="2 files changed", dosyalar=["auth.py"])
    card = core.format_card(k, now=1000 + 14 * 60)
    assert "14 dk önce ayrıldın (mesaj)" in card
    assert "JWT yenilemeyi dene" in card and "auth.py" in card


def test_sure_metni():
    assert core.sure_metni(30) == "1 dakikadan az"
    assert core.sure_metni(125 * 60) == "2 sa 5 dk"


def test_detect_meeting():
    assert core.detect_meeting([], []) is None
    assert core.detect_meeting([r"C:\Python312\python.exe"], []) is None  # kendi sesli notumuz
    assert core.detect_meeting([r"C:\Users\e\AppData\Roaming\Zoom\bin\Zoom.exe"], []) == "mikrofon: Zoom.exe"
    # Varsayılan başlık kalıbı yok: "meet.py" gibi dosya adları yanlış tetiklemez.
    assert core.detect_meeting([], ["meet.py - proje - Visual Studio Code"]) is None
    # Kullanıcı Windows'ta gördüğü gerçek başlığı ayarlara ekleyebilir.
    core._settings_file().write_text('{"pencere_kaliplari": ["^Zoom Meeting$"]}', encoding="utf-8")
    assert core.detect_meeting([], ["Zoom Meeting"]) == "pencere: Zoom Meeting"
    assert core.detect_meeting([], ["Zoom Workplace"]) is None


def test_first_changed_line():
    repo = make_repo()
    (repo / "a.py").write_text("x = 1\n" + "".join(f"s{i} = {i}\n" for i in range(10)))
    assert core.first_changed_line(str(repo), "a.py") == 2   # eklenen blok 2. satırda başlıyor
    (repo / "yeni.py").write_text("z = 3\n")
    assert core.first_changed_line(str(repo), "yeni.py") == 1  # izlenmeyen dosya
    snap = core.git_snapshot(str(repo))
    assert snap["satir"] == 1 and snap["dosyalar"][0] == "yeni.py"


def test_ignore_list_suppresses_meeting():
    discord = [r"C:\Users\e\AppData\Local\Discord\app-1.0\Discord.exe"]
    assert core.detect_meeting(discord, []) == "mikrofon: Discord.exe"
    core.add_ignore("Discord.exe")
    assert core.detect_meeting(discord, []) is None
    core.add_ignore("Discord.exe")
    assert core.load_ignore() == ["discord.exe"]  # tekrar eklenmez


def test_card_shows_recent_note_when_silent_record():
    repo = make_repo()
    notlu = core.make_record(str(repo), "token testini yaz", "diğer", pencere="")
    notlu.zaman -= 600
    core.save_record(notlu)
    sessiz = core.make_record(str(repo), "", "mola", otomatik=True, pencere="")
    core.save_record(sessiz)
    onceki = core.recent_note(sessiz)
    assert onceki is not None and onceki.not_metni == "token testini yaz"
    card = core.format_card(sessiz, now=sessiz.zaman + 120, onceki=onceki)
    assert "token testini yaz" in card and "12 dk önce bıraktığın not" in card


def test_recent_note_ignores_other_repo_and_old():
    a, b = make_repo(), make_repo()
    eski = core.make_record(str(a), "çok eski not", "diğer", pencere="")
    eski.zaman -= 5 * 3600
    core.save_record(eski)
    core.save_record(core.make_record(str(b), "başka depo", "diğer", pencere=""))
    sessiz = core.make_record(str(a), "", "mola", otomatik=True, pencere="")
    core.save_record(sessiz)
    assert core.recent_note(sessiz) is None


def test_old_json_without_satir_still_loads():
    core.data_file().write_text('[{"zaman": 1, "not_metni": "x", "tur": "diğer", "repo": "/r"}]',
                                encoding="utf-8")
    assert core.last_record().satir == 1


def test_snapshot_turkish_names_untracked_dirs_renames_deletes():
    repo = make_repo()
    g = lambda *a: subprocess.run(["git", "-C", str(repo), *a], check=True, capture_output=True)
    g("mv", "a.py", "taşındı.py")                       # yeniden adlandırma
    (repo / "b.py").unlink()                            # silinmiş dosya
    time.sleep(0.05)
    (repo / "yeni_klasör").mkdir()
    (repo / "yeni_klasör" / "envanter_çizimi.gd").write_text("x\n")
    snap = core.git_snapshot(str(repo))
    assert snap["dosyalar"][0] == "yeni_klasör/envanter_çizimi.gd"  # kaçış kodu yok, klasör açık
    assert "taşındı.py" in snap["dosyalar"]
    assert "b.py" not in snap["dosyalar"] and "a.py" not in snap["dosyalar"]


def test_is_git_repo():
    assert core.is_git_repo(str(make_repo()))
    assert not core.is_git_repo(tempfile.mkdtemp())


def test_unknown_keys_and_atomic_settings():
    core.data_file().write_text(
        '[{"zaman": 1, "not_metni": "x", "tur": "diğer", "repo": "/r", "gelecek_alan": 5}]',
        encoding="utf-8")
    assert core.last_record().not_metni == "x"            # bilinmeyen alan çökertmez
    core._settings_file().write_text('{"pencere_kaliplari": ["abc"]}', encoding="utf-8")
    core.add_ignore("OBS64.exe")
    s = core.load_settings()
    assert s["pencere_kaliplari"] == ["abc"] and s["yok_say"] == ["obs64.exe"]  # diğer ayar korunur
    assert not list(core._data_dir().glob("*.tmp"))


def test_invalid_user_pattern_does_not_crash():
    core._settings_file().write_text('{"pencere_kaliplari": ["Zoom(", "^Zoom Meeting$"]}',
                                     encoding="utf-8")
    assert core.detect_meeting([], ["Zoom Meeting"]) == "pencere: Zoom Meeting"


def test_atomic_write_retries_when_locked(monkeypatch):
    real_replace, calls = os.replace, {"n": 0}

    def flaky_replace(a, b):
        calls["n"] += 1
        if calls["n"] < 3:
            raise PermissionError("kilitli")
        real_replace(a, b)

    monkeypatch.setattr(core.os, "replace", flaky_replace)
    core.save_record(core.Kayit(zaman=1, not_metni="kilit testi", tur="diğer", repo="/r"))
    assert calls["n"] == 3 and core.last_record().not_metni == "kilit testi"


# ------------------------------------------------------------------ M2
def test_app_kind_defaults_and_settings():
    assert core.app_kind("code.exe", {}) == "work"
    assert core.app_kind("godot_v4.3-stable_win64.exe", {}) == "work"   # joker eşleşme
    assert core.app_kind("python.exe", {}) == "neutral"                   # kendi pencerelerimiz
    assert core.app_kind("whatsapp.exe", {}) == "other"
    assert core.app_kind("", {}) == "unknown"
    assert core.app_kind("blender.exe", {"calisma_uygulamalari": ["Blender.exe"]}) == "work"


def test_choose_repo_by_title_then_latest_change():
    a, b = make_repo(), make_repo()
    a_named = a.parent / ("oyun_" + a.name)
    a.rename(a_named)
    a = a_named
    title = f"main.gd - {a.name} - Visual Studio Code"
    assert core.choose_repo([str(b), str(a)], title) == str(a)
    # başlıkta ad yoksa: en son değişiklik yapılan depo
    (a / "a.py").write_text("eski\n")
    time.sleep(0.05)
    (b / "b.py").write_text("yeni\n")
    assert core.choose_repo([str(a), str(b)], "WhatsApp") == str(b)
    assert core.choose_repo([str(a)], "her şey") == str(a)


def test_update_record_and_mark_return():
    k = core.Kayit(zaman=1000.0, not_metni="", tur="mola", repo="/r")
    core.save_record(k)
    assert core.update_record(1000.0, not_metni="sonradan not")
    assert core.last_record().not_metni == "sonradan not"
    core.mark_return(now=1010.0)          # 30 sn dolmadan: dönüş sayılmaz
    assert core.last_record().donus == 0.0
    core.mark_return(now=1600.0)
    assert core.last_record().donus == 1600.0
    core.mark_return(now=2000.0)          # ikinci kez üzerine yazmaz
    assert core.last_record().donus == 1600.0
    assert core.update_record(9.0, not_metni="x") is False


def test_old_ai_field_in_json_is_ignored():
    core.data_file().write_text(
        '[{"zaman": 1, "not_metni": "", "tur": "mola", "repo": "/r", "ai_tahmin": "eski"}]',
        encoding="utf-8")
    k = core.last_record()
    assert not hasattr(k, "ai_tahmin") and "Yapay zekâ" not in core.format_card(k, now=100)


def test_report_counts_sources_durations_and_note_rate():
    now = 100_000.0
    rows = [
        core.Kayit(zaman=now - 3600, not_metni="not", tur="toplantı", repo="/r", kaynak="toplanti",
                   otomatik=True, donus=now - 3600 + 1800),
        core.Kayit(zaman=now - 3000, not_metni="", tur="toplantı", repo="/r", kaynak="toplanti", otomatik=True),
        core.Kayit(zaman=now - 2000, not_metni="soru notu", tur="soru", repo="/r", kaynak="kisayol",
                   donus=now - 2000 + 600),
        core.Kayit(zaman=now - 1000, not_metni="", tur="mola", repo="/r", kaynak="sessiz", otomatik=True),
        core.Kayit(zaman=now - 30 * 86400, not_metni="eski", tur="mola", repo="/r"),  # aralık dışı
    ]
    for r in rows:
        core.save_record(r)
    rep = core.report(7, now=now)
    assert "Son 7 gün: 4 kesinti kaydı" in rep
    assert "toplantı algılandı 2" in rep and "elle 1" in rep and "unutulmuş (notsuz otomatik) 1" in rep
    assert "Süresi ölçülen 2 kesinti: toplam 40 dk, ortalama 20 dk" in rep
    assert "Not bırakılan pencereler: 2/3 (%67)" in rep
    assert "Toplantıda kendiliğinden açılan pencerede not: 1/2" in rep
    assert core.report(7, now=now + 60 * 86400) == "Son 7 günde kayıt yok."


# ------------------------------------------------------------------ final
def test_no_repo_selected_is_safe():
    assert core.git_snapshot("") == {"dal": "", "diff_ozet": "", "dosyalar": [], "satir": 0,
                                     "git_deposu": False, "satir_kaynak": ""}
    assert core.choose_repo([], "VS Code") == ""
    k = core.make_record("", "not", "diğer", pencere="")
    assert k.repo == "" and "Proje: (seçilmedi)" in core.format_card(k, now=k.zaman)


def test_make_record_keeps_given_time():
    k = core.make_record("", "", "toplantı", pencere="", zaman=123.0)
    assert k.zaman == 123.0


def test_panel_settings_clamped_and_persisted():
    assert core.panel_settings({}) == ("sag", 18)                       # varsayılan: sağ, %18
    assert core.panel_settings({"panel": {"taraf": "sol", "genislik": 40}}) == ("sol", 20)
    assert core.panel_settings({"panel": {"taraf": "x", "genislik": "abc"}}) == ("sag", 18)
    core.add_ignore("Discord.exe")
    core.save_panel_settings("sol", 10)
    assert core.panel_settings() == ("sol", 15)
    assert core.load_ignore() == ["discord.exe"]                        # diğer ayar korunur
    core.remove_ignore("discord.exe")
    assert core.load_ignore() == []


def test_repos_persist_without_duplicates():
    core.save_repos(["C:/a", "C:/b", "C:/a"])
    assert core.load_repos() == ["C:/a", "C:/b"]


def test_card_wording_for_only_untracked_files():
    k = core.Kayit(zaman=0, not_metni="x", tur="diğer", repo="/r/demo", dosyalar=["yeni.py"])
    assert "yeni dosya(lar), henüz git’e eklenmedi" in core.format_card(k, now=0)
    k.dosyalar = []
    assert "commitlenmemiş değişiklik yok" in core.format_card(k, now=0)


# ------------------------------------------------------------------ git'siz klasör
def make_plain_folder() -> Path:
    d = Path(tempfile.mkdtemp()) / "oyun_klasoru"
    d.mkdir()
    for rel in ["scripts/oyuncu.gd", "scripts/envanter.gd", "sahne.tscn",
                ".godot/editor/cache.cfg", "node_modules/x/index.js", "Library/a.asset",
                "ikon.png.import", "oyuncu.gd.uid", "build/oyun.exe"]:
        f = d / rel
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text("x\n")
    return d


def test_plain_folder_snapshot_uses_modification_time_and_skips_generated():
    d = make_plain_folder()
    old = time.time() - 3600
    for rel in ["scripts/oyuncu.gd", "sahne.tscn"]:
        os.utime(d / rel, (old, old))
    time.sleep(0.05)
    (d / "scripts" / "envanter.gd").write_text("func sirala():\n    pass\n")
    for rel in [".godot/editor/cache.cfg", "node_modules/x/index.js", "Library/a.asset",
                "ikon.png.import", "oyuncu.gd.uid", "build/oyun.exe"]:
        (d / rel).write_text("araç dosyası, en yeni\n")             # en yeni ama atlanmalı
    snap = core.git_snapshot(str(d))
    assert snap["git_deposu"] is False and snap["satir"] == 0 and snap["dal"] == ""
    assert snap["dosyalar"][0] == "scripts/envanter.gd"
    assert set(snap["dosyalar"]) == {"scripts/envanter.gd", "scripts/oyuncu.gd", "sahne.tscn"}


def test_plain_folder_extra_excludes_from_settings():
    d = make_plain_folder()
    core.save_settings({"haric_klasorler": ["scripts"]})
    assert core.git_snapshot(str(d))["dosyalar"] == ["sahne.tscn"]


def test_card_for_plain_folder_has_no_git_lines_or_line_number():
    d = make_plain_folder()
    k = core.make_record(str(d), "envanter sıralamasını yazıyordum", "toplantı", pencere="")
    card = core.format_card(k, now=k.zaman)
    assert "Proje: oyun_klasoru" in card and "Son değiştirdiğin dosyalar:" in card
    assert "Dal:" not in card and "Değişiklik:" not in card and "(satır" not in card


def test_git_card_still_has_line_number():
    repo = make_repo()
    (repo / "a.py").write_text("x = 1\ny = 2\n")
    k = core.make_record(str(repo), "", "mola", pencere="")
    card = core.format_card(k, now=k.zaman)
    assert k.git_deposu and "Dal: main" in card and "a.py  (satır 2 - ilk değişiklik, git)" in card


def test_choose_repo_works_across_git_and_plain():
    repo = make_repo()
    d = make_plain_folder()
    time.sleep(0.05)
    (d / "sahne.tscn").write_text("en son\n")
    assert core.choose_repo([str(repo), str(d)], "WhatsApp") == str(d)
