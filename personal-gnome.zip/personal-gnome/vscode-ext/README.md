# Personal Gnome - VS Code eklentisi

İmleç hareket ettiğinde veya VS Code penceresi odak kazandığında, etkin dosyanın yolunu ve
imlecin satırını `~/.kaldigim_yer/vscode_imlec.json` dosyasına yazar. Personal Gnome paneli
kesinti anında bu bilgiyi okur ve kartta "satır 42 - imleç, VS Code" gösterir.

- İnternete bağlanmaz.
- Proje dosyalarını değiştirmez; yalnızca kendi tek veri dosyasını yazar.
