// Eklentiyi gerçek VS Code olmadan, sahte bir 'vscode' modülüyle çalıştırır.
// Kanıtlanan: 0 tabanlı satır 41 -> dosyaya 42 yazılır; odak yokken yazılmaz; atomik yazım.
const Module = require('module');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ky-'));
process.env.KALDIGIM_YER_DIR = tmp;

const dinleyiciler = {};
const fake = {
  window: {
    state: { focused: true },
    activeTextEditor: null,
    onDidChangeTextEditorSelection: f => { dinleyiciler.sel = f; return { dispose() {} }; },
    onDidChangeActiveTextEditor: f => { dinleyiciler.act = f; return { dispose() {} }; },
    onDidChangeWindowState: f => { dinleyiciler.win = f; return { dispose() {} }; }
  }
};
const origLoad = Module._load;
Module._load = function (req, ...rest) { return req === 'vscode' ? fake : origLoad.call(this, req, ...rest); };

const ext = require('../extension.js');
const editor = (file, line, ch, dirty) => ({
  document: { uri: { scheme: 'file', fsPath: file }, isDirty: dirty },
  selection: { active: { line, character: ch } }
});

const ctx = { subscriptions: [] };
ext.activate(ctx);
assert.strictEqual(ctx.subscriptions.length, 3);
const out = path.join(tmp, 'vscode_imlec.json');

// 1) Doğrudan yazım: 0 tabanlı 41 -> 42
ext.yaz(editor('/proje/auth.py', 41, 4, true));
let d = JSON.parse(fs.readFileSync(out, 'utf8'));
assert.strictEqual(d.satir, 42);
assert.strictEqual(d.sutun, 5);
assert.strictEqual(d.dosya, '/proje/auth.py');
assert.strictEqual(d.kaydedilmemis, true);
assert.ok(Math.abs(d.zaman - Date.now()) < 5000);

// 2) Dosya olmayan belge (ör. ayarlar, git farkı) yazılmaz
fs.unlinkSync(out);
ext.yaz({ document: { uri: { scheme: 'untitled', fsPath: 'x' }, isDirty: false }, selection: { active: { line: 0, character: 0 } } });
assert.ok(!fs.existsSync(out));

// 3) Seçim olayı (gecikmeli) -> yazılır; odak yokken yazılmaz
dinleyiciler.sel({ textEditor: editor('/proje/oyun.gd', 0, 0, false) });
setTimeout(() => {
  d = JSON.parse(fs.readFileSync(out, 'utf8'));
  assert.strictEqual(d.satir, 1);
  assert.strictEqual(d.dosya, '/proje/oyun.gd');
  fake.window.state.focused = false;
  dinleyiciler.sel({ textEditor: editor('/proje/baska.py', 99, 0, false) });
  setTimeout(() => {
    d = JSON.parse(fs.readFileSync(out, 'utf8'));
    assert.strictEqual(d.dosya, '/proje/oyun.gd');           // değişmedi
    assert.deepStrictEqual(fs.readdirSync(tmp).filter(f => f.endsWith('.tmp')), []);  // geçici dosya kalmadı
    console.log('EKLENTI TESTI: TAMAM');
  }, 600);
}, 600);
