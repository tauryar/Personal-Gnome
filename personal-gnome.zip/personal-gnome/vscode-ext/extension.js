// Personal Gnome - VS Code eklentisi.
// İmlecin dosya + satır bilgisini panelin veri klasörüne yazar. Proje dosyalarına dokunmaz.
const vscode = require('vscode');
const fs = require('fs');
const os = require('os');
const path = require('path');

const DOSYA = 'vscode_imlec.json';
let zamanlayici = null;

function veriKlasoru() {
  // Python tarafıyla aynı: KALDIGIM_YER_DIR ya da ~/.kaldigim_yer
  return process.env.KALDIGIM_YER_DIR || path.join(os.homedir(), '.kaldigim_yer');
}

function durum(editor) {
  if (!editor || !editor.document || editor.document.uri.scheme !== 'file') return null;
  const pos = editor.selection.active;
  return {
    dosya: editor.document.uri.fsPath,
    satir: pos.line + 1,          // VS Code satırları 0'dan sayar; kartta 1'den
    sutun: pos.character + 1,
    kaydedilmemis: editor.document.isDirty,
    zaman: Date.now()
  };
}

function yaz(editor) {
  const veri = durum(editor);
  if (!veri) return;
  const klasor = veriKlasoru();
  try {
    fs.mkdirSync(klasor, { recursive: true });
    const gecici = path.join(klasor, DOSYA + '.' + process.pid + '.tmp');
    fs.writeFileSync(gecici, JSON.stringify(veri));
    fs.renameSync(gecici, path.join(klasor, DOSYA));   // yarım yazılmış dosya okunmasın
  } catch (e) {
    // Panel okurken dosya anlık kilitli olabilir; bir sonraki harekette tekrar yazılır.
  }
}

function planla(editor, gecikme) {
  if (zamanlayici) clearTimeout(zamanlayici);
  zamanlayici = setTimeout(() => { zamanlayici = null; yaz(editor); }, gecikme);
}

function activate(context) {
  context.subscriptions.push(
    vscode.window.onDidChangeTextEditorSelection(e => {
      if (vscode.window.state.focused) planla(e.textEditor, 400);
    }),
    vscode.window.onDidChangeActiveTextEditor(ed => {
      if (vscode.window.state.focused) planla(ed, 100);
    }),
    vscode.window.onDidChangeWindowState(s => {
      if (s.focused) planla(vscode.window.activeTextEditor, 100);
    })
  );
  if (vscode.window.state.focused) yaz(vscode.window.activeTextEditor);
}

function deactivate() {
  if (zamanlayici) clearTimeout(zamanlayici);
}

module.exports = { activate, deactivate, durum, yaz, veriKlasoru };
