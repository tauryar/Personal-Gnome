"""Kenar yerleşimi hesapları (Windows çağrıları olmadan test edilebilen kısım)."""
import dock


def test_right_edge_default_18_percent_full_hd():
    assert dock.compute_rect("sag", 18, 1920, 1080) == (1574, 0, 346, 1080)


def test_left_edge_and_limits():
    assert dock.compute_rect("sol", 15, 1920, 1080) == (0, 0, 288, 1080)
    assert dock.compute_rect("sag", 20, 1366, 768) == (1093, 0, 273, 768)


def test_appbar_constants_match_shellapi_h():
    # shellapi.h: ABM_NEW 0, ABM_REMOVE 1, ABM_QUERYPOS 2, ABM_SETPOS 3; ABE_LEFT 0, ABE_RIGHT 2
    assert (dock.ABM_NEW, dock.ABM_REMOVE, dock.ABM_QUERYPOS, dock.ABM_SETPOS) == (0, 1, 2, 3)
    assert (dock.ABE_LEFT, dock.ABE_RIGHT) == (0, 2)


def test_panel_stops_above_bottom_taskbar():
    # 1920x1080, görev çubuğu altta 48 px: panel 0..1032 arası (saat kapanmaz)
    assert dock.vertical_bounds(1920, 1080, (0, 1032, 1920, 1080), False) == (0, 1032)


def test_panel_starts_below_top_taskbar():
    assert dock.vertical_bounds(1920, 1080, (0, 0, 1920, 48), False) == (48, 1080)


def test_full_height_when_taskbar_hidden_vertical_or_unknown():
    assert dock.vertical_bounds(1920, 1080, (0, 1032, 1920, 1080), True) == (0, 1080)   # otomatik gizli
    assert dock.vertical_bounds(1920, 1080, (0, 0, 62, 1080), False) == (0, 1080)       # solda dikey
    assert dock.vertical_bounds(1920, 1080, None, False) == (0, 1080)                   # alınamadı


def test_new_constants_match_shellapi_h():
    # shellapi.h: ABM_GETSTATE 4, ABM_GETTASKBARPOS 5, ABS_AUTOHIDE 1
    assert (dock.ABM_GETSTATE, dock.ABM_GETTASKBARPOS, dock.ABS_AUTOHIDE) == (4, 5, 1)
