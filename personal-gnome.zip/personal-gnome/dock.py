"""Paneli ekranın kenarına yerleştirme.

Windows'ta "appbar" (uygulama masaüstü araç çubuğu) olarak kaydolur: görev çubuğu
gibi ekranın kenarında yer ayırır, büyütülen pencereler kalan alana sığar.
Kullanılan çağrılar (shellapi.h): SHAppBarMessage ile ABM_NEW, ABM_QUERYPOS,
ABM_SETPOS, ABM_REMOVE, ABM_GETSTATE, ABM_GETTASKBARPOS. Windows dışında veya kayıt
başarısız olursa pencere yalnızca kenara konumlandırılır (yer ayrılmaz).

Şerit modunda yalnızca ince bir şerit kadar yer ayrılır; panel açılınca ayrılan alan
değişmez (pencereler yeniden boyutlanıp titremesin). Tkinter appbar bildirimlerini
(ABN_POSCHANGED, ABN_FULLSCREENAPP) yakalayamadığı için ekran/görev çubuğu durumu ve
öndeki tam ekran uygulama 2 sn'de bir yoklanır.
"""
from __future__ import annotations

import sys

IS_WINDOWS = sys.platform == "win32"

ABM_NEW, ABM_REMOVE, ABM_QUERYPOS, ABM_SETPOS = 0, 1, 2, 3
ABM_GETSTATE, ABM_GETTASKBARPOS = 4, 5
ABE_LEFT, ABE_RIGHT = 0, 2
ABS_AUTOHIDE = 1


def compute_rect(taraf: str, pct: int, sw: int, sh: int) -> tuple[int, int, int, int]:
    """(x, y, genişlik, yükseklik): ekranın sağ/sol kenarında, genişliğin %pct'si."""
    w = max(1, round(sw * pct / 100))
    x = sw - w if taraf == "sag" else 0
    return x, 0, w, sh


def vertical_bounds(sw: int, sh: int, taskbar: tuple[int, int, int, int] | None,
                    autohide: bool) -> tuple[int, int]:
    """Panelin üst/alt sınırı: görev çubuğu altta/üstteyse onun üstünde/altında biter
    (saat ve bildirim alanı kapanmasın). Görev çubuğu yan kenardaysa veya otomatik
    gizleniyorsa tam yükseklik."""
    if taskbar is None or autohide:
        return 0, sh
    left, top, right, bottom = taskbar
    if right - left < sw // 2:          # dikey görev çubuğu (sol/sağ kenar)
        return 0, sh
    if top > 0 and bottom >= sh:        # altta
        return 0, max(1, min(top, sh))
    if top <= 0 and bottom < sh:        # üstte
        return max(0, bottom), sh
    return 0, sh


if IS_WINDOWS:
    import ctypes
    from ctypes import wintypes

    class APPBARDATA(ctypes.Structure):
        # 32-bit Windows'ta shellapi.h bu yapıyı 1 bayt hizalı paketler.
        if ctypes.sizeof(ctypes.c_void_p) == 4:
            _pack_ = 1
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("hWnd", wintypes.HWND),
            ("uCallbackMessage", wintypes.UINT),
            ("uEdge", wintypes.UINT),
            ("rc", wintypes.RECT),
            ("lParam", wintypes.LPARAM),
        ]


def screen_size(root) -> tuple[int, int]:
    """Birincil ekranın boyutu. Windows'ta her çağrıda sistemden okunur (çözünürlük
    değişince güncel olsun)."""
    if IS_WINDOWS:
        try:
            w, h = ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1)
            if w > 0 and h > 0:
                return w, h
        except Exception:
            pass
    return root.winfo_screenwidth(), root.winfo_screenheight()


def expanded_rect(taraf: str, full_w: int, reserved: tuple[int, int, int, int],
                  sw: int) -> tuple[int, int, int, int]:
    """Şerit açıldığında pencerenin dikdörtgeni: ayrılan alanın yüksekliğinde, tam genişlikte."""
    _, y, _, h = reserved
    x = sw - full_w if taraf == "sag" else 0
    return x, y, full_w, h


def fullscreen_app_active(own_hwnds: tuple[int, ...] = ()) -> bool:
    """Öndeki pencere bütün ekranı kaplıyor mu (oyun, video, sunum)? Windows dışında False."""
    if not IS_WINDOWS:
        return False
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd or hwnd in own_hwnds or user32.GetAncestor(hwnd, 2) in own_hwnds:  # GA_ROOT
            return False
        buf = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(hwnd, buf, 64)
        if buf.value in ("Progman", "WorkerW", "Shell_TrayWnd"):  # masaüstü ve görev çubuğu
            return False
        if user32.IsZoomed(hwnd):  # büyütülmüş normal pencere tam ekran uygulama değildir
            return False
        r = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
            return False
        sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        return r.left <= 0 and r.top <= 0 and r.right >= sw and r.bottom >= sh
    except Exception:
        return False


class Dock:
    def __init__(self, root):
        self.root = root
        self.registered = False
        self.appbar_ok = IS_WINDOWS
        self.last_error = ""
        self.hwnd = 0  # kayıtta saklanır: pencere yok olsa da ABM_REMOVE gönderilebilsin
        self.reserved = (0, 0, 0, 0)   # ekranda ayrılan alan (x, y, w, h)
        self.full_width = 0            # panelin açık hâldeki genişliği
        self._sig = None               # son yerleşimdeki ekran/görev çubuğu durumu

    # -------------------------------------------------------------- Windows appbar
    def _hwnd(self) -> int:
        self.root.update_idletasks()
        try:
            return int(self.root.wm_frame(), 16)  # Tk'nin dış çerçeve penceresi
        except (ValueError, TypeError):
            return ctypes.windll.user32.GetParent(self.root.winfo_id())

    def _abd(self, edge: int, rect: tuple[int, int, int, int]) -> "APPBARDATA":
        abd = APPBARDATA()
        abd.cbSize = ctypes.sizeof(APPBARDATA)
        abd.hWnd = self.hwnd or self._hwnd()
        abd.uEdge = edge
        abd.rc.left, abd.rc.top, abd.rc.right, abd.rc.bottom = rect
        return abd

    def _appbar(self, taraf: str, w: int, sw: int, sh: int) -> tuple[int, int, int, int]:
        shell32 = ctypes.windll.shell32
        edge = ABE_RIGHT if taraf == "sag" else ABE_LEFT
        if not self.registered:
            self.hwnd = self._hwnd()
            abd = self._abd(edge, (0, 0, 0, 0))
            abd.uCallbackMessage = ctypes.windll.user32.RegisterWindowMessageW("PersonalGnomeAppBar")
            if not shell32.SHAppBarMessage(ABM_NEW, ctypes.byref(abd)):
                raise OSError("ABM_NEW reddedildi")
            self.registered = True
        top, bottom = vertical_bounds(sw, sh, *self._taskbar(shell32))
        x = sw - w if taraf == "sag" else 0
        abd = self._abd(edge, (x, top, x + w, bottom))
        shell32.SHAppBarMessage(ABM_QUERYPOS, ctypes.byref(abd))  # sistem dikdörtgeni düzeltir
        if taraf == "sag":
            abd.rc.left = abd.rc.right - w
        else:
            abd.rc.right = abd.rc.left + w
        shell32.SHAppBarMessage(ABM_SETPOS, ctypes.byref(abd))     # son hâli sistem verir
        r = abd.rc
        return r.left, r.top, r.right - r.left, r.bottom - r.top

    def _taskbar(self, shell32) -> tuple[tuple[int, int, int, int] | None, bool]:
        """Windows görev çubuğunun dikdörtgeni ve otomatik gizlenip gizlenmediği."""
        try:
            abd = APPBARDATA()
            abd.cbSize = ctypes.sizeof(APPBARDATA)
            autohide = bool(shell32.SHAppBarMessage(ABM_GETSTATE, ctypes.byref(abd)) & ABS_AUTOHIDE)
            abd = APPBARDATA()
            abd.cbSize = ctypes.sizeof(APPBARDATA)
            if not shell32.SHAppBarMessage(ABM_GETTASKBARPOS, ctypes.byref(abd)):
                return None, autohide
            r = abd.rc
            return (r.left, r.top, r.right, r.bottom), autohide
        except Exception:
            return None, False

    def own_hwnd(self) -> int:
        """Panelin kendi pencere tanıtıcısı (tam ekran algılamada kendimizi saymamak için)."""
        if not IS_WINDOWS:
            return 0
        try:
            return self.hwnd or self._hwnd()
        except Exception:
            return 0

    def remove(self) -> None:
        """Ayrılan alanı geri ver. Kapanışta mutlaka çağrılmalı."""
        if IS_WINDOWS and self.registered:
            try:
                abd = self._abd(0, (0, 0, 0, 0))
                ctypes.windll.shell32.SHAppBarMessage(ABM_REMOVE, ctypes.byref(abd))
            except Exception as exc:
                self.last_error = str(exc)
            self.registered = False

    # -------------------------------------------------------------- değişiklik algılama
    def signature(self) -> tuple:
        """Ekran boyutu + görev çubuğu konumu + otomatik gizlenme. Değişirse yeniden yerleş."""
        sw, sh = screen_size(self.root)
        tb = self._taskbar(ctypes.windll.shell32) if IS_WINDOWS else (None, False)
        return sw, sh, tb[0], tb[1]

    def changed(self) -> bool:
        try:
            return self._sig is not None and self.signature() != self._sig
        except Exception:
            return False

    # -------------------------------------------------------------- genel
    def apply(self, taraf: str, pct: int, fullscreen: bool = False,
              reserve: int | None = None) -> tuple[int, int, int, int]:
        """Ekranda yer ayır; ayrılan alanı (x, y, w, h) döndür ve pencereyi oraya koy.
        reserve verilirse (şerit modu) sadece o kadar piksel ayrılır; açık hâlin genişliği
        full_width'te tutulur."""
        sw, sh = screen_size(self.root)
        self.full_width = compute_rect(taraf, pct, sw, sh)[2]
        if fullscreen:
            self.remove()
            geo = (0, 0, sw, sh)
        else:
            width = self.full_width if reserve is None else max(1, int(reserve))
            geo = (sw - width if taraf == "sag" else 0, 0, width, sh)
            if self.appbar_ok:
                try:
                    geo = self._appbar(taraf, width, sw, sh)
                except Exception as exc:  # appbar olmazsa sadece kenara koy
                    self.appbar_ok = False
                    self.last_error = str(exc)
                    print(f"[panel] ekranda yer ayrılamadı, kenara yerleştirildi: {exc}")
        self.reserved = geo
        try:
            self._sig = self.signature()
        except Exception:
            self._sig = None
        self.set_geometry(geo)
        return geo

    def set_geometry(self, geo: tuple[int, int, int, int]) -> None:
        x, y, w, h = geo
        self.root.geometry(f"{w}x{h}+{x}+{y}")
